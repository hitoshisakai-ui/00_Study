import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useMemo = __vite__cjsImport0_react["useMemo"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=d3229816";
import "/src/App.css";
var _jsxFileName = "C:/ai-Coding-traning/MemoPad_hands-on/client/src/App.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d3229816";
var _s = $RefreshSig$();
const API_BASE = "http://localhost:3001/api";
const emptyMemo = {
	title: "",
	body: "",
	tagsText: ""
};
const emptyUser = {
	userId: "",
	displayName: "",
	email: "",
	password: "",
	role: "user",
	status: "active"
};
const initialFilters = {
	keyword: "",
	page: 1,
	limit: 10,
	sortBy: "updatedAt",
	order: "desc",
	favorite: false,
	tag: ""
};
function formatDate(value) {
	if (!value) return "";
	const date = new Date(value);
	if (Number.isNaN(date.getTime())) return value;
	const pad = (num) => String(num).padStart(2, "0");
	return `${date.getFullYear()}/${pad(date.getMonth() + 1)}/${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}
function formatSize(size) {
	if (!size) return "0 KB";
	if (size >= 1024 * 1024) return (size / 1024 / 1024).toFixed(1) + " MB";
	return Math.max(1, Math.round(size / 1024)) + " KB";
}
function getExtension(name) {
	const parts = String(name || "").split(".");
	return parts.length > 1 ? parts.pop().toLowerCase() : "";
}
function validateSelectedFiles(files, existingCount, type) {
	const errors = {};
	const list = Array.from(files || []);
	const isImage = type === "image";
	const allowed = isImage ? [
		"jpg",
		"jpeg",
		"png",
		"gif",
		"webp"
	] : [
		"pdf",
		"txt",
		"csv",
		"docx",
		"xlsx"
	];
	const maxCount = isImage ? 10 : 5;
	const maxSize = isImage ? 5 * 1024 * 1024 : 10 * 1024 * 1024;
	const key = isImage ? "images" : "attachments";
	if (existingCount + list.length > maxCount) errors[key] = isImage ? "画像は10枚以内で選択してください。" : "添付ファイルは5件以内で選択してください。";
	for (const file of list) {
		if (!allowed.includes(getExtension(file.name))) errors[key] = isImage ? "アップロードできる画像形式は jpg, jpeg, png, gif, webp です。" : "添付できるファイル形式は pdf, txt, csv, docx, xlsx です。";
		if (file.size > maxSize) errors[key] = isImage ? "画像は1ファイル5MB以内で選択してください。" : "添付ファイルは1ファイル10MB以内で選択してください。";
	}
	return errors;
}
function fileToUpload(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => resolve({
			name: file.name,
			type: file.type || "application/octet-stream",
			size: file.size,
			content: reader.result
		});
		reader.onerror = reject;
		reader.readAsDataURL(file);
	});
}
function validateMemo(form) {
	const errors = {};
	if (!form.title || form.title.trim().length === 0) errors.title = "タイトルを入力してください。";
	else if (form.title.length > 100) errors.title = "タイトルは100文字以内で入力してください。";
	if (!form.body || form.body.trim().length === 0) errors.body = "本文を入力してください。";
	else if (form.body.length > 2e3) errors.body = "本文は2000文字以内で入力してください。";
	return errors;
}
function validateLogin(form) {
	const errors = {};
	if (!form.userId.trim()) errors.userId = "ユーザーIDを入力してください。";
	else if (!/^[a-zA-Z0-9_-]+$/.test(form.userId)) errors.userId = "ユーザーIDは半角英数字、ハイフン、アンダースコアで入力してください。";
	else if (form.userId.length < 4 || form.userId.length > 20) errors.userId = "ユーザーIDは4文字以上20文字以内で入力してください。";
	if (!form.password) errors.password = "パスワードを入力してください。";
	else if (form.password.length < 8 || form.password.length > 64) errors.password = "パスワードは8文字以上64文字以内で入力してください。";
	return errors;
}
function App() {
	_s();
	const [token, setToken] = useState(() => localStorage.getItem("memoPadToken") || "");
	const [currentUser, setCurrentUser] = useState(null);
	const [loginForm, setLoginForm] = useState({
		userId: "admin",
		password: "password123"
	});
	const [loginErrors, setLoginErrors] = useState({});
	const [memos, setMemos] = useState([]);
	const [total, setTotal] = useState(0);
	const [selectedMemo, setSelectedMemo] = useState(null);
	const [memoForm, setMemoForm] = useState(emptyMemo);
	const [pendingAttachments, setPendingAttachments] = useState([]);
	const [pendingImages, setPendingImages] = useState([]);
	const [fileErrors, setFileErrors] = useState({});
	const [imageUrls, setImageUrls] = useState({});
	const [users, setUsers] = useState([]);
	const [tags, setTags] = useState([]);
	const [selectedUser, setSelectedUser] = useState(null);
	const [userForm, setUserForm] = useState(emptyUser);
	const [userErrors, setUserErrors] = useState({});
	const [mode, setMode] = useState("list");
	const [displayMode, setDisplayMode] = useState("list");
	const [filters, setFilters] = useState(initialFilters);
	const [formErrors, setFormErrors] = useState({});
	const [message, setMessage] = useState("");
	const [globalError, setGlobalError] = useState("");
	const [isLoading, setIsLoading] = useState(false);
	const [isSaving, setIsSaving] = useState(false);
	const [draftStatus, setDraftStatus] = useState("");
	const [formTouched, setFormTouched] = useState(false);
	const autosaveTimerRef = useRef(null);
	const autosaveSeqRef = useRef(0);
	const lastDraftPayloadRef = useRef("");
	const authHeaders = useMemo(() => token ? { Authorization: `Bearer ${token}` } : {}, [token]);
	const pageCount = Math.max(1, Math.ceil(total / filters.limit));
	const handleLoggedOut = () => {
		localStorage.removeItem("memoPadToken");
		setToken("");
		setCurrentUser(null);
		setMode("list");
	};
	const requestJson = async (path, options = {}) => {
		const response = await fetch(`${API_BASE}${path}`, {
			...options,
			headers: {
				...authHeaders,
				...options.headers || {}
			}
		});
		const data = response.status === 204 ? null : await response.json().catch(() => null);
		if (!response.ok) {
			const error = new Error(data?.message || "server");
			error.status = response.status;
			error.data = data;
			throw error;
		}
		return data;
	};
	const loadMemos = async () => {
		if (!token) return;
		setIsLoading(true);
		setGlobalError("");
		try {
			const params = new URLSearchParams({
				keyword: filters.keyword,
				page: String(filters.page),
				limit: String(filters.limit),
				sortBy: filters.sortBy,
				order: filters.order,
				favorite: String(filters.favorite),
				tag: filters.tag
			});
			const data = await requestJson(`/todos?${params.toString()}`);
			setMemos(data.items);
			setTotal(data.total);
			await loadTags();
		} catch (error) {
			if (error.status === 401) handleLoggedOut();
			else setGlobalError("通信に失敗しました。ネットワーク接続を確認してください。");
		} finally {
			setIsLoading(false);
		}
	};
	const loadTags = async () => {
		if (!token) return;
		try {
			setTags(await requestJson("/tags"));
		} catch (error) {}
	};
	const loadUsers = async () => {
		setGlobalError("");
		try {
			setUsers(await requestJson("/users"));
		} catch (error) {
			if (error.status === 403) {
				setMode("list");
				setGlobalError("アクセス権限がありません。");
			} else setGlobalError("通信に失敗しました。ネットワーク接続を確認してください。");
		}
	};
	useEffect(() => {
		const loadMe = async () => {
			if (!token) return;
			try {
				const data = await requestJson("/me");
				setCurrentUser(data.user);
			} catch (error) {
				handleLoggedOut();
			}
		};
		loadMe();
	}, [token]);
	useEffect(() => {
		if (currentUser) loadMemos();
	}, [currentUser, filters]);
	useEffect(() => {
		clearAutosaveTimer();
		if (!currentUser || !(mode === "create" || mode === "edit")) return;
		let cancelled = false;
		const loadDraft = async () => {
			setDraftStatus("");
			try {
				const data = await requestJson(draftPath);
				if (cancelled || !data?.draft) {
					lastDraftPayloadRef.current = serializeDraftPayload(buildDraftPayload());
					return;
				}
				const staleMessage = data.draft.isStale ? "他のユーザーによって元のメモが更新されています。復元後は内容を確認してください。" : "";
				if (window.confirm(`${staleMessage}${staleMessage ? "\n" : ""}保存されていない下書きがあります。復元しますか？`)) {
					const restored = {
						title: data.draft.title,
						body: data.draft.body,
						tagsText: data.draft.tagsText
					};
					setMemoForm(restored);
					setDraftStatus("下書きを復元しました。");
					lastDraftPayloadRef.current = serializeDraftPayload({
						memoId: draftMemoId,
						...restored,
						baseUpdatedAt: selectedMemo?.updatedAt || null
					});
				} else {
					await deleteCurrentDraft();
					lastDraftPayloadRef.current = serializeDraftPayload(buildDraftPayload());
				}
				setFormTouched(false);
			} catch (error) {
				lastDraftPayloadRef.current = serializeDraftPayload(buildDraftPayload());
			}
		};
		loadDraft();
		return () => {
			cancelled = true;
			clearAutosaveTimer();
		};
	}, [
		currentUser,
		mode,
		selectedMemo?.id
	]);
	useEffect(() => {
		clearAutosaveTimer();
		if (!currentUser || !(mode === "create" || mode === "edit") || isSaving || !formTouched) return;
		if (mode === "create" && !hasDraftContent(memoForm)) return;
		const payload = buildDraftPayload();
		const serialized = serializeDraftPayload(payload);
		if (serialized === lastDraftPayloadRef.current) return;
		autosaveTimerRef.current = setTimeout(async () => {
			const seq = autosaveSeqRef.current + 1;
			autosaveSeqRef.current = seq;
			try {
				const data = await requestJson("/drafts", {
					method: "POST",
					headers: { "Content-Type": "application/json" },
					body: JSON.stringify(payload)
				});
				if (seq === autosaveSeqRef.current) {
					lastDraftPayloadRef.current = serialized;
					setDraftStatus(data?.message || "下書きを保存しました。");
				}
			} catch (error) {
				if (seq === autosaveSeqRef.current) setDraftStatus("下書き保存に失敗しました。");
			}
		}, 3e3);
		return clearAutosaveTimer;
	}, [
		memoForm,
		mode,
		selectedMemo?.id,
		selectedMemo?.updatedAt,
		currentUser,
		isSaving,
		formTouched
	]);
	useEffect(() => {
		let active = true;
		const urls = [];
		const loadImageUrls = async () => {
			const images = selectedMemo?.images || [];
			if (images.length === 0) {
				setImageUrls({});
				return;
			}
			const entries = await Promise.all(images.map(async (file) => {
				try {
					const blob = await fetchFileBlob(file);
					const url = URL.createObjectURL(blob);
					urls.push(url);
					return [file.id, url];
				} catch (error) {
					return [file.id, ""];
				}
			}));
			if (active) setImageUrls(Object.fromEntries(entries));
		};
		loadImageUrls();
		return () => {
			active = false;
			urls.forEach((url) => URL.revokeObjectURL(url));
		};
	}, [
		selectedMemo?.id,
		selectedMemo?.images,
		token
	]);
	const login = async (event) => {
		event.preventDefault();
		const errors = validateLogin(loginForm);
		setLoginErrors(errors);
		setGlobalError("");
		if (Object.keys(errors).length > 0) return;
		setIsSaving(true);
		try {
			const response = await fetch(`${API_BASE}/login`, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(loginForm)
			});
			const data = await response.json().catch(() => null);
			if (!response.ok) throw new Error(data?.message || "login");
			localStorage.setItem("memoPadToken", data.token);
			setToken(data.token);
			setCurrentUser(data.user);
			setMessage("ログインしました。");
		} catch (error) {
			setGlobalError("ユーザーIDまたはパスワードが正しくありません。");
		} finally {
			setIsSaving(false);
		}
	};
	const logout = async () => {
		try {
			if (token) await requestJson("/logout", { method: "POST" });
		} catch (error) {}
		handleLoggedOut();
		setMessage("");
	};
	const updateFilters = (patch) => setFilters((current) => ({
		...current,
		...patch,
		page: patch.page || 1
	}));
	const draftMemoId = mode === "edit" && selectedMemo ? selectedMemo.id : null;
	const draftPath = draftMemoId ? `/drafts/memos/${draftMemoId}` : "/drafts/new";
	const buildDraftPayload = () => ({
		memoId: draftMemoId,
		title: memoForm.title,
		body: memoForm.body,
		tagsText: memoForm.tagsText,
		baseUpdatedAt: selectedMemo?.updatedAt || null
	});
	const serializeDraftPayload = (payload) => JSON.stringify(payload);
	const hasDraftContent = (form) => Boolean(form.title || form.body || form.tagsText);
	const setMemoField = (field, value) => {
		setMemoForm((current) => ({
			...current,
			[field]: value
		}));
		setFormTouched(true);
		setDraftStatus("");
	};
	const clearAutosaveTimer = () => {
		if (autosaveTimerRef.current) {
			clearTimeout(autosaveTimerRef.current);
			autosaveTimerRef.current = null;
		}
	};
	const deleteCurrentDraft = async () => {
		try {
			await requestJson(draftPath, { method: "DELETE" });
		} catch (error) {}
	};
	const fetchFileBlob = async (file) => {
		const response = await fetch(API_BASE + file.downloadUrl, { headers: authHeaders });
		if (!response.ok) throw new Error("download");
		return response.blob();
	};
	const downloadFile = async (file) => {
		try {
			const blob = await fetchFileBlob(file);
			const url = URL.createObjectURL(blob);
			const link = document.createElement("a");
			link.href = url;
			link.download = file.originalName;
			document.body.appendChild(link);
			link.click();
			link.remove();
			URL.revokeObjectURL(url);
		} catch (error) {
			setGlobalError("通信に失敗しました。ネットワーク接続を確認してください。");
		}
	};
	const refreshSelectedMemo = async () => {
		if (!selectedMemo) return;
		const memo = await requestJson("/todos/" + selectedMemo.id);
		setSelectedMemo(memo);
	};
	const deleteExistingFile = async (file) => {
		if (!window.confirm(file.originalName + " を削除しますか？")) return;
		try {
			await requestJson("/files/" + file.id, { method: "DELETE" });
			await refreshSelectedMemo();
			setMessage("ファイルを削除しました。");
		} catch (error) {
			setGlobalError(error.message || "処理中にエラーが発生しました。時間をおいて再度お試しください。");
		}
	};
	const addPendingFiles = (event, type) => {
		const selected = Array.from(event.target.files || []);
		const isImage = type === "image";
		const existingCount = isImage ? (selectedMemo?.images || []).length : (selectedMemo?.attachments || []).length;
		const current = isImage ? pendingImages : pendingAttachments;
		const next = [...current, ...selected];
		const errors = validateSelectedFiles(next, existingCount, type);
		const key = isImage ? "images" : "attachments";
		setFileErrors((currentErrors) => ({
			...currentErrors,
			[key]: errors[key] || ""
		}));
		if (isImage) setPendingImages(next);
		else setPendingAttachments(next);
		event.target.value = "";
	};
	const removePendingFile = (index, type) => {
		if (type === "image") setPendingImages((current) => current.filter((_, i) => i !== index));
		else setPendingAttachments((current) => current.filter((_, i) => i !== index));
		setFileErrors({});
	};
	const clearFileInputs = () => {
		setPendingAttachments([]);
		setPendingImages([]);
		setFileErrors({});
		setImageUrls({});
	};
	const openUserList = async () => {
		if (currentUser.role !== "admin") {
			setMode("list");
			setGlobalError("アクセス権限がありません。");
			return;
		}
		setMode("users");
		setMessage("");
		setUserErrors({});
		await loadUsers();
	};
	const startCreate = () => {
		clearAutosaveTimer();
		setSelectedMemo(null);
		setMemoForm(emptyMemo);
		clearFileInputs();
		setFormTouched(false);
		lastDraftPayloadRef.current = "";
		setDraftStatus("");
		setFormErrors({});
		setMessage("");
		setGlobalError("");
		setMode("create");
	};
	const startEdit = async (memo) => {
		clearAutosaveTimer();
		const fullMemo = memo.attachments ? memo : await requestJson("/todos/" + memo.id);
		setSelectedMemo(fullMemo);
		setMemoForm({
			title: fullMemo.title,
			body: fullMemo.body,
			tagsText: (fullMemo.tags || []).join(", ")
		});
		clearFileInputs();
		setFormTouched(false);
		lastDraftPayloadRef.current = "";
		setDraftStatus("");
		setFormErrors({});
		setMessage("");
		setGlobalError("");
		setMode("edit");
	};
	const showDetail = async (memo) => {
		setGlobalError("");
		try {
			setSelectedMemo(await requestJson(`/todos/${memo.id}`));
			setMode("detail");
		} catch (error) {
			setGlobalError(error.message || "指定されたメモは存在しません。");
			await loadMemos();
		}
	};
	const cancelMemoForm = async () => {
		const original = selectedMemo ? {
			title: selectedMemo.title,
			body: selectedMemo.body,
			tagsText: (selectedMemo.tags || []).join(", ")
		} : emptyMemo;
		const changed = memoForm.title !== original.title || memoForm.body !== original.body || memoForm.tagsText !== original.tagsText;
		if (changed && !window.confirm("入力内容は保存されていません。破棄しますか？")) return;
		clearAutosaveTimer();
		if (changed || hasDraftContent(memoForm)) await deleteCurrentDraft();
		setMode("list");
		setMemoForm(emptyMemo);
		clearFileInputs();
		setFormTouched(false);
		setDraftStatus("");
		setFormErrors({});
	};
	const saveMemo = async (event) => {
		event.preventDefault();
		const errors = validateMemo(memoForm);
		const attachmentErrors = validateSelectedFiles(pendingAttachments, selectedMemo?.attachments?.length || 0, "attachment");
		const imageErrors = validateSelectedFiles(pendingImages, selectedMemo?.images?.length || 0, "image");
		const nextFileErrors = {
			...attachmentErrors,
			...imageErrors
		};
		setFormErrors(errors);
		setFileErrors(nextFileErrors);
		setGlobalError("");
		setMessage("");
		if (Object.keys(errors).length > 0 || Object.values(nextFileErrors).some(Boolean)) return;
		clearAutosaveTimer();
		setIsSaving(true);
		try {
			const isEdit = mode === "edit" && selectedMemo;
			const attachments = await Promise.all(pendingAttachments.map(fileToUpload));
			const images = await Promise.all(pendingImages.map(fileToUpload));
			await requestJson("/todos" + (isEdit ? "/" + selectedMemo.id : ""), {
				method: isEdit ? "PUT" : "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					title: memoForm.title,
					body: memoForm.body,
					tags: memoForm.tagsText,
					updatedAt: selectedMemo?.updatedAt,
					attachments,
					images
				})
			});
			setMessage(isEdit ? "メモを更新しました。" : "メモを登録しました。");
			lastDraftPayloadRef.current = "";
			clearFileInputs();
			setFormTouched(false);
			setDraftStatus("");
			setMode("list");
			setMemoForm(emptyMemo);
			setSelectedMemo(null);
			await loadMemos();
			await loadTags();
		} catch (error) {
			if (error.data?.errors) setFormErrors(error.data.errors);
			setGlobalError(error.status === 409 ? error.message : "処理中にエラーが発生しました。時間をおいて再度お試しください。");
		} finally {
			setIsSaving(false);
		}
	};
	const deleteMemo = async (memo) => {
		if (!window.confirm("このメモを削除しますか？")) return;
		try {
			await requestJson(`/todos/${memo.id}`, { method: "DELETE" });
			setMessage("メモを削除しました。");
			setMode("list");
			setSelectedMemo(null);
			await loadMemos();
		} catch (error) {
			setGlobalError(error.message || "処理中にエラーが発生しました。時間をおいて再度お試しください。");
		}
	};
	const toggleFavorite = async (memo) => {
		try {
			await requestJson(`/todos/${memo.id}/favorite`, { method: memo.isFavorite ? "DELETE" : "POST" });
			await loadMemos();
		} catch (error) {
			setGlobalError("処理中にエラーが発生しました。時間をおいて再度お試しください。");
		}
	};
	const startUserCreate = () => {
		setSelectedUser(null);
		setUserForm(emptyUser);
		setUserErrors({});
		setMode("userForm");
	};
	const startUserEdit = (user) => {
		setSelectedUser(user);
		setUserForm({
			userId: user.userId,
			displayName: user.displayName,
			email: user.email,
			password: "",
			role: user.role,
			status: user.status
		});
		setUserErrors({});
		setMode("userForm");
	};
	const saveUser = async (event) => {
		event.preventDefault();
		setIsSaving(true);
		setUserErrors({});
		setGlobalError("");
		setMessage("");
		try {
			const isEdit = Boolean(selectedUser);
			const data = await requestJson(`/users${isEdit ? `/${selectedUser.id}` : ""}`, {
				method: isEdit ? "PUT" : "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(userForm)
			});
			setMessage(data.message);
			setMode("users");
			await loadUsers();
		} catch (error) {
			if (error.data?.errors) setUserErrors(error.data.errors);
			else setGlobalError(error.message || "処理中にエラーが発生しました。時間をおいて再度お試しください。");
		} finally {
			setIsSaving(false);
		}
	};
	const disableUser = async (user) => {
		if (!window.confirm(`${user.userId} を無効化しますか？`)) return;
		try {
			const data = await requestJson(`/users/${user.id}/disable`, { method: "PATCH" });
			setMessage(data.message);
			await loadUsers();
		} catch (error) {
			setGlobalError(error.message || "処理中にエラーが発生しました。時間をおいて再度お試しください。");
		}
	};
	if (!token || !currentUser) {
		return /* @__PURE__ */ _jsxDEV("main", {
			className: "app-shell narrow",
			children: /* @__PURE__ */ _jsxDEV("section", {
				className: "workspace form-panel",
				children: [
					/* @__PURE__ */ _jsxDEV("p", {
						className: "eyebrow",
						children: "QA Exercise"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 422,
						columnNumber: 89
					}, this),
					/* @__PURE__ */ _jsxDEV("h1", { children: "MemoPad ログイン" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 422,
						columnNumber: 127
					}, this),
					globalError && /* @__PURE__ */ _jsxDEV("div", {
						className: "notice error",
						children: globalError
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 422,
						columnNumber: 164
					}, this),
					/* @__PURE__ */ _jsxDEV("form", {
						onSubmit: login,
						noValidate: true,
						children: [
							/* @__PURE__ */ _jsxDEV("label", {
								className: "field",
								children: [
									/* @__PURE__ */ _jsxDEV("span", { children: "ユーザーID" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 422,
										columnNumber: 273
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										value: loginForm.userId,
										onChange: (e) => setLoginForm({
											...loginForm,
											userId: e.target.value
										})
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 422,
										columnNumber: 292
									}, this),
									loginErrors.userId && /* @__PURE__ */ _jsxDEV("strong", {
										className: "field-error",
										children: loginErrors.userId
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 422,
										columnNumber: 422
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 422,
								columnNumber: 248
							}, this),
							/* @__PURE__ */ _jsxDEV("label", {
								className: "field",
								children: [
									/* @__PURE__ */ _jsxDEV("span", { children: "パスワード" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 422,
										columnNumber: 517
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: "password",
										value: loginForm.password,
										onChange: (e) => setLoginForm({
											...loginForm,
											password: e.target.value
										})
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 422,
										columnNumber: 535
									}, this),
									loginErrors.password && /* @__PURE__ */ _jsxDEV("strong", {
										className: "field-error",
										children: loginErrors.password
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 422,
										columnNumber: 687
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 422,
								columnNumber: 492
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								className: "primary-button",
								disabled: isSaving,
								children: isSaving ? "ログイン中" : "ログイン"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 422,
								columnNumber: 759
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 422,
						columnNumber: 214
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "hint",
						children: "初期ユーザー: admin / password123"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 422,
						columnNumber: 873
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 422,
				columnNumber: 47
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 422,
			columnNumber: 12
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "app-shell",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "app-header",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
					className: "eyebrow",
					children: [
						currentUser.displayName,
						" / ",
						currentUser.role === "admin" ? "管理者" : "一般ユーザー"
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 427,
					columnNumber: 43
				}, this), /* @__PURE__ */ _jsxDEV("h1", { children: "MemoPad" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 427,
					columnNumber: 147
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 427,
					columnNumber: 38
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "header-actions",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "primary-button",
							onClick: startCreate,
							children: "新規作成"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 427,
							columnNumber: 201
						}, this),
						currentUser.role === "admin" && /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "ghost-button",
							onClick: openUserList,
							children: "ユーザー管理"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 427,
							columnNumber: 318
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "ghost-button",
							onClick: logout,
							children: "ログアウト"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 427,
							columnNumber: 404
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 427,
					columnNumber: 169
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 427,
				columnNumber: 7
			}, this),
			message && /* @__PURE__ */ _jsxDEV("div", {
				className: "notice success",
				children: message
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 428,
				columnNumber: 19
			}, this),
			globalError && /* @__PURE__ */ _jsxDEV("div", {
				className: "notice error",
				children: globalError
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 428,
				columnNumber: 83
			}, this),
			mode === "users" && currentUser.role === "admin" && /* @__PURE__ */ _jsxDEV("section", {
				className: "workspace",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "section-heading",
					children: [/* @__PURE__ */ _jsxDEV("h2", { children: "ユーザー管理" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 430,
						columnNumber: 124
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "form-actions",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "primary-button",
							onClick: startUserCreate,
							children: "ユーザー作成"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 430,
							columnNumber: 169
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "ghost-button",
							onClick: () => setMode("list"),
							children: "メモ一覧へ戻る"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 430,
							columnNumber: 259
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 430,
						columnNumber: 139
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 430,
					columnNumber: 91
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "user-table",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "user-row user-head",
						children: [
							/* @__PURE__ */ _jsxDEV("span", { children: "ユーザーID" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 430,
								columnNumber: 430
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "表示名" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 430,
								columnNumber: 449
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "メール" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 430,
								columnNumber: 465
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "権限" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 430,
								columnNumber: 481
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "状態" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 430,
								columnNumber: 496
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "操作" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 430,
								columnNumber: 511
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 430,
						columnNumber: 394
					}, this), users.map((user) => /* @__PURE__ */ _jsxDEV("div", {
						className: "user-row",
						children: [
							/* @__PURE__ */ _jsxDEV("span", { children: user.userId }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 430,
								columnNumber: 593
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: user.displayName }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 430,
								columnNumber: 619
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: user.email }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 430,
								columnNumber: 650
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: user.role === "admin" ? "管理者" : "一般ユーザー" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 430,
								columnNumber: 675
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: user.status === "active" ? "有効" : "無効" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 430,
								columnNumber: 730
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "row-actions",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => startUserEdit(user),
									children: "編集"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 430,
									columnNumber: 813
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: "danger-button",
									disabled: user.status === "disabled",
									onClick: () => disableUser(user),
									children: "無効化"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 430,
									columnNumber: 882
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 430,
								columnNumber: 783
							}, this)
						]
					}, user.id, true, {
						fileName: _jsxFileName,
						lineNumber: 430,
						columnNumber: 553
					}, this))]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 430,
					columnNumber: 366
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 430,
				columnNumber: 60
			}, this),
			mode === "userForm" && currentUser.role === "admin" && /* @__PURE__ */ _jsxDEV("section", {
				className: "workspace form-panel",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "section-heading",
					children: [/* @__PURE__ */ _jsxDEV("h2", { children: selectedUser ? "ユーザー編集" : "ユーザー作成" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 432,
						columnNumber: 138
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "ghost-button",
						onClick: () => setMode("users"),
						children: "キャンセル"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 432,
						columnNumber: 183
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 432,
					columnNumber: 105
				}, this), /* @__PURE__ */ _jsxDEV("form", {
					onSubmit: saveUser,
					noValidate: true,
					children: [
						/* @__PURE__ */ _jsxDEV("label", {
							className: "field",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: "ユーザーID" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 432,
									columnNumber: 345
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									value: userForm.userId,
									disabled: Boolean(selectedUser),
									onChange: (e) => setUserForm({
										...userForm,
										userId: e.target.value
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 432,
									columnNumber: 364
								}, this),
								userErrors.userId && /* @__PURE__ */ _jsxDEV("strong", {
									className: "field-error",
									children: userErrors.userId
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 432,
									columnNumber: 523
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 432,
							columnNumber: 320
						}, this),
						/* @__PURE__ */ _jsxDEV("label", {
							className: "field",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: "表示名" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 432,
									columnNumber: 617
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									value: userForm.displayName,
									onChange: (e) => setUserForm({
										...userForm,
										displayName: e.target.value
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 432,
									columnNumber: 633
								}, this),
								userErrors.displayName && /* @__PURE__ */ _jsxDEV("strong", {
									className: "field-error",
									children: userErrors.displayName
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 432,
									columnNumber: 774
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 432,
							columnNumber: 592
						}, this),
						/* @__PURE__ */ _jsxDEV("label", {
							className: "field",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: "メールアドレス" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 432,
									columnNumber: 873
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									value: userForm.email,
									onChange: (e) => setUserForm({
										...userForm,
										email: e.target.value
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 432,
									columnNumber: 893
								}, this),
								userErrors.email && /* @__PURE__ */ _jsxDEV("strong", {
									className: "field-error",
									children: userErrors.email
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 432,
									columnNumber: 1016
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 432,
							columnNumber: 848
						}, this),
						/* @__PURE__ */ _jsxDEV("label", {
							className: "field",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: ["パスワード", selectedUser ? "（変更時のみ入力）" : ""] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 432,
									columnNumber: 1109
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									type: "password",
									value: userForm.password,
									onChange: (e) => setUserForm({
										...userForm,
										password: e.target.value
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 432,
									columnNumber: 1160
								}, this),
								userErrors.password && /* @__PURE__ */ _jsxDEV("strong", {
									className: "field-error",
									children: userErrors.password
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 432,
									columnNumber: 1308
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 432,
							columnNumber: 1084
						}, this),
						/* @__PURE__ */ _jsxDEV("label", {
							className: "field",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: "権限" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 432,
									columnNumber: 1404
								}, this),
								/* @__PURE__ */ _jsxDEV("select", {
									value: userForm.role,
									onChange: (e) => setUserForm({
										...userForm,
										role: e.target.value
									}),
									children: [/* @__PURE__ */ _jsxDEV("option", {
										value: "user",
										children: "一般ユーザー"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 432,
										columnNumber: 1518
									}, this), /* @__PURE__ */ _jsxDEV("option", {
										value: "admin",
										children: "管理者"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 432,
										columnNumber: 1554
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 432,
									columnNumber: 1419
								}, this),
								userErrors.role && /* @__PURE__ */ _jsxDEV("strong", {
									className: "field-error",
									children: userErrors.role
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 432,
									columnNumber: 1617
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 432,
							columnNumber: 1379
						}, this),
						selectedUser && /* @__PURE__ */ _jsxDEV("label", {
							className: "field",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "状態" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 432,
								columnNumber: 1726
							}, this), /* @__PURE__ */ _jsxDEV("select", {
								value: userForm.status,
								onChange: (e) => setUserForm({
									...userForm,
									status: e.target.value
								}),
								children: [/* @__PURE__ */ _jsxDEV("option", {
									value: "active",
									children: "有効"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 432,
									columnNumber: 1844
								}, this), /* @__PURE__ */ _jsxDEV("option", {
									value: "disabled",
									children: "無効"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 432,
									columnNumber: 1878
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 432,
								columnNumber: 1741
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 432,
							columnNumber: 1701
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "form-actions",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								className: "primary-button",
								disabled: isSaving,
								children: isSaving ? "保存中" : selectedUser ? "更新" : "登録"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 432,
								columnNumber: 1962
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								className: "ghost-button",
								onClick: () => setMode("users"),
								children: "キャンセル"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 432,
								columnNumber: 2087
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 432,
							columnNumber: 1932
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 432,
					columnNumber: 283
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 432,
				columnNumber: 63
			}, this),
			mode === "list" && /* @__PURE__ */ _jsxDEV("section", {
				className: "workspace",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "toolbar stackable",
						children: [
							/* @__PURE__ */ _jsxDEV("label", {
								className: "search-field",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "検索" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 434,
									columnNumber: 125
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									value: filters.keyword,
									onChange: (e) => updateFilters({ keyword: e.target.value }),
									placeholder: "タイトル・本文を検索"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 434,
									columnNumber: 140
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 434,
								columnNumber: 93
							}, this),
							/* @__PURE__ */ _jsxDEV("label", {
								className: "select-field",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "表示件数" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 434,
									columnNumber: 299
								}, this), /* @__PURE__ */ _jsxDEV("select", {
									value: filters.limit,
									onChange: (e) => updateFilters({ limit: Number(e.target.value) }),
									children: [
										/* @__PURE__ */ _jsxDEV("option", {
											value: "10",
											children: "10件"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 434,
											columnNumber: 413
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "25",
											children: "25件"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 434,
											columnNumber: 444
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "50",
											children: "50件"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 434,
											columnNumber: 475
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 434,
									columnNumber: 316
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 434,
								columnNumber: 267
							}, this),
							/* @__PURE__ */ _jsxDEV("label", {
								className: "select-field",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "並び替え" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 434,
									columnNumber: 555
								}, this), /* @__PURE__ */ _jsxDEV("select", {
									value: filters.sortBy,
									onChange: (e) => updateFilters({ sortBy: e.target.value }),
									children: [
										/* @__PURE__ */ _jsxDEV("option", {
											value: "updatedAt",
											children: "更新日時"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 434,
											columnNumber: 663
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "createdAt",
											children: "作成日時"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 434,
											columnNumber: 702
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "title",
											children: "タイトル"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 434,
											columnNumber: 741
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 434,
									columnNumber: 572
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 434,
								columnNumber: 523
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "segmented",
								"aria-label": "昇順降順",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: filters.order === "desc" ? "active" : "",
									onClick: () => updateFilters({ order: "desc" }),
									children: "降順"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 434,
									columnNumber: 838
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: filters.order === "asc" ? "active" : "",
									onClick: () => updateFilters({ order: "asc" }),
									children: "昇順"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 434,
									columnNumber: 973
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 434,
								columnNumber: 793
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 434,
						columnNumber: 58
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "toolbar compact-toolbar",
						children: [
							/* @__PURE__ */ _jsxDEV("label", {
								className: "check-field",
								children: [/* @__PURE__ */ _jsxDEV("input", {
									type: "checkbox",
									checked: filters.favorite,
									onChange: (e) => updateFilters({ favorite: e.target.checked })
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 434,
									columnNumber: 1190
								}, this), " お気に入りのみ"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 434,
								columnNumber: 1159
							}, this),
							/* @__PURE__ */ _jsxDEV("label", {
								className: "select-field",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "タグ" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 434,
									columnNumber: 1354
								}, this), /* @__PURE__ */ _jsxDEV("select", {
									value: filters.tag,
									onChange: (e) => updateFilters({ tag: e.target.value }),
									children: [/* @__PURE__ */ _jsxDEV("option", {
										value: "",
										children: "すべて"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 434,
										columnNumber: 1454
									}, this), tags.map((tag) => /* @__PURE__ */ _jsxDEV("option", {
										value: tag.normalizedName,
										children: tag.name
									}, tag.normalizedName, false, {
										fileName: _jsxFileName,
										lineNumber: 434,
										columnNumber: 1502
									}, this))]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 434,
									columnNumber: 1369
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 434,
								columnNumber: 1322
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "segmented",
								"aria-label": "表示切り替え",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: displayMode === "list" ? "active" : "",
									onClick: () => setDisplayMode("list"),
									children: "一覧"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 434,
									columnNumber: 1647
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: displayMode === "compact" ? "active" : "",
									onClick: () => setDisplayMode("compact"),
									children: "コンパクト"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 434,
									columnNumber: 1770
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 434,
								columnNumber: 1600
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 434,
						columnNumber: 1118
					}, this),
					isLoading && /* @__PURE__ */ _jsxDEV("p", {
						className: "empty-state",
						children: "読み込み中です。"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 434,
						columnNumber: 1928
					}, this),
					!isLoading && total === 0 && !filters.keyword && !filters.favorite && /* @__PURE__ */ _jsxDEV("p", {
						className: "empty-state",
						children: "メモが登録されていません。"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 434,
						columnNumber: 2039
					}, this),
					!isLoading && total === 0 && (filters.keyword || filters.favorite) && /* @__PURE__ */ _jsxDEV("p", {
						className: "empty-state",
						children: "条件に一致するメモがありません。"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 434,
						columnNumber: 2155
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: displayMode === "compact" ? "memo-list compact" : "memo-list",
						children: memos.map((memo) => /* @__PURE__ */ _jsxDEV("article", {
							className: "memo-item",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "memo-main",
								children: [
									/* @__PURE__ */ _jsxDEV("h2", { children: memo.title }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 434,
										columnNumber: 2375
									}, this),
									displayMode === "list" && /* @__PURE__ */ _jsxDEV("p", {
										className: "memo-preview",
										children: memo.body.slice(0, 50)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 434,
										columnNumber: 2423
									}, this),
									memo.tags?.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
										className: "tag-list",
										children: memo.tags.map((tag) => /* @__PURE__ */ _jsxDEV("span", {
											className: "tag-chip",
											children: tag
										}, tag, false, {
											fileName: _jsxFileName,
											lineNumber: 434,
											columnNumber: 2556
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 434,
										columnNumber: 2506
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "memo-date",
										children: ["更新日時 ", formatDate(memo.updatedAt)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 434,
										columnNumber: 2614
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 434,
								columnNumber: 2348
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "memo-actions",
								children: [
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => toggleFavorite(memo),
										children: memo.isFavorite ? "お気に入り解除" : "お気に入り"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 434,
										columnNumber: 2712
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => showDetail(memo),
										children: "詳細"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 434,
										columnNumber: 2819
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => startEdit(memo),
										children: "編集"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 434,
										columnNumber: 2885
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										className: "danger-button",
										onClick: () => deleteMemo(memo),
										children: "削除"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 434,
										columnNumber: 2950
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 434,
								columnNumber: 2682
							}, this)]
						}, memo.id, true, {
							fileName: _jsxFileName,
							lineNumber: 434,
							columnNumber: 2303
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 434,
						columnNumber: 2203
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "pagination",
						children: [
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								disabled: filters.page <= 1,
								onClick: () => updateFilters({ page: filters.page - 1 }),
								children: "前へ"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 434,
								columnNumber: 3094
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: [
								filters.page,
								" / ",
								pageCount
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 434,
								columnNumber: 3214
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								disabled: filters.page >= pageCount,
								onClick: () => updateFilters({ page: filters.page + 1 }),
								children: "次へ"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 434,
								columnNumber: 3255
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 434,
						columnNumber: 3066
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 434,
				columnNumber: 27
			}, this),
			(mode === "create" || mode === "edit") && /* @__PURE__ */ _jsxDEV("section", {
				className: "workspace form-panel",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "section-heading",
					children: [/* @__PURE__ */ _jsxDEV("h2", { children: mode === "create" ? "メモ新規作成" : "メモ編集" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 436,
						columnNumber: 125
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "ghost-button",
						onClick: cancelMemoForm,
						children: "キャンセル"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 436,
						columnNumber: 173
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 436,
					columnNumber: 92
				}, this), /* @__PURE__ */ _jsxDEV("form", {
					onSubmit: saveMemo,
					noValidate: true,
					children: [
						/* @__PURE__ */ _jsxDEV("label", {
							className: "field",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: "タイトル" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 436,
									columnNumber: 327
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									value: memoForm.title,
									maxLength: 120,
									onChange: (e) => setMemoField("title", e.target.value)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 436,
									columnNumber: 344
								}, this),
								/* @__PURE__ */ _jsxDEV("small", { children: [memoForm.title.length, "/100"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 436,
									columnNumber: 448
								}, this),
								formErrors.title && /* @__PURE__ */ _jsxDEV("strong", {
									className: "field-error",
									children: formErrors.title
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 436,
									columnNumber: 511
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 436,
							columnNumber: 302
						}, this),
						/* @__PURE__ */ _jsxDEV("label", {
							className: "field",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: "本文" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 436,
									columnNumber: 604
								}, this),
								/* @__PURE__ */ _jsxDEV("textarea", {
									value: memoForm.body,
									rows: "12",
									maxLength: 2100,
									onChange: (e) => setMemoField("body", e.target.value)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 436,
									columnNumber: 619
								}, this),
								/* @__PURE__ */ _jsxDEV("small", { children: [memoForm.body.length, "/2000"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 436,
									columnNumber: 735
								}, this),
								formErrors.body && /* @__PURE__ */ _jsxDEV("strong", {
									className: "field-error",
									children: formErrors.body
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 436,
									columnNumber: 797
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 436,
							columnNumber: 579
						}, this),
						/* @__PURE__ */ _jsxDEV("label", {
							className: "field",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: "タグ" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 436,
									columnNumber: 889
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									value: memoForm.tagsText,
									onChange: (e) => setMemoField("tagsText", e.target.value),
									placeholder: "例: 仕事, 重要"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 436,
									columnNumber: 904
								}, this),
								/* @__PURE__ */ _jsxDEV("small", { children: "カンマ区切り、最大10個、各30文字以内" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 436,
									columnNumber: 1022
								}, this),
								formErrors.tags && /* @__PURE__ */ _jsxDEV("strong", {
									className: "field-error",
									children: formErrors.tags
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 436,
									columnNumber: 1077
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 436,
							columnNumber: 864
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "file-grid",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "field",
								children: [
									/* @__PURE__ */ _jsxDEV("span", { children: "添付ファイル" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 436,
										columnNumber: 1196
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: "file",
										multiple: true,
										accept: ".pdf,.txt,.csv,.docx,.xlsx",
										onChange: (e) => addPendingFiles(e, "attachment")
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 436,
										columnNumber: 1215
									}, this),
									/* @__PURE__ */ _jsxDEV("small", { children: "最大5件、1ファイル10MB以内" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 436,
										columnNumber: 1332
									}, this),
									fileErrors.attachments && /* @__PURE__ */ _jsxDEV("strong", {
										className: "field-error",
										children: fileErrors.attachments
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 436,
										columnNumber: 1390
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 436,
								columnNumber: 1171
							}, this), /* @__PURE__ */ _jsxDEV("label", {
								className: "field",
								children: [
									/* @__PURE__ */ _jsxDEV("span", { children: "画像" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 436,
										columnNumber: 1489
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: "file",
										multiple: true,
										accept: ".jpg,.jpeg,.png,.gif,.webp",
										onChange: (e) => addPendingFiles(e, "image")
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 436,
										columnNumber: 1504
									}, this),
									/* @__PURE__ */ _jsxDEV("small", { children: "最大10枚、1ファイル5MB以内" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 436,
										columnNumber: 1616
									}, this),
									fileErrors.images && /* @__PURE__ */ _jsxDEV("strong", {
										className: "field-error",
										children: fileErrors.images
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 436,
										columnNumber: 1669
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 436,
								columnNumber: 1464
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 436,
							columnNumber: 1144
						}, this),
						selectedMemo?.attachments?.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
							className: "file-list",
							children: [/* @__PURE__ */ _jsxDEV("h3", { children: "登録済み添付ファイル" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 436,
								columnNumber: 1813
							}, this), selectedMemo.attachments.map((file) => /* @__PURE__ */ _jsxDEV("div", {
								className: "file-row",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: [
									file.originalName,
									" (",
									formatSize(file.size),
									")"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 436,
									columnNumber: 1912
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "row-actions",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => downloadFile(file),
										children: "ダウンロード"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 436,
										columnNumber: 1999
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										className: "danger-button",
										onClick: () => deleteExistingFile(file),
										children: "削除"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 436,
										columnNumber: 2071
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 436,
									columnNumber: 1970
								}, this)]
							}, file.id, true, {
								fileName: _jsxFileName,
								lineNumber: 436,
								columnNumber: 1872
							}, this))]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 436,
							columnNumber: 1786
						}, this),
						selectedMemo?.images?.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
							className: "image-grid",
							children: [/* @__PURE__ */ _jsxDEV("h3", { children: "登録済み画像" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 436,
								columnNumber: 2257
							}, this), selectedMemo.images.map((file) => /* @__PURE__ */ _jsxDEV("div", {
								className: "image-card",
								children: [
									imageUrls[file.id] ? /* @__PURE__ */ _jsxDEV("img", {
										src: imageUrls[file.id],
										alt: file.originalName
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 436,
										columnNumber: 2371
									}, this) : /* @__PURE__ */ _jsxDEV("div", {
										className: "image-placeholder",
										children: "プレビューできません"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 436,
										columnNumber: 2430
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: file.originalName }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 436,
										columnNumber: 2482
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "row-actions",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => downloadFile(file),
											children: "ダウンロード"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 436,
											columnNumber: 2543
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											className: "danger-button",
											onClick: () => deleteExistingFile(file),
											children: "削除"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 436,
											columnNumber: 2615
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 436,
										columnNumber: 2514
									}, this)
								]
							}, file.id, true, {
								fileName: _jsxFileName,
								lineNumber: 436,
								columnNumber: 2307
							}, this))]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 436,
							columnNumber: 2229
						}, this),
						pendingAttachments.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
							className: "file-list",
							children: [/* @__PURE__ */ _jsxDEV("h3", { children: "追加予定の添付ファイル" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 436,
								columnNumber: 2797
							}, this), pendingAttachments.map((file, index) => /* @__PURE__ */ _jsxDEV("div", {
								className: "file-row",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: [
									file.name,
									" (",
									formatSize(file.size),
									")"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 436,
									columnNumber: 2914
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: "danger-button",
									onClick: () => removePendingFile(index, "attachment"),
									children: "削除"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 436,
									columnNumber: 2964
								}, this)]
							}, file.name + "-" + index, true, {
								fileName: _jsxFileName,
								lineNumber: 436,
								columnNumber: 2858
							}, this))]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 436,
							columnNumber: 2770
						}, this),
						pendingImages.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
							className: "image-grid",
							children: [/* @__PURE__ */ _jsxDEV("h3", { children: "追加予定の画像" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 436,
								columnNumber: 3150
							}, this), pendingImages.map((file, index) => /* @__PURE__ */ _jsxDEV("div", {
								className: "image-card",
								children: [
									/* @__PURE__ */ _jsxDEV("img", {
										src: URL.createObjectURL(file),
										alt: file.name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 436,
										columnNumber: 3260
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: file.name }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 436,
										columnNumber: 3315
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										className: "danger-button",
										onClick: () => removePendingFile(index, "image"),
										children: "削除"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 436,
										columnNumber: 3339
									}, this)
								]
							}, file.name + "-" + index, true, {
								fileName: _jsxFileName,
								lineNumber: 436,
								columnNumber: 3202
							}, this))]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 436,
							columnNumber: 3122
						}, this),
						draftStatus && /* @__PURE__ */ _jsxDEV("p", {
							className: "draft-status",
							children: draftStatus
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 436,
							columnNumber: 3479
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "form-actions",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								className: "primary-button",
								disabled: isSaving,
								children: isSaving ? "保存中" : mode === "create" ? "登録" : "更新"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 436,
								columnNumber: 3555
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								className: "ghost-button",
								onClick: cancelMemoForm,
								children: "キャンセル"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 436,
								columnNumber: 3685
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 436,
							columnNumber: 3525
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 436,
					columnNumber: 265
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 436,
				columnNumber: 50
			}, this),
			mode === "detail" && selectedMemo && /* @__PURE__ */ _jsxDEV("section", {
				className: "workspace detail-panel",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "section-heading",
						children: [/* @__PURE__ */ _jsxDEV("h2", { children: selectedMemo.title }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 438,
							columnNumber: 122
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "ghost-button",
							onClick: () => setMode("list"),
							children: "一覧へ戻る"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 438,
							columnNumber: 151
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 438,
						columnNumber: 89
					}, this),
					selectedMemo.tags?.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
						className: "tag-list detail-tags",
						children: selectedMemo.tags.map((tag) => /* @__PURE__ */ _jsxDEV("span", {
							className: "tag-chip",
							children: tag
						}, tag, false, {
							fileName: _jsxFileName,
							lineNumber: 438,
							columnNumber: 354
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 438,
						columnNumber: 284
					}, this),
					selectedMemo.attachments?.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
						className: "file-list",
						children: [/* @__PURE__ */ _jsxDEV("h3", { children: "添付ファイル" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 438,
							columnNumber: 480
						}, this), selectedMemo.attachments.map((file) => /* @__PURE__ */ _jsxDEV("div", {
							className: "file-row",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: [
								file.originalName,
								" (",
								formatSize(file.size),
								")"
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 438,
								columnNumber: 575
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "row-actions",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => downloadFile(file),
									children: "ダウンロード"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 438,
									columnNumber: 662
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: "danger-button",
									onClick: () => deleteExistingFile(file),
									children: "削除"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 438,
									columnNumber: 734
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 438,
								columnNumber: 633
							}, this)]
						}, file.id, true, {
							fileName: _jsxFileName,
							lineNumber: 438,
							columnNumber: 535
						}, this))]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 438,
						columnNumber: 453
					}, this),
					selectedMemo.images?.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
						className: "image-grid",
						children: [/* @__PURE__ */ _jsxDEV("h3", { children: "画像" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 438,
							columnNumber: 919
						}, this), selectedMemo.images.map((file) => /* @__PURE__ */ _jsxDEV("div", {
							className: "image-card",
							children: [
								imageUrls[file.id] ? /* @__PURE__ */ _jsxDEV("img", {
									src: imageUrls[file.id],
									alt: file.originalName
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 438,
									columnNumber: 1029
								}, this) : /* @__PURE__ */ _jsxDEV("div", {
									className: "image-placeholder",
									children: "プレビューできません"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 438,
									columnNumber: 1088
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: file.originalName }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 438,
									columnNumber: 1140
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "row-actions",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => downloadFile(file),
										children: "ダウンロード"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 438,
										columnNumber: 1201
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										className: "danger-button",
										onClick: () => deleteExistingFile(file),
										children: "削除"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 438,
										columnNumber: 1273
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 438,
									columnNumber: 1172
								}, this)
							]
						}, file.id, true, {
							fileName: _jsxFileName,
							lineNumber: 438,
							columnNumber: 965
						}, this))]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 438,
						columnNumber: 891
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "memo-body",
						children: selectedMemo.body
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 438,
						columnNumber: 1394
					}, this),
					/* @__PURE__ */ _jsxDEV("dl", {
						className: "date-grid",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "作成日時" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 438,
							columnNumber: 1473
						}, this), /* @__PURE__ */ _jsxDEV("dd", { children: formatDate(selectedMemo.createdAt) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 438,
							columnNumber: 1486
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 438,
							columnNumber: 1468
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "更新日時" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 438,
							columnNumber: 1542
						}, this), /* @__PURE__ */ _jsxDEV("dd", { children: formatDate(selectedMemo.updatedAt) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 438,
							columnNumber: 1555
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 438,
							columnNumber: 1537
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 438,
						columnNumber: 1442
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "form-actions",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => startEdit(selectedMemo),
							children: "編集"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 438,
							columnNumber: 1641
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "danger-button",
							onClick: () => deleteMemo(selectedMemo),
							children: "削除"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 438,
							columnNumber: 1714
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 438,
						columnNumber: 1611
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 438,
				columnNumber: 45
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 426,
		columnNumber: 5
	}, this);
}
_s(App, "pT+ytzi2R+nNY0D7xR0EgxObmqw=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/ai-Coding-traning/MemoPad_hands-on/client/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/ai-Coding-traning/MemoPad_hands-on/client/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/ai-Coding-traning/MemoPad_hands-on/client/src/App.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUMsU0FBUyxXQUFXLFNBQVMsUUFBUSxnQkFBZ0I7QUFDdEQsT0FBTzs7OztBQUVQLE1BQU0sV0FBVztBQUNqQixNQUFNLFlBQVk7Q0FBRSxPQUFPO0NBQUksTUFBTTtDQUFJLFVBQVU7QUFBRztBQUN0RCxNQUFNLFlBQVk7Q0FBRSxRQUFRO0NBQUksYUFBYTtDQUFJLE9BQU87Q0FBSSxVQUFVO0NBQUksTUFBTTtDQUFRLFFBQVE7QUFBUztBQUN6RyxNQUFNLGlCQUFpQjtDQUFFLFNBQVM7Q0FBSSxNQUFNO0NBQUcsT0FBTztDQUFJLFFBQVE7Q0FBYSxPQUFPO0NBQVEsVUFBVTtDQUFPLEtBQUs7QUFBRztBQUV2SCxTQUFTLFdBQVcsT0FBTztDQUN6QixJQUFJLENBQUMsT0FBTyxPQUFPO0NBQ25CLE1BQU0sT0FBTyxJQUFJLEtBQUssS0FBSztDQUMzQixJQUFJLE9BQU8sTUFBTSxLQUFLLFFBQVEsQ0FBQyxHQUFHLE9BQU87Q0FDekMsTUFBTSxPQUFPLFFBQVEsT0FBTyxHQUFHLENBQUMsQ0FBQyxTQUFTLEdBQUcsR0FBRztDQUNoRCxPQUFPLEdBQUcsS0FBSyxZQUFZLEVBQUUsR0FBRyxJQUFJLEtBQUssU0FBUyxJQUFJLENBQUMsRUFBRSxHQUFHLElBQUksS0FBSyxRQUFRLENBQUMsRUFBRSxHQUFHLElBQUksS0FBSyxTQUFTLENBQUMsRUFBRSxHQUFHLElBQUksS0FBSyxXQUFXLENBQUMsRUFBRSxHQUFHLElBQUksS0FBSyxXQUFXLENBQUM7QUFDNUo7QUFHQSxTQUFTLFdBQVcsTUFBTTtDQUN4QixJQUFJLENBQUMsTUFBTSxPQUFPO0NBQ2xCLElBQUksUUFBUSxPQUFPLE1BQU0sUUFBUSxPQUFPLE9BQU8sS0FBSSxDQUFFLFFBQVEsQ0FBQyxJQUFJO0NBQ2xFLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLE9BQU8sSUFBSSxDQUFDLElBQUk7QUFDaEQ7QUFFQSxTQUFTLGFBQWEsTUFBTTtDQUMxQixNQUFNLFFBQVEsT0FBTyxRQUFRLEVBQUUsQ0FBQyxDQUFDLE1BQU0sR0FBRztDQUMxQyxPQUFPLE1BQU0sU0FBUyxJQUFJLE1BQU0sSUFBSSxDQUFDLENBQUMsWUFBWSxJQUFJO0FBQ3hEO0FBRUEsU0FBUyxzQkFBc0IsT0FBTyxlQUFlLE1BQU07Q0FDekQsTUFBTSxTQUFTLENBQUM7Q0FDaEIsTUFBTSxPQUFPLE1BQU0sS0FBSyxTQUFTLENBQUMsQ0FBQztDQUNuQyxNQUFNLFVBQVUsU0FBUztDQUN6QixNQUFNLFVBQVUsVUFBVTtFQUFDO0VBQU87RUFBUTtFQUFPO0VBQU87Q0FBTSxJQUFJO0VBQUM7RUFBTztFQUFPO0VBQU87RUFBUTtDQUFNO0NBQ3RHLE1BQU0sV0FBVyxVQUFVLEtBQUs7Q0FDaEMsTUFBTSxVQUFVLFVBQVUsSUFBSSxPQUFPLE9BQU8sS0FBSyxPQUFPO0NBQ3hELE1BQU0sTUFBTSxVQUFVLFdBQVc7Q0FDakMsSUFBSSxnQkFBZ0IsS0FBSyxTQUFTLFVBQVUsT0FBTyxPQUFPLFVBQVUsdUJBQXVCO0NBQzNGLEtBQUssTUFBTSxRQUFRLE1BQU07RUFDdkIsSUFBSSxDQUFDLFFBQVEsU0FBUyxhQUFhLEtBQUssSUFBSSxDQUFDLEdBQUcsT0FBTyxPQUFPLFVBQVUsaURBQWlEO0VBQ3pILElBQUksS0FBSyxPQUFPLFNBQVMsT0FBTyxPQUFPLFVBQVUsNEJBQTRCO0NBQy9FO0NBQ0EsT0FBTztBQUNUO0FBRUEsU0FBUyxhQUFhLE1BQU07Q0FDMUIsT0FBTyxJQUFJLFNBQVMsU0FBUyxXQUFXO0VBQ3RDLE1BQU0sU0FBUyxJQUFJLFdBQVc7RUFDOUIsT0FBTyxlQUFlLFFBQVE7R0FBRSxNQUFNLEtBQUs7R0FBTSxNQUFNLEtBQUssUUFBUTtHQUE0QixNQUFNLEtBQUs7R0FBTSxTQUFTLE9BQU87RUFBTyxDQUFDO0VBQ3pJLE9BQU8sVUFBVTtFQUNqQixPQUFPLGNBQWMsSUFBSTtDQUMzQixDQUFDO0FBQ0g7QUFFQSxTQUFTLGFBQWEsTUFBTTtDQUMxQixNQUFNLFNBQVMsQ0FBQztDQUNoQixJQUFJLENBQUMsS0FBSyxTQUFTLEtBQUssTUFBTSxLQUFLLENBQUMsQ0FBQyxXQUFXLEdBQUcsT0FBTyxRQUFRO01BQzdELElBQUksS0FBSyxNQUFNLFNBQVMsS0FBSyxPQUFPLFFBQVE7Q0FDakQsSUFBSSxDQUFDLEtBQUssUUFBUSxLQUFLLEtBQUssS0FBSyxDQUFDLENBQUMsV0FBVyxHQUFHLE9BQU8sT0FBTztNQUMxRCxJQUFJLEtBQUssS0FBSyxTQUFTLEtBQU0sT0FBTyxPQUFPO0NBQ2hELE9BQU87QUFDVDtBQUVBLFNBQVMsY0FBYyxNQUFNO0NBQzNCLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLElBQUksQ0FBQyxLQUFLLE9BQU8sS0FBSyxHQUFHLE9BQU8sU0FBUztNQUNwQyxJQUFJLENBQUMsbUJBQW1CLEtBQUssS0FBSyxNQUFNLEdBQUcsT0FBTyxTQUFTO01BQzNELElBQUksS0FBSyxPQUFPLFNBQVMsS0FBSyxLQUFLLE9BQU8sU0FBUyxJQUFJLE9BQU8sU0FBUztDQUM1RSxJQUFJLENBQUMsS0FBSyxVQUFVLE9BQU8sV0FBVztNQUNqQyxJQUFJLEtBQUssU0FBUyxTQUFTLEtBQUssS0FBSyxTQUFTLFNBQVMsSUFBSSxPQUFPLFdBQVc7Q0FDbEYsT0FBTztBQUNUO0FBRUEsU0FBUyxNQUFNOztDQUNiLE1BQU0sQ0FBQyxPQUFPLFlBQVksZUFBZSxhQUFhLFFBQVEsY0FBYyxLQUFLLEVBQUU7Q0FDbkYsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsSUFBSTtDQUNuRCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUztFQUFFLFFBQVE7RUFBUyxVQUFVO0NBQWMsQ0FBQztDQUN2RixNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxDQUFDLENBQUM7Q0FDakQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLENBQUMsQ0FBQztDQUNyQyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsQ0FBQztDQUNwQyxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxJQUFJO0NBQ3JELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxTQUFTO0NBQ2xELE1BQU0sQ0FBQyxvQkFBb0IseUJBQXlCLFNBQVMsQ0FBQyxDQUFDO0NBQy9ELE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLENBQUMsQ0FBQztDQUNyRCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxDQUFDLENBQUM7Q0FDL0MsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsQ0FBQyxDQUFDO0NBQzdDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxDQUFDLENBQUM7Q0FDckMsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLENBQUMsQ0FBQztDQUNuQyxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxJQUFJO0NBQ3JELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxTQUFTO0NBQ2xELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLENBQUMsQ0FBQztDQUMvQyxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsTUFBTTtDQUN2QyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxNQUFNO0NBQ3JELE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxjQUFjO0NBQ3JELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLENBQUMsQ0FBQztDQUMvQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsRUFBRTtDQUN6QyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxFQUFFO0NBQ2pELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEtBQUs7Q0FDaEQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEtBQUs7Q0FDOUMsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsRUFBRTtDQUNqRCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxLQUFLO0NBQ3BELE1BQU0sbUJBQW1CLE9BQU8sSUFBSTtDQUNwQyxNQUFNLGlCQUFpQixPQUFPLENBQUM7Q0FDL0IsTUFBTSxzQkFBc0IsT0FBTyxFQUFFO0NBRXJDLE1BQU0sY0FBYyxjQUFjLFFBQVEsRUFBRSxlQUFlLFVBQVUsUUFBUSxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQztDQUM1RixNQUFNLFlBQVksS0FBSyxJQUFJLEdBQUcsS0FBSyxLQUFLLFFBQVEsUUFBUSxLQUFLLENBQUM7Q0FFOUQsTUFBTSx3QkFBd0I7RUFDNUIsYUFBYSxXQUFXLGNBQWM7RUFDdEMsU0FBUyxFQUFFO0VBQ1gsZUFBZSxJQUFJO0VBQ25CLFFBQVEsTUFBTTtDQUNoQjtDQUVBLE1BQU0sY0FBYyxPQUFPLE1BQU0sVUFBVSxDQUFDLE1BQU07RUFDaEQsTUFBTSxXQUFXLE1BQU0sTUFBTSxHQUFHLFdBQVcsUUFBUTtHQUFFLEdBQUc7R0FBUyxTQUFTO0lBQUUsR0FBRztJQUFhLEdBQUksUUFBUSxXQUFXLENBQUM7R0FBRztFQUFFLENBQUM7RUFDMUgsTUFBTSxPQUFPLFNBQVMsV0FBVyxNQUFNLE9BQU8sTUFBTSxTQUFTLEtBQUssQ0FBQyxDQUFDLFlBQVksSUFBSTtFQUNwRixJQUFJLENBQUMsU0FBUyxJQUFJO0dBQ2hCLE1BQU0sUUFBUSxJQUFJLE1BQU0sTUFBTSxXQUFXLFFBQVE7R0FDakQsTUFBTSxTQUFTLFNBQVM7R0FDeEIsTUFBTSxPQUFPO0dBQ2IsTUFBTTtFQUNSO0VBQ0EsT0FBTztDQUNUO0NBRUEsTUFBTSxZQUFZLFlBQVk7RUFDNUIsSUFBSSxDQUFDLE9BQU87RUFDWixhQUFhLElBQUk7RUFDakIsZUFBZSxFQUFFO0VBQ2pCLElBQUk7R0FDRixNQUFNLFNBQVMsSUFBSSxnQkFBZ0I7SUFBRSxTQUFTLFFBQVE7SUFBUyxNQUFNLE9BQU8sUUFBUSxJQUFJO0lBQUcsT0FBTyxPQUFPLFFBQVEsS0FBSztJQUFHLFFBQVEsUUFBUTtJQUFRLE9BQU8sUUFBUTtJQUFPLFVBQVUsT0FBTyxRQUFRLFFBQVE7SUFBRyxLQUFLLFFBQVE7R0FBSSxDQUFDO0dBQzdOLE1BQU0sT0FBTyxNQUFNLFlBQVksVUFBVSxPQUFPLFNBQVMsR0FBRztHQUM1RCxTQUFTLEtBQUssS0FBSztHQUNuQixTQUFTLEtBQUssS0FBSztHQUNuQixNQUFNLFNBQVM7RUFDakIsU0FBUyxPQUFPO0dBQ2QsSUFBSSxNQUFNLFdBQVcsS0FBSyxnQkFBZ0I7UUFDckMsZUFBZSw4QkFBOEI7RUFDcEQsVUFBVTtHQUNSLGFBQWEsS0FBSztFQUNwQjtDQUNGO0NBSUEsTUFBTSxXQUFXLFlBQVk7RUFDM0IsSUFBSSxDQUFDLE9BQU87RUFDWixJQUFJO0dBQUUsUUFBUSxNQUFNLFlBQVksT0FBTyxDQUFDO0VBQUUsU0FDbkMsT0FBTyxDQUEwQjtDQUMxQztDQUVBLE1BQU0sWUFBWSxZQUFZO0VBQzVCLGVBQWUsRUFBRTtFQUNqQixJQUFJO0dBQ0YsU0FBUyxNQUFNLFlBQVksUUFBUSxDQUFDO0VBQ3RDLFNBQVMsT0FBTztHQUNkLElBQUksTUFBTSxXQUFXLEtBQUs7SUFDeEIsUUFBUSxNQUFNO0lBQ2QsZUFBZSxlQUFlO0dBQ2hDLE9BQU8sZUFBZSw4QkFBOEI7RUFDdEQ7Q0FDRjtDQUVBLGdCQUFnQjtFQUNkLE1BQU0sU0FBUyxZQUFZO0dBQ3pCLElBQUksQ0FBQyxPQUFPO0dBQ1osSUFBSTtJQUNGLE1BQU0sT0FBTyxNQUFNLFlBQVksS0FBSztJQUNwQyxlQUFlLEtBQUssSUFBSTtHQUMxQixTQUFTLE9BQU87SUFDZCxnQkFBZ0I7R0FDbEI7RUFDRjtFQUNBLE9BQU87Q0FDVCxHQUFHLENBQUMsS0FBSyxDQUFDO0NBRVYsZ0JBQWdCO0VBQUUsSUFBSSxhQUFhLFVBQVU7Q0FBRSxHQUFHLENBQUMsYUFBYSxPQUFPLENBQUM7Q0FFeEUsZ0JBQWdCO0VBQ2QsbUJBQW1CO0VBQ25CLElBQUksQ0FBQyxlQUFlLEVBQUUsU0FBUyxZQUFZLFNBQVMsU0FBUztFQUM3RCxJQUFJLFlBQVk7RUFDaEIsTUFBTSxZQUFZLFlBQVk7R0FDNUIsZUFBZSxFQUFFO0dBQ2pCLElBQUk7SUFDRixNQUFNLE9BQU8sTUFBTSxZQUFZLFNBQVM7SUFDeEMsSUFBSSxhQUFhLENBQUMsTUFBTSxPQUFPO0tBQzdCLG9CQUFvQixVQUFVLHNCQUFzQixrQkFBa0IsQ0FBQztLQUN2RTtJQUNGO0lBQ0EsTUFBTSxlQUFlLEtBQUssTUFBTSxVQUFVLDZDQUE2QztJQUN2RixJQUFJLE9BQU8sUUFBUSxHQUFHLGVBQWUsZUFBZSxPQUFPLEdBQUcseUJBQXlCLEdBQUc7S0FDeEYsTUFBTSxXQUFXO01BQUUsT0FBTyxLQUFLLE1BQU07TUFBTyxNQUFNLEtBQUssTUFBTTtNQUFNLFVBQVUsS0FBSyxNQUFNO0tBQVM7S0FDakcsWUFBWSxRQUFRO0tBQ3BCLGVBQWUsYUFBYTtLQUM1QixvQkFBb0IsVUFBVSxzQkFBc0I7TUFBRSxRQUFRO01BQWEsR0FBRztNQUFVLGVBQWUsY0FBYyxhQUFhO0tBQUssQ0FBQztJQUMxSSxPQUFPO0tBQ0wsTUFBTSxtQkFBbUI7S0FDekIsb0JBQW9CLFVBQVUsc0JBQXNCLGtCQUFrQixDQUFDO0lBQ3pFO0lBQ0EsZUFBZSxLQUFLO0dBQ3RCLFNBQVMsT0FBTztJQUNkLG9CQUFvQixVQUFVLHNCQUFzQixrQkFBa0IsQ0FBQztHQUN6RTtFQUNGO0VBQ0EsVUFBVTtFQUNWLGFBQWE7R0FBRSxZQUFZO0dBQU0sbUJBQW1CO0VBQUU7Q0FDeEQsR0FBRztFQUFDO0VBQWE7RUFBTSxjQUFjO0NBQUUsQ0FBQztDQUV4QyxnQkFBZ0I7RUFDZCxtQkFBbUI7RUFDbkIsSUFBSSxDQUFDLGVBQWUsRUFBRSxTQUFTLFlBQVksU0FBUyxXQUFXLFlBQVksQ0FBQyxhQUFhO0VBQ3pGLElBQUksU0FBUyxZQUFZLENBQUMsZ0JBQWdCLFFBQVEsR0FBRztFQUNyRCxNQUFNLFVBQVUsa0JBQWtCO0VBQ2xDLE1BQU0sYUFBYSxzQkFBc0IsT0FBTztFQUNoRCxJQUFJLGVBQWUsb0JBQW9CLFNBQVM7RUFDaEQsaUJBQWlCLFVBQVUsV0FBVyxZQUFZO0dBQ2hELE1BQU0sTUFBTSxlQUFlLFVBQVU7R0FDckMsZUFBZSxVQUFVO0dBQ3pCLElBQUk7SUFDRixNQUFNLE9BQU8sTUFBTSxZQUFZLFdBQVc7S0FBRSxRQUFRO0tBQVEsU0FBUyxFQUFFLGdCQUFnQixtQkFBbUI7S0FBRyxNQUFNLEtBQUssVUFBVSxPQUFPO0lBQUUsQ0FBQztJQUM1SSxJQUFJLFFBQVEsZUFBZSxTQUFTO0tBQ2xDLG9CQUFvQixVQUFVO0tBQzlCLGVBQWUsTUFBTSxXQUFXLGFBQWE7SUFDL0M7R0FDRixTQUFTLE9BQU87SUFDZCxJQUFJLFFBQVEsZUFBZSxTQUFTLGVBQWUsZUFBZTtHQUNwRTtFQUNGLEdBQUcsR0FBSTtFQUNQLE9BQU87Q0FDVCxHQUFHO0VBQUM7RUFBVTtFQUFNLGNBQWM7RUFBSSxjQUFjO0VBQVc7RUFBYTtFQUFVO0NBQVcsQ0FBQztDQUdsRyxnQkFBZ0I7RUFDZCxJQUFJLFNBQVM7RUFDYixNQUFNLE9BQU8sQ0FBQztFQUNkLE1BQU0sZ0JBQWdCLFlBQVk7R0FDaEMsTUFBTSxTQUFTLGNBQWMsVUFBVSxDQUFDO0dBQ3hDLElBQUksT0FBTyxXQUFXLEdBQUc7SUFBRSxhQUFhLENBQUMsQ0FBQztJQUFHO0dBQU87R0FDcEQsTUFBTSxVQUFVLE1BQU0sUUFBUSxJQUFJLE9BQU8sSUFBSSxPQUFPLFNBQVM7SUFDM0QsSUFBSTtLQUNGLE1BQU0sT0FBTyxNQUFNLGNBQWMsSUFBSTtLQUNyQyxNQUFNLE1BQU0sSUFBSSxnQkFBZ0IsSUFBSTtLQUNwQyxLQUFLLEtBQUssR0FBRztLQUNiLE9BQU8sQ0FBQyxLQUFLLElBQUksR0FBRztJQUN0QixTQUFTLE9BQU87S0FDZCxPQUFPLENBQUMsS0FBSyxJQUFJLEVBQUU7SUFDckI7R0FDRixDQUFDLENBQUM7R0FDRixJQUFJLFFBQVEsYUFBYSxPQUFPLFlBQVksT0FBTyxDQUFDO0VBQ3REO0VBQ0EsY0FBYztFQUNkLGFBQWE7R0FBRSxTQUFTO0dBQU8sS0FBSyxTQUFTLFFBQVEsSUFBSSxnQkFBZ0IsR0FBRyxDQUFDO0VBQUU7Q0FDakYsR0FBRztFQUFDLGNBQWM7RUFBSSxjQUFjO0VBQVE7Q0FBSyxDQUFDO0NBRWxELE1BQU0sUUFBUSxPQUFPLFVBQVU7RUFDN0IsTUFBTSxlQUFlO0VBQ3JCLE1BQU0sU0FBUyxjQUFjLFNBQVM7RUFDdEMsZUFBZSxNQUFNO0VBQ3JCLGVBQWUsRUFBRTtFQUNqQixJQUFJLE9BQU8sS0FBSyxNQUFNLENBQUMsQ0FBQyxTQUFTLEdBQUc7RUFDcEMsWUFBWSxJQUFJO0VBQ2hCLElBQUk7R0FDRixNQUFNLFdBQVcsTUFBTSxNQUFNLEdBQUcsU0FBUyxTQUFTO0lBQUUsUUFBUTtJQUFRLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0lBQUcsTUFBTSxLQUFLLFVBQVUsU0FBUztHQUFFLENBQUM7R0FDdEosTUFBTSxPQUFPLE1BQU0sU0FBUyxLQUFLLENBQUMsQ0FBQyxZQUFZLElBQUk7R0FDbkQsSUFBSSxDQUFDLFNBQVMsSUFBSSxNQUFNLElBQUksTUFBTSxNQUFNLFdBQVcsT0FBTztHQUMxRCxhQUFhLFFBQVEsZ0JBQWdCLEtBQUssS0FBSztHQUMvQyxTQUFTLEtBQUssS0FBSztHQUNuQixlQUFlLEtBQUssSUFBSTtHQUN4QixXQUFXLFdBQVc7RUFDeEIsU0FBUyxPQUFPO0dBQ2QsZUFBZSwwQkFBMEI7RUFDM0MsVUFBVTtHQUNSLFlBQVksS0FBSztFQUNuQjtDQUNGO0NBRUEsTUFBTSxTQUFTLFlBQVk7RUFDekIsSUFBSTtHQUFFLElBQUksT0FBTyxNQUFNLFlBQVksV0FBVyxFQUFFLFFBQVEsT0FBTyxDQUFDO0VBQUUsU0FBUyxPQUFPLENBQTJCO0VBQzdHLGdCQUFnQjtFQUNoQixXQUFXLEVBQUU7Q0FDZjtDQUVBLE1BQU0saUJBQWlCLFVBQVUsWUFBWSxhQUFhO0VBQUUsR0FBRztFQUFTLEdBQUc7RUFBTyxNQUFNLE1BQU0sUUFBUTtDQUFFLEVBQUU7Q0FDMUcsTUFBTSxjQUFjLFNBQVMsVUFBVSxlQUFlLGFBQWEsS0FBSztDQUN4RSxNQUFNLFlBQVksY0FBYyxpQkFBaUIsZ0JBQWdCO0NBQ2pFLE1BQU0sMkJBQTJCO0VBQUUsUUFBUTtFQUFhLE9BQU8sU0FBUztFQUFPLE1BQU0sU0FBUztFQUFNLFVBQVUsU0FBUztFQUFVLGVBQWUsY0FBYyxhQUFhO0NBQUs7Q0FDaEwsTUFBTSx5QkFBeUIsWUFBWSxLQUFLLFVBQVUsT0FBTztDQUNqRSxNQUFNLG1CQUFtQixTQUFTLFFBQVEsS0FBSyxTQUFTLEtBQUssUUFBUSxLQUFLLFFBQVE7Q0FDbEYsTUFBTSxnQkFBZ0IsT0FBTyxVQUFVO0VBQUUsYUFBYSxhQUFhO0dBQUUsR0FBRztJQUFVLFFBQVE7RUFBTSxFQUFFO0VBQUcsZUFBZSxJQUFJO0VBQUcsZUFBZSxFQUFFO0NBQUU7Q0FDOUksTUFBTSwyQkFBMkI7RUFBRSxJQUFJLGlCQUFpQixTQUFTO0dBQUUsYUFBYSxpQkFBaUIsT0FBTztHQUFHLGlCQUFpQixVQUFVO0VBQUs7Q0FBRTtDQUM3SSxNQUFNLHFCQUFxQixZQUFZO0VBQUUsSUFBSTtHQUFFLE1BQU0sWUFBWSxXQUFXLEVBQUUsUUFBUSxTQUFTLENBQUM7RUFBRSxTQUFTLE9BQU8sQ0FBMkI7Q0FBRTtDQUUvSSxNQUFNLGdCQUFnQixPQUFPLFNBQVM7RUFDcEMsTUFBTSxXQUFXLE1BQU0sTUFBTSxXQUFXLEtBQUssYUFBYSxFQUFFLFNBQVMsWUFBWSxDQUFDO0VBQ2xGLElBQUksQ0FBQyxTQUFTLElBQUksTUFBTSxJQUFJLE1BQU0sVUFBVTtFQUM1QyxPQUFPLFNBQVMsS0FBSztDQUN2QjtDQUNBLE1BQU0sZUFBZSxPQUFPLFNBQVM7RUFDbkMsSUFBSTtHQUNGLE1BQU0sT0FBTyxNQUFNLGNBQWMsSUFBSTtHQUNyQyxNQUFNLE1BQU0sSUFBSSxnQkFBZ0IsSUFBSTtHQUNwQyxNQUFNLE9BQU8sU0FBUyxjQUFjLEdBQUc7R0FDdkMsS0FBSyxPQUFPO0dBQ1osS0FBSyxXQUFXLEtBQUs7R0FDckIsU0FBUyxLQUFLLFlBQVksSUFBSTtHQUM5QixLQUFLLE1BQU07R0FDWCxLQUFLLE9BQU87R0FDWixJQUFJLGdCQUFnQixHQUFHO0VBQ3pCLFNBQVMsT0FBTztHQUNkLGVBQWUsOEJBQThCO0VBQy9DO0NBQ0Y7Q0FDQSxNQUFNLHNCQUFzQixZQUFZO0VBQ3RDLElBQUksQ0FBQyxjQUFjO0VBQ25CLE1BQU0sT0FBTyxNQUFNLFlBQVksWUFBWSxhQUFhLEVBQUU7RUFDMUQsZ0JBQWdCLElBQUk7Q0FDdEI7Q0FDQSxNQUFNLHFCQUFxQixPQUFPLFNBQVM7RUFDekMsSUFBSSxDQUFDLE9BQU8sUUFBUSxLQUFLLGVBQWUsV0FBVyxHQUFHO0VBQ3RELElBQUk7R0FDRixNQUFNLFlBQVksWUFBWSxLQUFLLElBQUksRUFBRSxRQUFRLFNBQVMsQ0FBQztHQUMzRCxNQUFNLG9CQUFvQjtHQUMxQixXQUFXLGNBQWM7RUFDM0IsU0FBUyxPQUFPO0dBQ2QsZUFBZSxNQUFNLFdBQVcsaUNBQWlDO0VBQ25FO0NBQ0Y7Q0FDQSxNQUFNLG1CQUFtQixPQUFPLFNBQVM7RUFDdkMsTUFBTSxXQUFXLE1BQU0sS0FBSyxNQUFNLE9BQU8sU0FBUyxDQUFDLENBQUM7RUFDcEQsTUFBTSxVQUFVLFNBQVM7RUFDekIsTUFBTSxnQkFBZ0IsV0FBVyxjQUFjLFVBQVUsQ0FBQyxFQUFDLENBQUUsVUFBVSxjQUFjLGVBQWUsQ0FBQyxFQUFDLENBQUU7RUFDeEcsTUFBTSxVQUFVLFVBQVUsZ0JBQWdCO0VBQzFDLE1BQU0sT0FBTyxDQUFDLEdBQUcsU0FBUyxHQUFHLFFBQVE7RUFDckMsTUFBTSxTQUFTLHNCQUFzQixNQUFNLGVBQWUsSUFBSTtFQUM5RCxNQUFNLE1BQU0sVUFBVSxXQUFXO0VBQ2pDLGVBQWUsbUJBQW1CO0dBQUUsR0FBRztJQUFnQixNQUFNLE9BQU8sUUFBUTtFQUFHLEVBQUU7RUFDakYsSUFBSSxTQUFTLGlCQUFpQixJQUFJO09BQzdCLHNCQUFzQixJQUFJO0VBQy9CLE1BQU0sT0FBTyxRQUFRO0NBQ3ZCO0NBQ0EsTUFBTSxxQkFBcUIsT0FBTyxTQUFTO0VBQ3pDLElBQUksU0FBUyxTQUFTLGtCQUFrQixZQUFZLFFBQVEsUUFBUSxHQUFHLE1BQU0sTUFBTSxLQUFLLENBQUM7T0FDcEYsdUJBQXVCLFlBQVksUUFBUSxRQUFRLEdBQUcsTUFBTSxNQUFNLEtBQUssQ0FBQztFQUM3RSxjQUFjLENBQUMsQ0FBQztDQUNsQjtDQUNBLE1BQU0sd0JBQXdCO0VBQUUsc0JBQXNCLENBQUMsQ0FBQztFQUFHLGlCQUFpQixDQUFDLENBQUM7RUFBRyxjQUFjLENBQUMsQ0FBQztFQUFHLGFBQWEsQ0FBQyxDQUFDO0NBQUU7Q0FFckgsTUFBTSxlQUFlLFlBQVk7RUFDL0IsSUFBSSxZQUFZLFNBQVMsU0FBUztHQUFFLFFBQVEsTUFBTTtHQUFHLGVBQWUsZUFBZTtHQUFHO0VBQU87RUFDN0YsUUFBUSxPQUFPO0VBQUcsV0FBVyxFQUFFO0VBQUcsY0FBYyxDQUFDLENBQUM7RUFBRyxNQUFNLFVBQVU7Q0FDdkU7Q0FDQSxNQUFNLG9CQUFvQjtFQUFFLG1CQUFtQjtFQUFHLGdCQUFnQixJQUFJO0VBQUcsWUFBWSxTQUFTO0VBQUcsZ0JBQWdCO0VBQUcsZUFBZSxLQUFLO0VBQUcsb0JBQW9CLFVBQVU7RUFBSSxlQUFlLEVBQUU7RUFBRyxjQUFjLENBQUMsQ0FBQztFQUFHLFdBQVcsRUFBRTtFQUFHLGVBQWUsRUFBRTtFQUFHLFFBQVEsUUFBUTtDQUFFO0NBQzFRLE1BQU0sWUFBWSxPQUFPLFNBQVM7RUFBRSxtQkFBbUI7RUFBRyxNQUFNLFdBQVcsS0FBSyxjQUFjLE9BQU8sTUFBTSxZQUFZLFlBQVksS0FBSyxFQUFFO0VBQUcsZ0JBQWdCLFFBQVE7RUFBRyxZQUFZO0dBQUUsT0FBTyxTQUFTO0dBQU8sTUFBTSxTQUFTO0dBQU0sV0FBVyxTQUFTLFFBQVEsQ0FBQyxFQUFDLENBQUUsS0FBSyxJQUFJO0VBQUUsQ0FBQztFQUFHLGdCQUFnQjtFQUFHLGVBQWUsS0FBSztFQUFHLG9CQUFvQixVQUFVO0VBQUksZUFBZSxFQUFFO0VBQUcsY0FBYyxDQUFDLENBQUM7RUFBRyxXQUFXLEVBQUU7RUFBRyxlQUFlLEVBQUU7RUFBRyxRQUFRLE1BQU07Q0FBRTtDQUN4YixNQUFNLGFBQWEsT0FBTyxTQUFTO0VBQ2pDLGVBQWUsRUFBRTtFQUNqQixJQUFJO0dBQUUsZ0JBQWdCLE1BQU0sWUFBWSxVQUFVLEtBQUssSUFBSSxDQUFDO0dBQUcsUUFBUSxRQUFRO0VBQUUsU0FDMUUsT0FBTztHQUFFLGVBQWUsTUFBTSxXQUFXLGlCQUFpQjtHQUFHLE1BQU0sVUFBVTtFQUFFO0NBQ3hGO0NBQ0EsTUFBTSxpQkFBaUIsWUFBWTtFQUNqQyxNQUFNLFdBQVcsZUFBZTtHQUFFLE9BQU8sYUFBYTtHQUFPLE1BQU0sYUFBYTtHQUFNLFdBQVcsYUFBYSxRQUFRLENBQUMsRUFBQyxDQUFFLEtBQUssSUFBSTtFQUFFLElBQUk7RUFDekksTUFBTSxVQUFVLFNBQVMsVUFBVSxTQUFTLFNBQVMsU0FBUyxTQUFTLFNBQVMsUUFBUSxTQUFTLGFBQWEsU0FBUztFQUN2SCxJQUFJLFdBQVcsQ0FBQyxPQUFPLFFBQVEsd0JBQXdCLEdBQUc7RUFDMUQsbUJBQW1CO0VBQ25CLElBQUksV0FBVyxnQkFBZ0IsUUFBUSxHQUFHLE1BQU0sbUJBQW1CO0VBQ25FLFFBQVEsTUFBTTtFQUFHLFlBQVksU0FBUztFQUFHLGdCQUFnQjtFQUFHLGVBQWUsS0FBSztFQUFHLGVBQWUsRUFBRTtFQUFHLGNBQWMsQ0FBQyxDQUFDO0NBQ3pIO0NBQ0EsTUFBTSxXQUFXLE9BQU8sVUFBVTtFQUNoQyxNQUFNLGVBQWU7RUFDckIsTUFBTSxTQUFTLGFBQWEsUUFBUTtFQUNwQyxNQUFNLG1CQUFtQixzQkFBc0Isb0JBQW9CLGNBQWMsYUFBYSxVQUFVLEdBQUcsWUFBWTtFQUN2SCxNQUFNLGNBQWMsc0JBQXNCLGVBQWUsY0FBYyxRQUFRLFVBQVUsR0FBRyxPQUFPO0VBQ25HLE1BQU0saUJBQWlCO0dBQUUsR0FBRztHQUFrQixHQUFHO0VBQVk7RUFDN0QsY0FBYyxNQUFNO0VBQUcsY0FBYyxjQUFjO0VBQUcsZUFBZSxFQUFFO0VBQUcsV0FBVyxFQUFFO0VBQ3ZGLElBQUksT0FBTyxLQUFLLE1BQU0sQ0FBQyxDQUFDLFNBQVMsS0FBSyxPQUFPLE9BQU8sY0FBYyxDQUFDLENBQUMsS0FBSyxPQUFPLEdBQUc7RUFDbkYsbUJBQW1CO0VBQ25CLFlBQVksSUFBSTtFQUNoQixJQUFJO0dBQ0YsTUFBTSxTQUFTLFNBQVMsVUFBVTtHQUNsQyxNQUFNLGNBQWMsTUFBTSxRQUFRLElBQUksbUJBQW1CLElBQUksWUFBWSxDQUFDO0dBQzFFLE1BQU0sU0FBUyxNQUFNLFFBQVEsSUFBSSxjQUFjLElBQUksWUFBWSxDQUFDO0dBQ2hFLE1BQU0sWUFBWSxZQUFZLFNBQVMsTUFBTSxhQUFhLEtBQUssS0FBSztJQUFFLFFBQVEsU0FBUyxRQUFRO0lBQVEsU0FBUyxFQUFFLGdCQUFnQixtQkFBbUI7SUFBRyxNQUFNLEtBQUssVUFBVTtLQUFFLE9BQU8sU0FBUztLQUFPLE1BQU0sU0FBUztLQUFNLE1BQU0sU0FBUztLQUFVLFdBQVcsY0FBYztLQUFXO0tBQWE7SUFBTyxDQUFDO0dBQUUsQ0FBQztHQUNoVCxXQUFXLFNBQVMsZUFBZSxZQUFZO0dBQy9DLG9CQUFvQixVQUFVO0dBQUksZ0JBQWdCO0dBQUcsZUFBZSxLQUFLO0dBQUcsZUFBZSxFQUFFO0dBQzdGLFFBQVEsTUFBTTtHQUFHLFlBQVksU0FBUztHQUFHLGdCQUFnQixJQUFJO0dBQUcsTUFBTSxVQUFVO0dBQUcsTUFBTSxTQUFTO0VBQ3BHLFNBQVMsT0FBTztHQUNkLElBQUksTUFBTSxNQUFNLFFBQVEsY0FBYyxNQUFNLEtBQUssTUFBTTtHQUN2RCxlQUFlLE1BQU0sV0FBVyxNQUFNLE1BQU0sVUFBVSxpQ0FBaUM7RUFDekYsVUFBVTtHQUFFLFlBQVksS0FBSztFQUFFO0NBQ2pDO0NBQ0EsTUFBTSxhQUFhLE9BQU8sU0FBUztFQUNqQyxJQUFJLENBQUMsT0FBTyxRQUFRLGNBQWMsR0FBRztFQUNyQyxJQUFJO0dBQUUsTUFBTSxZQUFZLFVBQVUsS0FBSyxNQUFNLEVBQUUsUUFBUSxTQUFTLENBQUM7R0FBRyxXQUFXLFlBQVk7R0FBRyxRQUFRLE1BQU07R0FBRyxnQkFBZ0IsSUFBSTtHQUFHLE1BQU0sVUFBVTtFQUFFLFNBQ2pKLE9BQU87R0FBRSxlQUFlLE1BQU0sV0FBVyxpQ0FBaUM7RUFBRTtDQUNyRjtDQUNBLE1BQU0saUJBQWlCLE9BQU8sU0FBUztFQUNyQyxJQUFJO0dBQUUsTUFBTSxZQUFZLFVBQVUsS0FBSyxHQUFHLFlBQVksRUFBRSxRQUFRLEtBQUssYUFBYSxXQUFXLE9BQU8sQ0FBQztHQUFHLE1BQU0sVUFBVTtFQUFFLFNBQ25ILE9BQU87R0FBRSxlQUFlLGlDQUFpQztFQUFFO0NBQ3BFO0NBRUEsTUFBTSx3QkFBd0I7RUFBRSxnQkFBZ0IsSUFBSTtFQUFHLFlBQVksU0FBUztFQUFHLGNBQWMsQ0FBQyxDQUFDO0VBQUcsUUFBUSxVQUFVO0NBQUU7Q0FDdEgsTUFBTSxpQkFBaUIsU0FBUztFQUFFLGdCQUFnQixJQUFJO0VBQUcsWUFBWTtHQUFFLFFBQVEsS0FBSztHQUFRLGFBQWEsS0FBSztHQUFhLE9BQU8sS0FBSztHQUFPLFVBQVU7R0FBSSxNQUFNLEtBQUs7R0FBTSxRQUFRLEtBQUs7RUFBTyxDQUFDO0VBQUcsY0FBYyxDQUFDLENBQUM7RUFBRyxRQUFRLFVBQVU7Q0FBRTtDQUM1TyxNQUFNLFdBQVcsT0FBTyxVQUFVO0VBQ2hDLE1BQU0sZUFBZTtFQUFHLFlBQVksSUFBSTtFQUFHLGNBQWMsQ0FBQyxDQUFDO0VBQUcsZUFBZSxFQUFFO0VBQUcsV0FBVyxFQUFFO0VBQy9GLElBQUk7R0FDRixNQUFNLFNBQVMsUUFBUSxZQUFZO0dBQ25DLE1BQU0sT0FBTyxNQUFNLFlBQVksU0FBUyxTQUFTLElBQUksYUFBYSxPQUFPLE1BQU07SUFBRSxRQUFRLFNBQVMsUUFBUTtJQUFRLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0lBQUcsTUFBTSxLQUFLLFVBQVUsUUFBUTtHQUFFLENBQUM7R0FDbk0sV0FBVyxLQUFLLE9BQU87R0FBRyxRQUFRLE9BQU87R0FBRyxNQUFNLFVBQVU7RUFDOUQsU0FBUyxPQUFPO0dBQ2QsSUFBSSxNQUFNLE1BQU0sUUFBUSxjQUFjLE1BQU0sS0FBSyxNQUFNO1FBQ2xELGVBQWUsTUFBTSxXQUFXLGlDQUFpQztFQUN4RSxVQUFVO0dBQUUsWUFBWSxLQUFLO0VBQUU7Q0FDakM7Q0FDQSxNQUFNLGNBQWMsT0FBTyxTQUFTO0VBQ2xDLElBQUksQ0FBQyxPQUFPLFFBQVEsR0FBRyxLQUFLLE9BQU8sV0FBVyxHQUFHO0VBQ2pELElBQUk7R0FBRSxNQUFNLE9BQU8sTUFBTSxZQUFZLFVBQVUsS0FBSyxHQUFHLFdBQVcsRUFBRSxRQUFRLFFBQVEsQ0FBQztHQUFHLFdBQVcsS0FBSyxPQUFPO0dBQUcsTUFBTSxVQUFVO0VBQUUsU0FDN0gsT0FBTztHQUFFLGVBQWUsTUFBTSxXQUFXLGlDQUFpQztFQUFFO0NBQ3JGO0NBRUEsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhO0VBQzFCLE9BQU8sd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFBbUIsd0JBQUMsV0FBRDtJQUFTLFdBQVU7Y0FBbkI7S0FBMEMsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQVU7S0FBYzs7Ozs7S0FBQyx3QkFBQyxNQUFELFlBQUksZUFBZ0I7Ozs7O0tBQUUsZUFBZSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZ0I7S0FBaUI7Ozs7O0tBQUUsd0JBQUMsUUFBRDtNQUFNLFVBQVU7TUFBTztnQkFBdkI7T0FBa0Msd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWpCO1NBQXlCLHdCQUFDLFFBQUQsWUFBTSxTQUFZOzs7OztTQUFDLHdCQUFDLFNBQUQ7VUFBTyxPQUFPLFVBQVU7VUFBUSxXQUFXLE1BQU0sYUFBYTtXQUFFLEdBQUc7V0FBVyxRQUFRLEVBQUUsT0FBTztVQUFNLENBQUM7U0FBSTs7Ozs7U0FBRSxZQUFZLFVBQVUsd0JBQUMsVUFBRDtVQUFRLFdBQVU7b0JBQWUsWUFBWTtTQUFlOzs7OztRQUFTOzs7Ozs7T0FBQyx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBakI7U0FBeUIsd0JBQUMsUUFBRCxZQUFNLFFBQVc7Ozs7O1NBQUMsd0JBQUMsU0FBRDtVQUFPLE1BQUs7VUFBVyxPQUFPLFVBQVU7VUFBVSxXQUFXLE1BQU0sYUFBYTtXQUFFLEdBQUc7V0FBVyxVQUFVLEVBQUUsT0FBTztVQUFNLENBQUM7U0FBSTs7Ozs7U0FBRSxZQUFZLFlBQVksd0JBQUMsVUFBRDtVQUFRLFdBQVU7b0JBQWUsWUFBWTtTQUFpQjs7Ozs7UUFBUzs7Ozs7O09BQUMsd0JBQUMsVUFBRDtRQUFRLE1BQUs7UUFBUyxXQUFVO1FBQWlCLFVBQVU7a0JBQVcsV0FBVyxVQUFVO09BQWU7Ozs7O01BQU87Ozs7OztLQUFDLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFPO0tBQThCOzs7OztJQUFVOzs7Ozs7RUFBTzs7Ozs7Q0FDejZCO0NBRUEsT0FDRSx3QkFBQyxRQUFEO0VBQU0sV0FBVTtZQUFoQjtHQUNFLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO2NBQWxCLENBQStCLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFiO01BQXdCLFlBQVk7TUFBWTtNQUFJLFlBQVksU0FBUyxVQUFVLFFBQVE7S0FBWTs7Ozs7Y0FBQyx3QkFBQyxNQUFELFlBQUksVUFBVzs7OztZQUFNOzs7O2NBQUMsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUFnQyx3QkFBQyxVQUFEO09BQVEsTUFBSztPQUFTLFdBQVU7T0FBaUIsU0FBUztpQkFBYTtNQUFZOzs7OztNQUFFLFlBQVksU0FBUyxXQUFXLHdCQUFDLFVBQUQ7T0FBUSxNQUFLO09BQVMsV0FBVTtPQUFlLFNBQVM7aUJBQWM7TUFBYzs7Ozs7TUFBRSx3QkFBQyxVQUFEO09BQVEsTUFBSztPQUFTLFdBQVU7T0FBZSxTQUFTO2lCQUFRO01BQWE7Ozs7O0tBQU07Ozs7O1lBQVM7Ozs7OztHQUN4ZSxXQUFXLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWtCO0dBQWE7Ozs7O0dBQUcsZUFBZSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFnQjtHQUFpQjs7Ozs7R0FFM0gsU0FBUyxXQUFXLFlBQVksU0FBUyxXQUFXLHdCQUFDLFdBQUQ7SUFBUyxXQUFVO2NBQW5CLENBQStCLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FBaUMsd0JBQUMsTUFBRCxZQUFJLFNBQVU7Ozs7ZUFBQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUE4Qix3QkFBQyxVQUFEO09BQVEsTUFBSztPQUFTLFdBQVU7T0FBaUIsU0FBUztpQkFBaUI7TUFBYzs7OztnQkFBQyx3QkFBQyxVQUFEO09BQVEsTUFBSztPQUFTLFdBQVU7T0FBZSxlQUFlLFFBQVEsTUFBTTtpQkFBRztNQUFlOzs7O2NBQU07Ozs7O2FBQU07Ozs7O2NBQUMsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUE0Qix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUFvQyx3QkFBQyxRQUFELFlBQU0sU0FBWTs7Ozs7T0FBQyx3QkFBQyxRQUFELFlBQU0sTUFBUzs7Ozs7T0FBQyx3QkFBQyxRQUFELFlBQU0sTUFBUzs7Ozs7T0FBQyx3QkFBQyxRQUFELFlBQU0sS0FBUTs7Ozs7T0FBQyx3QkFBQyxRQUFELFlBQU0sS0FBUTs7Ozs7T0FBQyx3QkFBQyxRQUFELFlBQU0sS0FBUTs7Ozs7TUFBTTs7Ozs7ZUFBRSxNQUFNLEtBQUssU0FBUyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUF3Qyx3QkFBQyxRQUFELFlBQU8sS0FBSyxPQUFhOzs7OztPQUFDLHdCQUFDLFFBQUQsWUFBTyxLQUFLLFlBQWtCOzs7OztPQUFDLHdCQUFDLFFBQUQsWUFBTyxLQUFLLE1BQVk7Ozs7O09BQUMsd0JBQUMsUUFBRCxZQUFPLEtBQUssU0FBUyxVQUFVLFFBQVEsU0FBZTs7Ozs7T0FBQyx3QkFBQyxRQUFELFlBQU8sS0FBSyxXQUFXLFdBQVcsT0FBTyxLQUFXOzs7OztPQUFDLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUE4Qix3QkFBQyxVQUFEO1NBQVEsTUFBSztTQUFTLGVBQWUsY0FBYyxJQUFJO21CQUFHO1FBQVU7Ozs7a0JBQUMsd0JBQUMsVUFBRDtTQUFRLE1BQUs7U0FBUyxXQUFVO1NBQWdCLFVBQVUsS0FBSyxXQUFXO1NBQVksZUFBZSxZQUFZLElBQUk7bUJBQUc7UUFBVzs7OztnQkFBTzs7Ozs7O01BQU07UUFBMWIsS0FBSzs7OztZQUFxYixDQUFDLENBQU87Ozs7O1lBQVU7Ozs7OztHQUU1Z0MsU0FBUyxjQUFjLFlBQVksU0FBUyxXQUFXLHdCQUFDLFdBQUQ7SUFBUyxXQUFVO2NBQW5CLENBQTBDLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FBaUMsd0JBQUMsTUFBRCxZQUFLLGVBQWUsV0FBVyxTQUFhOzs7O2VBQUMsd0JBQUMsVUFBRDtNQUFRLE1BQUs7TUFBUyxXQUFVO01BQWUsZUFBZSxRQUFRLE9BQU87Z0JBQUc7S0FBYTs7OzthQUFNOzs7OztjQUFDLHdCQUFDLFFBQUQ7S0FBTSxVQUFVO0tBQVU7ZUFBMUI7TUFBcUMsd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQWpCO1FBQXlCLHdCQUFDLFFBQUQsWUFBTSxTQUFZOzs7OztRQUFDLHdCQUFDLFNBQUQ7U0FBTyxPQUFPLFNBQVM7U0FBUSxVQUFVLFFBQVEsWUFBWTtTQUFHLFdBQVcsTUFBTSxZQUFZO1VBQUUsR0FBRztVQUFVLFFBQVEsRUFBRSxPQUFPO1NBQU0sQ0FBQztRQUFJOzs7OztRQUFFLFdBQVcsVUFBVSx3QkFBQyxVQUFEO1NBQVEsV0FBVTttQkFBZSxXQUFXO1FBQWU7Ozs7O09BQVM7Ozs7OztNQUFDLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFqQjtRQUF5Qix3QkFBQyxRQUFELFlBQU0sTUFBUzs7Ozs7UUFBQyx3QkFBQyxTQUFEO1NBQU8sT0FBTyxTQUFTO1NBQWEsV0FBVyxNQUFNLFlBQVk7VUFBRSxHQUFHO1VBQVUsYUFBYSxFQUFFLE9BQU87U0FBTSxDQUFDO1FBQUk7Ozs7O1FBQUUsV0FBVyxlQUFlLHdCQUFDLFVBQUQ7U0FBUSxXQUFVO21CQUFlLFdBQVc7UUFBb0I7Ozs7O09BQVM7Ozs7OztNQUFDLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFqQjtRQUF5Qix3QkFBQyxRQUFELFlBQU0sVUFBYTs7Ozs7UUFBQyx3QkFBQyxTQUFEO1NBQU8sT0FBTyxTQUFTO1NBQU8sV0FBVyxNQUFNLFlBQVk7VUFBRSxHQUFHO1VBQVUsT0FBTyxFQUFFLE9BQU87U0FBTSxDQUFDO1FBQUk7Ozs7O1FBQUUsV0FBVyxTQUFTLHdCQUFDLFVBQUQ7U0FBUSxXQUFVO21CQUFlLFdBQVc7UUFBYzs7Ozs7T0FBUzs7Ozs7O01BQUMsd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQWpCO1FBQXlCLHdCQUFDLFFBQUQsYUFBTSxTQUFNLGVBQWUsY0FBYyxFQUFTOzs7OztRQUFDLHdCQUFDLFNBQUQ7U0FBTyxNQUFLO1NBQVcsT0FBTyxTQUFTO1NBQVUsV0FBVyxNQUFNLFlBQVk7VUFBRSxHQUFHO1VBQVUsVUFBVSxFQUFFLE9BQU87U0FBTSxDQUFDO1FBQUk7Ozs7O1FBQUUsV0FBVyxZQUFZLHdCQUFDLFVBQUQ7U0FBUSxXQUFVO21CQUFlLFdBQVc7UUFBaUI7Ozs7O09BQVM7Ozs7OztNQUFDLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFqQjtRQUF5Qix3QkFBQyxRQUFELFlBQU0sS0FBUTs7Ozs7UUFBQyx3QkFBQyxVQUFEO1NBQVEsT0FBTyxTQUFTO1NBQU0sV0FBVyxNQUFNLFlBQVk7VUFBRSxHQUFHO1VBQVUsTUFBTSxFQUFFLE9BQU87U0FBTSxDQUFDO21CQUFoRyxDQUFtRyx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBTztTQUFjOzs7O21CQUFDLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFRO1NBQVc7Ozs7aUJBQVM7Ozs7OztRQUFFLFdBQVcsUUFBUSx3QkFBQyxVQUFEO1NBQVEsV0FBVTttQkFBZSxXQUFXO1FBQWE7Ozs7O09BQVM7Ozs7OztNQUFFLGdCQUFnQix3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBakIsQ0FBeUIsd0JBQUMsUUFBRCxZQUFNLEtBQVE7Ozs7aUJBQUMsd0JBQUMsVUFBRDtRQUFRLE9BQU8sU0FBUztRQUFRLFdBQVcsTUFBTSxZQUFZO1NBQUUsR0FBRztTQUFVLFFBQVEsRUFBRSxPQUFPO1FBQU0sQ0FBQztrQkFBcEcsQ0FBdUcsd0JBQUMsVUFBRDtTQUFRLE9BQU07bUJBQVM7UUFBVTs7OztrQkFBQyx3QkFBQyxVQUFEO1NBQVEsT0FBTTttQkFBVztRQUFVOzs7O2dCQUFTOzs7OztlQUFROzs7Ozs7TUFBRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUE4Qix3QkFBQyxVQUFEO1FBQVEsTUFBSztRQUFTLFdBQVU7UUFBaUIsVUFBVTtrQkFBVyxXQUFXLFFBQVEsZUFBZSxPQUFPO09BQWE7Ozs7aUJBQUMsd0JBQUMsVUFBRDtRQUFRLE1BQUs7UUFBUyxXQUFVO1FBQWUsZUFBZSxRQUFRLE9BQU87a0JBQUc7T0FBYTs7OztlQUFNOzs7Ozs7S0FBTzs7Ozs7WUFBVTs7Ozs7O0dBRW5wRSxTQUFTLFVBQVUsd0JBQUMsV0FBRDtJQUFTLFdBQVU7Y0FBbkI7S0FBK0Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FBbUMsd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWpCLENBQWdDLHdCQUFDLFFBQUQsWUFBTSxLQUFROzs7O2tCQUFDLHdCQUFDLFNBQUQ7U0FBTyxPQUFPLFFBQVE7U0FBUyxXQUFXLE1BQU0sY0FBYyxFQUFFLFNBQVMsRUFBRSxPQUFPLE1BQU0sQ0FBQztTQUFHLGFBQVk7UUFBYzs7OztnQkFBUTs7Ozs7O09BQUMsd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWpCLENBQWdDLHdCQUFDLFFBQUQsWUFBTSxPQUFVOzs7O2tCQUFDLHdCQUFDLFVBQUQ7U0FBUSxPQUFPLFFBQVE7U0FBTyxXQUFXLE1BQU0sY0FBYyxFQUFFLE9BQU8sT0FBTyxFQUFFLE9BQU8sS0FBSyxFQUFFLENBQUM7bUJBQTlGO1VBQWlHLHdCQUFDLFVBQUQ7V0FBUSxPQUFNO3FCQUFLO1VBQVc7Ozs7O1VBQUMsd0JBQUMsVUFBRDtXQUFRLE9BQU07cUJBQUs7VUFBVzs7Ozs7VUFBQyx3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBSztVQUFXOzs7OztTQUFTOzs7OztnQkFBUTs7Ozs7O09BQUMsd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWpCLENBQWdDLHdCQUFDLFFBQUQsWUFBTSxPQUFVOzs7O2tCQUFDLHdCQUFDLFVBQUQ7U0FBUSxPQUFPLFFBQVE7U0FBUSxXQUFXLE1BQU0sY0FBYyxFQUFFLFFBQVEsRUFBRSxPQUFPLE1BQU0sQ0FBQzttQkFBeEY7VUFBMkYsd0JBQUMsVUFBRDtXQUFRLE9BQU07cUJBQVk7VUFBWTs7Ozs7VUFBQyx3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBWTtVQUFZOzs7OztVQUFDLHdCQUFDLFVBQUQ7V0FBUSxPQUFNO3FCQUFRO1VBQVk7Ozs7O1NBQVM7Ozs7O2dCQUFROzs7Ozs7T0FBQyx3QkFBQyxPQUFEO1FBQUssV0FBVTtRQUFZLGNBQVc7a0JBQXRDLENBQTZDLHdCQUFDLFVBQUQ7U0FBUSxNQUFLO1NBQVMsV0FBVyxRQUFRLFVBQVUsU0FBUyxXQUFXO1NBQUksZUFBZSxjQUFjLEVBQUUsT0FBTyxPQUFPLENBQUM7bUJBQUc7UUFBVTs7OztrQkFBQyx3QkFBQyxVQUFEO1NBQVEsTUFBSztTQUFTLFdBQVcsUUFBUSxVQUFVLFFBQVEsV0FBVztTQUFJLGVBQWUsY0FBYyxFQUFFLE9BQU8sTUFBTSxDQUFDO21CQUFHO1FBQVU7Ozs7Z0JBQU07Ozs7OztNQUFNOzs7Ozs7S0FBQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUF5Qyx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBakIsQ0FBK0Isd0JBQUMsU0FBRDtTQUFPLE1BQUs7U0FBVyxTQUFTLFFBQVE7U0FBVSxXQUFXLE1BQU0sY0FBYyxFQUFFLFVBQVUsRUFBRSxPQUFPLFFBQVEsQ0FBQztRQUFJOzs7O2tCQUFDLFVBQWU7Ozs7OztPQUFDLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFqQixDQUFnQyx3QkFBQyxRQUFELFlBQU0sS0FBUTs7OztrQkFBQyx3QkFBQyxVQUFEO1NBQVEsT0FBTyxRQUFRO1NBQUssV0FBVyxNQUFNLGNBQWMsRUFBRSxLQUFLLEVBQUUsT0FBTyxNQUFNLENBQUM7bUJBQWxGLENBQXFGLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFHO1NBQVc7Ozs7bUJBQUUsS0FBSyxLQUFLLFFBQVEsd0JBQUMsVUFBRDtVQUFpQyxPQUFPLElBQUk7b0JBQWlCLElBQUk7U0FBYSxHQUFqRSxJQUFJOzs7O2dCQUE2RCxDQUFDLENBQVU7Ozs7O2dCQUFROzs7Ozs7T0FBQyx3QkFBQyxPQUFEO1FBQUssV0FBVTtRQUFZLGNBQVc7a0JBQXRDLENBQStDLHdCQUFDLFVBQUQ7U0FBUSxNQUFLO1NBQVMsV0FBVyxnQkFBZ0IsU0FBUyxXQUFXO1NBQUksZUFBZSxlQUFlLE1BQU07bUJBQUc7UUFBVTs7OztrQkFBQyx3QkFBQyxVQUFEO1NBQVEsTUFBSztTQUFTLFdBQVcsZ0JBQWdCLFlBQVksV0FBVztTQUFJLGVBQWUsZUFBZSxTQUFTO21CQUFHO1FBQWE7Ozs7Z0JBQU07Ozs7OztNQUFNOzs7Ozs7S0FBRSxhQUFhLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFjO0tBQVc7Ozs7O0tBQUcsQ0FBQyxhQUFhLFVBQVUsS0FBSyxDQUFDLFFBQVEsV0FBVyxDQUFDLFFBQVEsWUFBWSx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYztLQUFnQjs7Ozs7S0FBRyxDQUFDLGFBQWEsVUFBVSxNQUFNLFFBQVEsV0FBVyxRQUFRLGFBQWEsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWM7S0FBbUI7Ozs7O0tBQUUsd0JBQUMsT0FBRDtNQUFLLFdBQVcsZ0JBQWdCLFlBQVksc0JBQXNCO2dCQUFjLE1BQU0sS0FBSyxTQUFTLHdCQUFDLFdBQUQ7T0FBUyxXQUFVO2lCQUFuQixDQUE2Qyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUEyQix3QkFBQyxNQUFELFlBQUssS0FBSyxNQUFVOzs7OztTQUFFLGdCQUFnQixVQUFVLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFnQixLQUFLLEtBQUssTUFBTSxHQUFHLEVBQUU7U0FBSzs7Ozs7U0FBRyxLQUFLLE1BQU0sU0FBUyxLQUFLLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFZLEtBQUssS0FBSyxLQUFLLFFBQVEsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXNCO1VBQVUsR0FBaEI7Ozs7aUJBQWdCLENBQUM7U0FBTzs7Ozs7U0FBRSx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBYixDQUF5QixTQUFNLFdBQVcsS0FBSyxTQUFTLENBQUs7Ozs7OztRQUFNOzs7OztpQkFBQyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUE4Qix3QkFBQyxVQUFEO1VBQVEsTUFBSztVQUFTLGVBQWUsZUFBZSxJQUFJO29CQUFJLEtBQUssYUFBYSxZQUFZO1NBQWdCOzs7OztTQUFDLHdCQUFDLFVBQUQ7VUFBUSxNQUFLO1VBQVMsZUFBZSxXQUFXLElBQUk7b0JBQUc7U0FBVTs7Ozs7U0FBQyx3QkFBQyxVQUFEO1VBQVEsTUFBSztVQUFTLGVBQWUsVUFBVSxJQUFJO29CQUFHO1NBQVU7Ozs7O1NBQUMsd0JBQUMsVUFBRDtVQUFRLE1BQUs7VUFBUyxXQUFVO1VBQWdCLGVBQWUsV0FBVyxJQUFJO29CQUFHO1NBQVU7Ozs7O1FBQU07Ozs7O2VBQVU7U0FBOXNCLEtBQUs7Ozs7YUFBeXNCLENBQUM7S0FBTzs7Ozs7S0FBQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUE0Qix3QkFBQyxVQUFEO1FBQVEsTUFBSztRQUFTLFVBQVUsUUFBUSxRQUFRO1FBQUcsZUFBZSxjQUFjLEVBQUUsTUFBTSxRQUFRLE9BQU8sRUFBRSxDQUFDO2tCQUFHO09BQVU7Ozs7O09BQUMsd0JBQUMsUUFBRDtRQUFPLFFBQVE7UUFBSztRQUFJO09BQWdCOzs7OztPQUFDLHdCQUFDLFVBQUQ7UUFBUSxNQUFLO1FBQVMsVUFBVSxRQUFRLFFBQVE7UUFBVyxlQUFlLGNBQWMsRUFBRSxNQUFNLFFBQVEsT0FBTyxFQUFFLENBQUM7a0JBQUc7T0FBVTs7Ozs7TUFBTTs7Ozs7O0lBQVU7Ozs7OztJQUU3ekcsU0FBUyxZQUFZLFNBQVMsV0FBVyx3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUFuQixDQUEwQyx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQWlDLHdCQUFDLE1BQUQsWUFBSyxTQUFTLFdBQVcsV0FBVyxPQUFXOzs7O2VBQUMsd0JBQUMsVUFBRDtNQUFRLE1BQUs7TUFBUyxXQUFVO01BQWUsU0FBUztnQkFBZ0I7S0FBYTs7OzthQUFNOzs7OztjQUFDLHdCQUFDLFFBQUQ7S0FBTSxVQUFVO0tBQVU7ZUFBMUI7TUFBcUMsd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQWpCO1FBQXlCLHdCQUFDLFFBQUQsWUFBTSxPQUFVOzs7OztRQUFDLHdCQUFDLFNBQUQ7U0FBTyxPQUFPLFNBQVM7U0FBTyxXQUFXO1NBQUssV0FBVyxNQUFNLGFBQWEsU0FBUyxFQUFFLE9BQU8sS0FBSztRQUFJOzs7OztRQUFDLHdCQUFDLFNBQUQsYUFBUSxTQUFTLE1BQU0sUUFBTyxNQUFXOzs7OztRQUFFLFdBQVcsU0FBUyx3QkFBQyxVQUFEO1NBQVEsV0FBVTttQkFBZSxXQUFXO1FBQWM7Ozs7O09BQVM7Ozs7OztNQUFDLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFqQjtRQUF5Qix3QkFBQyxRQUFELFlBQU0sS0FBUTs7Ozs7UUFBQyx3QkFBQyxZQUFEO1NBQVUsT0FBTyxTQUFTO1NBQU0sTUFBSztTQUFLLFdBQVc7U0FBTSxXQUFXLE1BQU0sYUFBYSxRQUFRLEVBQUUsT0FBTyxLQUFLO1FBQUk7Ozs7O1FBQUMsd0JBQUMsU0FBRCxhQUFRLFNBQVMsS0FBSyxRQUFPLE9BQVk7Ozs7O1FBQUUsV0FBVyxRQUFRLHdCQUFDLFVBQUQ7U0FBUSxXQUFVO21CQUFlLFdBQVc7UUFBYTs7Ozs7T0FBUzs7Ozs7O01BQUMsd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQWpCO1FBQXlCLHdCQUFDLFFBQUQsWUFBTSxLQUFROzs7OztRQUFDLHdCQUFDLFNBQUQ7U0FBTyxPQUFPLFNBQVM7U0FBVSxXQUFXLE1BQU0sYUFBYSxZQUFZLEVBQUUsT0FBTyxLQUFLO1NBQUcsYUFBWTtRQUFhOzs7OztRQUFDLHdCQUFDLFNBQUQsWUFBTyx1QkFBMkI7Ozs7O1FBQUUsV0FBVyxRQUFRLHdCQUFDLFVBQUQ7U0FBUSxXQUFVO21CQUFlLFdBQVc7UUFBYTs7Ozs7T0FBUzs7Ozs7O01BQUMsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBMkIsd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWpCO1NBQXlCLHdCQUFDLFFBQUQsWUFBTSxTQUFZOzs7OztTQUFDLHdCQUFDLFNBQUQ7VUFBTyxNQUFLO1VBQU87VUFBUyxRQUFPO1VBQTZCLFdBQVcsTUFBTSxnQkFBZ0IsR0FBRyxZQUFZO1NBQUk7Ozs7O1NBQUMsd0JBQUMsU0FBRCxZQUFPLG1CQUF1Qjs7Ozs7U0FBRSxXQUFXLGVBQWUsd0JBQUMsVUFBRDtVQUFRLFdBQVU7b0JBQWUsV0FBVztTQUFvQjs7Ozs7UUFBUzs7Ozs7aUJBQUMsd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWpCO1NBQXlCLHdCQUFDLFFBQUQsWUFBTSxLQUFROzs7OztTQUFDLHdCQUFDLFNBQUQ7VUFBTyxNQUFLO1VBQU87VUFBUyxRQUFPO1VBQTZCLFdBQVcsTUFBTSxnQkFBZ0IsR0FBRyxPQUFPO1NBQUk7Ozs7O1NBQUMsd0JBQUMsU0FBRCxZQUFPLG1CQUF1Qjs7Ozs7U0FBRSxXQUFXLFVBQVUsd0JBQUMsVUFBRDtVQUFRLFdBQVU7b0JBQWUsV0FBVztTQUFlOzs7OztRQUFTOzs7OztlQUFNOzs7Ozs7TUFBRSxjQUFjLGFBQWEsU0FBUyxLQUFLLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQTJCLHdCQUFDLE1BQUQsWUFBSSxhQUFjOzs7O2lCQUFFLGFBQWEsWUFBWSxLQUFLLFNBQVMsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FBd0Msd0JBQUMsUUFBRDtTQUFPLEtBQUs7U0FBYTtTQUFHLFdBQVcsS0FBSyxJQUFJO1NBQUU7UUFBTzs7OztrQkFBQyx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUE2Qix3QkFBQyxVQUFEO1VBQVEsTUFBSztVQUFTLGVBQWUsYUFBYSxJQUFJO29CQUFHO1NBQWM7Ozs7bUJBQUMsd0JBQUMsVUFBRDtVQUFRLE1BQUs7VUFBUyxXQUFVO1VBQWdCLGVBQWUsbUJBQW1CLElBQUk7b0JBQUc7U0FBVTs7OztpQkFBTTs7Ozs7Z0JBQU07VUFBdlIsS0FBSzs7OztjQUFrUixDQUFDLENBQU87Ozs7OztNQUFHLGNBQWMsUUFBUSxTQUFTLEtBQUssd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBNEIsd0JBQUMsTUFBRCxZQUFJLFNBQVU7Ozs7aUJBQUUsYUFBYSxPQUFPLEtBQUssU0FBUyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUEyQyxVQUFVLEtBQUssTUFBTSx3QkFBQyxPQUFEO1VBQUssS0FBSyxVQUFVLEtBQUs7VUFBSyxLQUFLLEtBQUs7U0FBZTs7OztvQkFBSSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBb0I7U0FBZTs7Ozs7U0FBRSx3QkFBQyxRQUFELFlBQU8sS0FBSyxhQUFtQjs7Ozs7U0FBQyx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUE2Qix3QkFBQyxVQUFEO1dBQVEsTUFBSztXQUFTLGVBQWUsYUFBYSxJQUFJO3FCQUFHO1VBQWM7Ozs7b0JBQUMsd0JBQUMsVUFBRDtXQUFRLE1BQUs7V0FBUyxXQUFVO1dBQWdCLGVBQWUsbUJBQW1CLElBQUk7cUJBQUc7VUFBVTs7OztrQkFBTTs7Ozs7O1FBQU07VUFBbFksS0FBSzs7OztjQUE2WCxDQUFDLENBQU87Ozs7OztNQUFHLG1CQUFtQixTQUFTLEtBQUssd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBMkIsd0JBQUMsTUFBRCxZQUFJLGNBQWU7Ozs7aUJBQUUsbUJBQW1CLEtBQUssTUFBTSxVQUFVLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQXdELHdCQUFDLFFBQUQ7U0FBTyxLQUFLO1NBQUs7U0FBRyxXQUFXLEtBQUssSUFBSTtTQUFFO1FBQU87Ozs7a0JBQUMsd0JBQUMsVUFBRDtTQUFRLE1BQUs7U0FBUyxXQUFVO1NBQWdCLGVBQWUsa0JBQWtCLE9BQU8sWUFBWTttQkFBRztRQUFVOzs7O2dCQUFNO1VBQWxNLEtBQUssT0FBTyxNQUFNOzs7O2NBQWdMLENBQUMsQ0FBTzs7Ozs7O01BQUcsY0FBYyxTQUFTLEtBQUssd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FBNEIsd0JBQUMsTUFBRCxZQUFJLFVBQVc7Ozs7aUJBQUUsY0FBYyxLQUFLLE1BQU0sVUFBVSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUEwRCx3QkFBQyxPQUFEO1VBQUssS0FBSyxJQUFJLGdCQUFnQixJQUFJO1VBQUcsS0FBSyxLQUFLO1NBQU87Ozs7O1NBQUMsd0JBQUMsUUFBRCxZQUFPLEtBQUssS0FBVzs7Ozs7U0FBQyx3QkFBQyxVQUFEO1VBQVEsTUFBSztVQUFTLFdBQVU7VUFBZ0IsZUFBZSxrQkFBa0IsT0FBTyxPQUFPO29CQUFHO1NBQVU7Ozs7O1FBQU07VUFBMU4sS0FBSyxPQUFPLE1BQU07Ozs7Y0FBd00sQ0FBQyxDQUFPOzs7Ozs7TUFBRyxlQUFlLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFnQjtNQUFlOzs7OztNQUFFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQThCLHdCQUFDLFVBQUQ7UUFBUSxNQUFLO1FBQVMsV0FBVTtRQUFpQixVQUFVO2tCQUFXLFdBQVcsUUFBUSxTQUFTLFdBQVcsT0FBTztPQUFhOzs7O2lCQUFDLHdCQUFDLFVBQUQ7UUFBUSxNQUFLO1FBQVMsV0FBVTtRQUFlLFNBQVM7a0JBQWdCO09BQWE7Ozs7ZUFBTTs7Ozs7O0tBQU87Ozs7O1lBQVU7Ozs7OztHQUV6c0gsU0FBUyxZQUFZLGdCQUFnQix3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUFuQjtLQUE0Qyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUFpQyx3QkFBQyxNQUFELFlBQUssYUFBYSxNQUFVOzs7O2dCQUFDLHdCQUFDLFVBQUQ7T0FBUSxNQUFLO09BQVMsV0FBVTtPQUFlLGVBQWUsUUFBUSxNQUFNO2lCQUFHO01BQWE7Ozs7Y0FBTTs7Ozs7O0tBQUUsYUFBYSxNQUFNLFNBQVMsS0FBSyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBd0IsYUFBYSxLQUFLLEtBQUssUUFBUSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBc0I7TUFBVSxHQUFoQjs7OzthQUFnQixDQUFDO0tBQU87Ozs7O0tBQUcsYUFBYSxhQUFhLFNBQVMsS0FBSyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUEyQix3QkFBQyxNQUFELFlBQUksU0FBVTs7OztnQkFBRSxhQUFhLFlBQVksS0FBSyxTQUFTLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQXdDLHdCQUFDLFFBQUQ7UUFBTyxLQUFLO1FBQWE7UUFBRyxXQUFXLEtBQUssSUFBSTtRQUFFO09BQU87Ozs7aUJBQUMsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FBNkIsd0JBQUMsVUFBRDtTQUFRLE1BQUs7U0FBUyxlQUFlLGFBQWEsSUFBSTttQkFBRztRQUFjOzs7O2tCQUFDLHdCQUFDLFVBQUQ7U0FBUSxNQUFLO1NBQVMsV0FBVTtTQUFnQixlQUFlLG1CQUFtQixJQUFJO21CQUFHO1FBQVU7Ozs7Z0JBQU07Ozs7O2VBQU07U0FBdlIsS0FBSzs7OzthQUFrUixDQUFDLENBQU87Ozs7OztLQUFHLGFBQWEsUUFBUSxTQUFTLEtBQUssd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FBNEIsd0JBQUMsTUFBRCxZQUFJLEtBQU07Ozs7Z0JBQUUsYUFBYSxPQUFPLEtBQUssU0FBUyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUEyQyxVQUFVLEtBQUssTUFBTSx3QkFBQyxPQUFEO1NBQUssS0FBSyxVQUFVLEtBQUs7U0FBSyxLQUFLLEtBQUs7UUFBZTs7OzttQkFBSSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBb0I7UUFBZTs7Ozs7UUFBRSx3QkFBQyxRQUFELFlBQU8sS0FBSyxhQUFtQjs7Ozs7UUFBQyx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUE2Qix3QkFBQyxVQUFEO1VBQVEsTUFBSztVQUFTLGVBQWUsYUFBYSxJQUFJO29CQUFHO1NBQWM7Ozs7bUJBQUMsd0JBQUMsVUFBRDtVQUFRLE1BQUs7VUFBUyxXQUFVO1VBQWdCLGVBQWUsbUJBQW1CLElBQUk7b0JBQUc7U0FBVTs7OztpQkFBTTs7Ozs7O09BQU07U0FBbFksS0FBSzs7OzthQUE2WCxDQUFDLENBQU87Ozs7OztLQUFFLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFhLGFBQWE7S0FBUTs7Ozs7S0FBQyx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZCxDQUEwQix3QkFBQyxPQUFELGFBQUssd0JBQUMsTUFBRCxZQUFJLE9BQVE7Ozs7Z0JBQUMsd0JBQUMsTUFBRCxZQUFLLFdBQVcsYUFBYSxTQUFTLEVBQU07Ozs7Y0FBTTs7OztnQkFBQyx3QkFBQyxPQUFELGFBQUssd0JBQUMsTUFBRCxZQUFJLE9BQVE7Ozs7Z0JBQUMsd0JBQUMsTUFBRCxZQUFLLFdBQVcsYUFBYSxTQUFTLEVBQU07Ozs7Y0FBTTs7OztjQUFLOzs7Ozs7S0FBQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUE4Qix3QkFBQyxVQUFEO09BQVEsTUFBSztPQUFTLGVBQWUsVUFBVSxZQUFZO2lCQUFHO01BQVU7Ozs7Z0JBQUMsd0JBQUMsVUFBRDtPQUFRLE1BQUs7T0FBUyxXQUFVO09BQWdCLGVBQWUsV0FBVyxZQUFZO2lCQUFHO01BQVU7Ozs7Y0FBTTs7Ozs7O0lBQVU7Ozs7OztFQUMxeEQ7Ozs7OztBQUVWOzs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsi77u/aW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgJy4vQXBwLmNzcydcblxuY29uc3QgQVBJX0JBU0UgPSAnaHR0cDovL2xvY2FsaG9zdDozMDAxL2FwaSdcbmNvbnN0IGVtcHR5TWVtbyA9IHsgdGl0bGU6ICcnLCBib2R5OiAnJywgdGFnc1RleHQ6ICcnIH1cbmNvbnN0IGVtcHR5VXNlciA9IHsgdXNlcklkOiAnJywgZGlzcGxheU5hbWU6ICcnLCBlbWFpbDogJycsIHBhc3N3b3JkOiAnJywgcm9sZTogJ3VzZXInLCBzdGF0dXM6ICdhY3RpdmUnIH1cbmNvbnN0IGluaXRpYWxGaWx0ZXJzID0geyBrZXl3b3JkOiAnJywgcGFnZTogMSwgbGltaXQ6IDEwLCBzb3J0Qnk6ICd1cGRhdGVkQXQnLCBvcmRlcjogJ2Rlc2MnLCBmYXZvcml0ZTogZmFsc2UsIHRhZzogJycgfVxuXG5mdW5jdGlvbiBmb3JtYXREYXRlKHZhbHVlKSB7XG4gIGlmICghdmFsdWUpIHJldHVybiAnJ1xuICBjb25zdCBkYXRlID0gbmV3IERhdGUodmFsdWUpXG4gIGlmIChOdW1iZXIuaXNOYU4oZGF0ZS5nZXRUaW1lKCkpKSByZXR1cm4gdmFsdWVcbiAgY29uc3QgcGFkID0gKG51bSkgPT4gU3RyaW5nKG51bSkucGFkU3RhcnQoMiwgJzAnKVxuICByZXR1cm4gYCR7ZGF0ZS5nZXRGdWxsWWVhcigpfS8ke3BhZChkYXRlLmdldE1vbnRoKCkgKyAxKX0vJHtwYWQoZGF0ZS5nZXREYXRlKCkpfSAke3BhZChkYXRlLmdldEhvdXJzKCkpfToke3BhZChkYXRlLmdldE1pbnV0ZXMoKSl9OiR7cGFkKGRhdGUuZ2V0U2Vjb25kcygpKX1gXG59XG5cblxuZnVuY3Rpb24gZm9ybWF0U2l6ZShzaXplKSB7XG4gIGlmICghc2l6ZSkgcmV0dXJuICcwIEtCJ1xuICBpZiAoc2l6ZSA+PSAxMDI0ICogMTAyNCkgcmV0dXJuIChzaXplIC8gMTAyNCAvIDEwMjQpLnRvRml4ZWQoMSkgKyAnIE1CJ1xuICByZXR1cm4gTWF0aC5tYXgoMSwgTWF0aC5yb3VuZChzaXplIC8gMTAyNCkpICsgJyBLQidcbn1cblxuZnVuY3Rpb24gZ2V0RXh0ZW5zaW9uKG5hbWUpIHtcbiAgY29uc3QgcGFydHMgPSBTdHJpbmcobmFtZSB8fCAnJykuc3BsaXQoJy4nKVxuICByZXR1cm4gcGFydHMubGVuZ3RoID4gMSA/IHBhcnRzLnBvcCgpLnRvTG93ZXJDYXNlKCkgOiAnJ1xufVxuXG5mdW5jdGlvbiB2YWxpZGF0ZVNlbGVjdGVkRmlsZXMoZmlsZXMsIGV4aXN0aW5nQ291bnQsIHR5cGUpIHtcbiAgY29uc3QgZXJyb3JzID0ge31cbiAgY29uc3QgbGlzdCA9IEFycmF5LmZyb20oZmlsZXMgfHwgW10pXG4gIGNvbnN0IGlzSW1hZ2UgPSB0eXBlID09PSAnaW1hZ2UnXG4gIGNvbnN0IGFsbG93ZWQgPSBpc0ltYWdlID8gWydqcGcnLCAnanBlZycsICdwbmcnLCAnZ2lmJywgJ3dlYnAnXSA6IFsncGRmJywgJ3R4dCcsICdjc3YnLCAnZG9jeCcsICd4bHN4J11cbiAgY29uc3QgbWF4Q291bnQgPSBpc0ltYWdlID8gMTAgOiA1XG4gIGNvbnN0IG1heFNpemUgPSBpc0ltYWdlID8gNSAqIDEwMjQgKiAxMDI0IDogMTAgKiAxMDI0ICogMTAyNFxuICBjb25zdCBrZXkgPSBpc0ltYWdlID8gJ2ltYWdlcycgOiAnYXR0YWNobWVudHMnXG4gIGlmIChleGlzdGluZ0NvdW50ICsgbGlzdC5sZW5ndGggPiBtYXhDb3VudCkgZXJyb3JzW2tleV0gPSBpc0ltYWdlID8gJ+eUu+WDj+OBrzEw5p6a5Lul5YaF44Gn6YG45oqe44GX44Gm44GP44Gg44GV44GE44CCJyA6ICfmt7vku5jjg5XjgqHjgqTjg6vjga815Lu25Lul5YaF44Gn6YG45oqe44GX44Gm44GP44Gg44GV44GE44CCJ1xuICBmb3IgKGNvbnN0IGZpbGUgb2YgbGlzdCkge1xuICAgIGlmICghYWxsb3dlZC5pbmNsdWRlcyhnZXRFeHRlbnNpb24oZmlsZS5uYW1lKSkpIGVycm9yc1trZXldID0gaXNJbWFnZSA/ICfjgqLjg4Pjg5fjg63jg7zjg4njgafjgY3jgovnlLvlg4/lvaLlvI/jga8ganBnLCBqcGVnLCBwbmcsIGdpZiwgd2VicCDjgafjgZnjgIInIDogJ+a3u+S7mOOBp+OBjeOCi+ODleOCoeOCpOODq+W9ouW8j+OBryBwZGYsIHR4dCwgY3N2LCBkb2N4LCB4bHN4IOOBp+OBmeOAgidcbiAgICBpZiAoZmlsZS5zaXplID4gbWF4U2l6ZSkgZXJyb3JzW2tleV0gPSBpc0ltYWdlID8gJ+eUu+WDj+OBrzHjg5XjgqHjgqTjg6s1TULku6XlhoXjgafpgbjmip7jgZfjgabjgY/jgaDjgZXjgYTjgIInIDogJ+a3u+S7mOODleOCoeOCpOODq+OBrzHjg5XjgqHjgqTjg6sxME1C5Lul5YaF44Gn6YG45oqe44GX44Gm44GP44Gg44GV44GE44CCJ1xuICB9XG4gIHJldHVybiBlcnJvcnNcbn1cblxuZnVuY3Rpb24gZmlsZVRvVXBsb2FkKGZpbGUpIHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpXG4gICAgcmVhZGVyLm9ubG9hZCA9ICgpID0+IHJlc29sdmUoeyBuYW1lOiBmaWxlLm5hbWUsIHR5cGU6IGZpbGUudHlwZSB8fCAnYXBwbGljYXRpb24vb2N0ZXQtc3RyZWFtJywgc2l6ZTogZmlsZS5zaXplLCBjb250ZW50OiByZWFkZXIucmVzdWx0IH0pXG4gICAgcmVhZGVyLm9uZXJyb3IgPSByZWplY3RcbiAgICByZWFkZXIucmVhZEFzRGF0YVVSTChmaWxlKVxuICB9KVxufVxuXG5mdW5jdGlvbiB2YWxpZGF0ZU1lbW8oZm9ybSkge1xuICBjb25zdCBlcnJvcnMgPSB7fVxuICBpZiAoIWZvcm0udGl0bGUgfHwgZm9ybS50aXRsZS50cmltKCkubGVuZ3RoID09PSAwKSBlcnJvcnMudGl0bGUgPSAn44K/44Kk44OI44Or44KS5YWl5Yqb44GX44Gm44GP44Gg44GV44GE44CCJ1xuICBlbHNlIGlmIChmb3JtLnRpdGxlLmxlbmd0aCA+IDEwMCkgZXJyb3JzLnRpdGxlID0gJ+OCv+OCpOODiOODq+OBrzEwMOaWh+Wtl+S7peWGheOBp+WFpeWKm+OBl+OBpuOBj+OBoOOBleOBhOOAgidcbiAgaWYgKCFmb3JtLmJvZHkgfHwgZm9ybS5ib2R5LnRyaW0oKS5sZW5ndGggPT09IDApIGVycm9ycy5ib2R5ID0gJ+acrOaWh+OCkuWFpeWKm+OBl+OBpuOBj+OBoOOBleOBhOOAgidcbiAgZWxzZSBpZiAoZm9ybS5ib2R5Lmxlbmd0aCA+IDIwMDApIGVycm9ycy5ib2R5ID0gJ+acrOaWh+OBrzIwMDDmloflrZfku6XlhoXjgaflhaXlipvjgZfjgabjgY/jgaDjgZXjgYTjgIInXG4gIHJldHVybiBlcnJvcnNcbn1cblxuZnVuY3Rpb24gdmFsaWRhdGVMb2dpbihmb3JtKSB7XG4gIGNvbnN0IGVycm9ycyA9IHt9XG4gIGlmICghZm9ybS51c2VySWQudHJpbSgpKSBlcnJvcnMudXNlcklkID0gJ+ODpuODvOOCtuODvElE44KS5YWl5Yqb44GX44Gm44GP44Gg44GV44GE44CCJ1xuICBlbHNlIGlmICghL15bYS16QS1aMC05Xy1dKyQvLnRlc3QoZm9ybS51c2VySWQpKSBlcnJvcnMudXNlcklkID0gJ+ODpuODvOOCtuODvElE44Gv5Y2K6KeS6Iux5pWw5a2X44CB44OP44Kk44OV44Oz44CB44Ki44Oz44OA44O844K544Kz44Ki44Gn5YWl5Yqb44GX44Gm44GP44Gg44GV44GE44CCJ1xuICBlbHNlIGlmIChmb3JtLnVzZXJJZC5sZW5ndGggPCA0IHx8IGZvcm0udXNlcklkLmxlbmd0aCA+IDIwKSBlcnJvcnMudXNlcklkID0gJ+ODpuODvOOCtuODvElE44GvNOaWh+Wtl+S7peS4ijIw5paH5a2X5Lul5YaF44Gn5YWl5Yqb44GX44Gm44GP44Gg44GV44GE44CCJ1xuICBpZiAoIWZvcm0ucGFzc3dvcmQpIGVycm9ycy5wYXNzd29yZCA9ICfjg5Hjgrnjg6/jg7zjg4njgpLlhaXlipvjgZfjgabjgY/jgaDjgZXjgYTjgIInXG4gIGVsc2UgaWYgKGZvcm0ucGFzc3dvcmQubGVuZ3RoIDwgOCB8fCBmb3JtLnBhc3N3b3JkLmxlbmd0aCA+IDY0KSBlcnJvcnMucGFzc3dvcmQgPSAn44OR44K544Ov44O844OJ44GvOOaWh+Wtl+S7peS4ijY05paH5a2X5Lul5YaF44Gn5YWl5Yqb44GX44Gm44GP44Gg44GV44GE44CCJ1xuICByZXR1cm4gZXJyb3JzXG59XG5cbmZ1bmN0aW9uIEFwcCgpIHtcbiAgY29uc3QgW3Rva2VuLCBzZXRUb2tlbl0gPSB1c2VTdGF0ZSgoKSA9PiBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnbWVtb1BhZFRva2VuJykgfHwgJycpXG4gIGNvbnN0IFtjdXJyZW50VXNlciwgc2V0Q3VycmVudFVzZXJdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2xvZ2luRm9ybSwgc2V0TG9naW5Gb3JtXSA9IHVzZVN0YXRlKHsgdXNlcklkOiAnYWRtaW4nLCBwYXNzd29yZDogJ3Bhc3N3b3JkMTIzJyB9KVxuICBjb25zdCBbbG9naW5FcnJvcnMsIHNldExvZ2luRXJyb3JzXSA9IHVzZVN0YXRlKHt9KVxuICBjb25zdCBbbWVtb3MsIHNldE1lbW9zXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbdG90YWwsIHNldFRvdGFsXSA9IHVzZVN0YXRlKDApXG4gIGNvbnN0IFtzZWxlY3RlZE1lbW8sIHNldFNlbGVjdGVkTWVtb10gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbbWVtb0Zvcm0sIHNldE1lbW9Gb3JtXSA9IHVzZVN0YXRlKGVtcHR5TWVtbylcbiAgY29uc3QgW3BlbmRpbmdBdHRhY2htZW50cywgc2V0UGVuZGluZ0F0dGFjaG1lbnRzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbcGVuZGluZ0ltYWdlcywgc2V0UGVuZGluZ0ltYWdlc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW2ZpbGVFcnJvcnMsIHNldEZpbGVFcnJvcnNdID0gdXNlU3RhdGUoe30pXG4gIGNvbnN0IFtpbWFnZVVybHMsIHNldEltYWdlVXJsc10gPSB1c2VTdGF0ZSh7fSlcbiAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW3RhZ3MsIHNldFRhZ3NdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtzZWxlY3RlZFVzZXIsIHNldFNlbGVjdGVkVXNlcl0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbdXNlckZvcm0sIHNldFVzZXJGb3JtXSA9IHVzZVN0YXRlKGVtcHR5VXNlcilcbiAgY29uc3QgW3VzZXJFcnJvcnMsIHNldFVzZXJFcnJvcnNdID0gdXNlU3RhdGUoe30pXG4gIGNvbnN0IFttb2RlLCBzZXRNb2RlXSA9IHVzZVN0YXRlKCdsaXN0JylcbiAgY29uc3QgW2Rpc3BsYXlNb2RlLCBzZXREaXNwbGF5TW9kZV0gPSB1c2VTdGF0ZSgnbGlzdCcpXG4gIGNvbnN0IFtmaWx0ZXJzLCBzZXRGaWx0ZXJzXSA9IHVzZVN0YXRlKGluaXRpYWxGaWx0ZXJzKVxuICBjb25zdCBbZm9ybUVycm9ycywgc2V0Rm9ybUVycm9yc10gPSB1c2VTdGF0ZSh7fSlcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtnbG9iYWxFcnJvciwgc2V0R2xvYmFsRXJyb3JdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW2lzU2F2aW5nLCBzZXRJc1NhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSlcclxuICBjb25zdCBbZHJhZnRTdGF0dXMsIHNldERyYWZ0U3RhdHVzXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtmb3JtVG91Y2hlZCwgc2V0Rm9ybVRvdWNoZWRdID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgY29uc3QgYXV0b3NhdmVUaW1lclJlZiA9IHVzZVJlZihudWxsKVxyXG4gIGNvbnN0IGF1dG9zYXZlU2VxUmVmID0gdXNlUmVmKDApXHJcbiAgY29uc3QgbGFzdERyYWZ0UGF5bG9hZFJlZiA9IHVzZVJlZignJylcblxuICBjb25zdCBhdXRoSGVhZGVycyA9IHVzZU1lbW8oKCkgPT4gdG9rZW4gPyB7IEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHt0b2tlbn1gIH0gOiB7fSwgW3Rva2VuXSlcbiAgY29uc3QgcGFnZUNvdW50ID0gTWF0aC5tYXgoMSwgTWF0aC5jZWlsKHRvdGFsIC8gZmlsdGVycy5saW1pdCkpXG5cbiAgY29uc3QgaGFuZGxlTG9nZ2VkT3V0ID0gKCkgPT4ge1xuICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdtZW1vUGFkVG9rZW4nKVxuICAgIHNldFRva2VuKCcnKVxuICAgIHNldEN1cnJlbnRVc2VyKG51bGwpXG4gICAgc2V0TW9kZSgnbGlzdCcpXG4gIH1cblxuICBjb25zdCByZXF1ZXN0SnNvbiA9IGFzeW5jIChwYXRoLCBvcHRpb25zID0ge30pID0+IHtcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0FQSV9CQVNFfSR7cGF0aH1gLCB7IC4uLm9wdGlvbnMsIGhlYWRlcnM6IHsgLi4uYXV0aEhlYWRlcnMsIC4uLihvcHRpb25zLmhlYWRlcnMgfHwge30pIH0gfSlcbiAgICBjb25zdCBkYXRhID0gcmVzcG9uc2Uuc3RhdHVzID09PSAyMDQgPyBudWxsIDogYXdhaXQgcmVzcG9uc2UuanNvbigpLmNhdGNoKCgpID0+IG51bGwpXG4gICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgY29uc3QgZXJyb3IgPSBuZXcgRXJyb3IoZGF0YT8ubWVzc2FnZSB8fCAnc2VydmVyJylcbiAgICAgIGVycm9yLnN0YXR1cyA9IHJlc3BvbnNlLnN0YXR1c1xuICAgICAgZXJyb3IuZGF0YSA9IGRhdGFcbiAgICAgIHRocm93IGVycm9yXG4gICAgfVxuICAgIHJldHVybiBkYXRhXG4gIH1cblxuICBjb25zdCBsb2FkTWVtb3MgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCF0b2tlbikgcmV0dXJuXG4gICAgc2V0SXNMb2FkaW5nKHRydWUpXG4gICAgc2V0R2xvYmFsRXJyb3IoJycpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoeyBrZXl3b3JkOiBmaWx0ZXJzLmtleXdvcmQsIHBhZ2U6IFN0cmluZyhmaWx0ZXJzLnBhZ2UpLCBsaW1pdDogU3RyaW5nKGZpbHRlcnMubGltaXQpLCBzb3J0Qnk6IGZpbHRlcnMuc29ydEJ5LCBvcmRlcjogZmlsdGVycy5vcmRlciwgZmF2b3JpdGU6IFN0cmluZyhmaWx0ZXJzLmZhdm9yaXRlKSwgdGFnOiBmaWx0ZXJzLnRhZyB9KVxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcXVlc3RKc29uKGAvdG9kb3M/JHtwYXJhbXMudG9TdHJpbmcoKX1gKVxuICAgICAgc2V0TWVtb3MoZGF0YS5pdGVtcylcbiAgICAgIHNldFRvdGFsKGRhdGEudG90YWwpXG4gICAgICBhd2FpdCBsb2FkVGFncygpXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChlcnJvci5zdGF0dXMgPT09IDQwMSkgaGFuZGxlTG9nZ2VkT3V0KClcbiAgICAgIGVsc2Ugc2V0R2xvYmFsRXJyb3IoJ+mAmuS/oeOBq+WkseaVl+OBl+OBvuOBl+OBn+OAguODjeODg+ODiOODr+ODvOOCr+aOpee2muOCkueiuuiqjeOBl+OBpuOBj+OBoOOBleOBhOOAgicpXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSlcbiAgICB9XG4gIH1cblxuXG5cbiAgY29uc3QgbG9hZFRhZ3MgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCF0b2tlbikgcmV0dXJuXG4gICAgdHJ5IHsgc2V0VGFncyhhd2FpdCByZXF1ZXN0SnNvbignL3RhZ3MnKSkgfVxuICAgIGNhdGNoIChlcnJvcikgeyAvKiDjgr/jgrDlj5blvpflpLHmlZfjga/kuIDopqfmk43kvZzjgpLlhKrlhYjjgZnjgovjgIIgKi8gfVxuICB9XG5cbiAgY29uc3QgbG9hZFVzZXJzID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldEdsb2JhbEVycm9yKCcnKVxuICAgIHRyeSB7XG4gICAgICBzZXRVc2Vycyhhd2FpdCByZXF1ZXN0SnNvbignL3VzZXJzJykpXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChlcnJvci5zdGF0dXMgPT09IDQwMykge1xuICAgICAgICBzZXRNb2RlKCdsaXN0JylcbiAgICAgICAgc2V0R2xvYmFsRXJyb3IoJ+OCouOCr+OCu+OCueaoqemZkOOBjOOBguOCiuOBvuOBm+OCk+OAgicpXG4gICAgICB9IGVsc2Ugc2V0R2xvYmFsRXJyb3IoJ+mAmuS/oeOBq+WkseaVl+OBl+OBvuOBl+OBn+OAguODjeODg+ODiOODr+ODvOOCr+aOpee2muOCkueiuuiqjeOBl+OBpuOBj+OBoOOBleOBhOOAgicpXG4gICAgfVxuICB9XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBsb2FkTWUgPSBhc3luYyAoKSA9PiB7XG4gICAgICBpZiAoIXRva2VuKSByZXR1cm5cbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXF1ZXN0SnNvbignL21lJylcbiAgICAgICAgc2V0Q3VycmVudFVzZXIoZGF0YS51c2VyKVxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgaGFuZGxlTG9nZ2VkT3V0KClcbiAgICAgIH1cbiAgICB9XG4gICAgbG9hZE1lKClcbiAgfSwgW3Rva2VuXSlcblxuICB1c2VFZmZlY3QoKCkgPT4geyBpZiAoY3VycmVudFVzZXIpIGxvYWRNZW1vcygpIH0sIFtjdXJyZW50VXNlciwgZmlsdGVyc10pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjbGVhckF1dG9zYXZlVGltZXIoKVxuICAgIGlmICghY3VycmVudFVzZXIgfHwgIShtb2RlID09PSAnY3JlYXRlJyB8fCBtb2RlID09PSAnZWRpdCcpKSByZXR1cm5cbiAgICBsZXQgY2FuY2VsbGVkID0gZmFsc2VcbiAgICBjb25zdCBsb2FkRHJhZnQgPSBhc3luYyAoKSA9PiB7XG4gICAgICBzZXREcmFmdFN0YXR1cygnJylcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXF1ZXN0SnNvbihkcmFmdFBhdGgpXG4gICAgICAgIGlmIChjYW5jZWxsZWQgfHwgIWRhdGE/LmRyYWZ0KSB7XG4gICAgICAgICAgbGFzdERyYWZ0UGF5bG9hZFJlZi5jdXJyZW50ID0gc2VyaWFsaXplRHJhZnRQYXlsb2FkKGJ1aWxkRHJhZnRQYXlsb2FkKCkpXG4gICAgICAgICAgcmV0dXJuXG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc3RhbGVNZXNzYWdlID0gZGF0YS5kcmFmdC5pc1N0YWxlID8gJ+S7luOBruODpuODvOOCtuODvOOBq+OCiOOBo+OBpuWFg+OBruODoeODouOBjOabtOaWsOOBleOCjOOBpuOBhOOBvuOBmeOAguW+qeWFg+W+jOOBr+WGheWuueOCkueiuuiqjeOBl+OBpuOBj+OBoOOBleOBhOOAgicgOiAnJ1xuICAgICAgICBpZiAod2luZG93LmNvbmZpcm0oYCR7c3RhbGVNZXNzYWdlfSR7c3RhbGVNZXNzYWdlID8gJ1xcbicgOiAnJ33kv53lrZjjgZXjgozjgabjgYTjgarjgYTkuIvmm7jjgY3jgYzjgYLjgorjgb7jgZnjgILlvqnlhYPjgZfjgb7jgZnjgYvvvJ9gKSkge1xuICAgICAgICAgIGNvbnN0IHJlc3RvcmVkID0geyB0aXRsZTogZGF0YS5kcmFmdC50aXRsZSwgYm9keTogZGF0YS5kcmFmdC5ib2R5LCB0YWdzVGV4dDogZGF0YS5kcmFmdC50YWdzVGV4dCB9XG4gICAgICAgICAgc2V0TWVtb0Zvcm0ocmVzdG9yZWQpXG4gICAgICAgICAgc2V0RHJhZnRTdGF0dXMoJ+S4i+abuOOBjeOCkuW+qeWFg+OBl+OBvuOBl+OBn+OAgicpXG4gICAgICAgICAgbGFzdERyYWZ0UGF5bG9hZFJlZi5jdXJyZW50ID0gc2VyaWFsaXplRHJhZnRQYXlsb2FkKHsgbWVtb0lkOiBkcmFmdE1lbW9JZCwgLi4ucmVzdG9yZWQsIGJhc2VVcGRhdGVkQXQ6IHNlbGVjdGVkTWVtbz8udXBkYXRlZEF0IHx8IG51bGwgfSlcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBhd2FpdCBkZWxldGVDdXJyZW50RHJhZnQoKVxuICAgICAgICAgIGxhc3REcmFmdFBheWxvYWRSZWYuY3VycmVudCA9IHNlcmlhbGl6ZURyYWZ0UGF5bG9hZChidWlsZERyYWZ0UGF5bG9hZCgpKVxuICAgICAgICB9XG4gICAgICAgIHNldEZvcm1Ub3VjaGVkKGZhbHNlKVxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgbGFzdERyYWZ0UGF5bG9hZFJlZi5jdXJyZW50ID0gc2VyaWFsaXplRHJhZnRQYXlsb2FkKGJ1aWxkRHJhZnRQYXlsb2FkKCkpXG4gICAgICB9XG4gICAgfVxuICAgIGxvYWREcmFmdCgpXG4gICAgcmV0dXJuICgpID0+IHsgY2FuY2VsbGVkID0gdHJ1ZTsgY2xlYXJBdXRvc2F2ZVRpbWVyKCkgfVxuICB9LCBbY3VycmVudFVzZXIsIG1vZGUsIHNlbGVjdGVkTWVtbz8uaWRdKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY2xlYXJBdXRvc2F2ZVRpbWVyKClcbiAgICBpZiAoIWN1cnJlbnRVc2VyIHx8ICEobW9kZSA9PT0gJ2NyZWF0ZScgfHwgbW9kZSA9PT0gJ2VkaXQnKSB8fCBpc1NhdmluZyB8fCAhZm9ybVRvdWNoZWQpIHJldHVyblxuICAgIGlmIChtb2RlID09PSAnY3JlYXRlJyAmJiAhaGFzRHJhZnRDb250ZW50KG1lbW9Gb3JtKSkgcmV0dXJuXG4gICAgY29uc3QgcGF5bG9hZCA9IGJ1aWxkRHJhZnRQYXlsb2FkKClcbiAgICBjb25zdCBzZXJpYWxpemVkID0gc2VyaWFsaXplRHJhZnRQYXlsb2FkKHBheWxvYWQpXG4gICAgaWYgKHNlcmlhbGl6ZWQgPT09IGxhc3REcmFmdFBheWxvYWRSZWYuY3VycmVudCkgcmV0dXJuXG4gICAgYXV0b3NhdmVUaW1lclJlZi5jdXJyZW50ID0gc2V0VGltZW91dChhc3luYyAoKSA9PiB7XG4gICAgICBjb25zdCBzZXEgPSBhdXRvc2F2ZVNlcVJlZi5jdXJyZW50ICsgMVxuICAgICAgYXV0b3NhdmVTZXFSZWYuY3VycmVudCA9IHNlcVxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcXVlc3RKc29uKCcvZHJhZnRzJywgeyBtZXRob2Q6ICdQT1NUJywgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sIGJvZHk6IEpTT04uc3RyaW5naWZ5KHBheWxvYWQpIH0pXG4gICAgICAgIGlmIChzZXEgPT09IGF1dG9zYXZlU2VxUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICBsYXN0RHJhZnRQYXlsb2FkUmVmLmN1cnJlbnQgPSBzZXJpYWxpemVkXG4gICAgICAgICAgc2V0RHJhZnRTdGF0dXMoZGF0YT8ubWVzc2FnZSB8fCAn5LiL5pu444GN44KS5L+d5a2Y44GX44G+44GX44Gf44CCJylcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgaWYgKHNlcSA9PT0gYXV0b3NhdmVTZXFSZWYuY3VycmVudCkgc2V0RHJhZnRTdGF0dXMoJ+S4i+abuOOBjeS/neWtmOOBq+WkseaVl+OBl+OBvuOBl+OBn+OAgicpXG4gICAgICB9XG4gICAgfSwgMzAwMClcbiAgICByZXR1cm4gY2xlYXJBdXRvc2F2ZVRpbWVyXG4gIH0sIFttZW1vRm9ybSwgbW9kZSwgc2VsZWN0ZWRNZW1vPy5pZCwgc2VsZWN0ZWRNZW1vPy51cGRhdGVkQXQsIGN1cnJlbnRVc2VyLCBpc1NhdmluZywgZm9ybVRvdWNoZWRdKVxuXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsZXQgYWN0aXZlID0gdHJ1ZVxuICAgIGNvbnN0IHVybHMgPSBbXVxuICAgIGNvbnN0IGxvYWRJbWFnZVVybHMgPSBhc3luYyAoKSA9PiB7XG4gICAgICBjb25zdCBpbWFnZXMgPSBzZWxlY3RlZE1lbW8/LmltYWdlcyB8fCBbXVxuICAgICAgaWYgKGltYWdlcy5sZW5ndGggPT09IDApIHsgc2V0SW1hZ2VVcmxzKHt9KTsgcmV0dXJuIH1cbiAgICAgIGNvbnN0IGVudHJpZXMgPSBhd2FpdCBQcm9taXNlLmFsbChpbWFnZXMubWFwKGFzeW5jIChmaWxlKSA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgYmxvYiA9IGF3YWl0IGZldGNoRmlsZUJsb2IoZmlsZSlcbiAgICAgICAgICBjb25zdCB1cmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpXG4gICAgICAgICAgdXJscy5wdXNoKHVybClcbiAgICAgICAgICByZXR1cm4gW2ZpbGUuaWQsIHVybF1cbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICByZXR1cm4gW2ZpbGUuaWQsICcnXVxuICAgICAgICB9XG4gICAgICB9KSlcbiAgICAgIGlmIChhY3RpdmUpIHNldEltYWdlVXJscyhPYmplY3QuZnJvbUVudHJpZXMoZW50cmllcykpXG4gICAgfVxuICAgIGxvYWRJbWFnZVVybHMoKVxuICAgIHJldHVybiAoKSA9PiB7IGFjdGl2ZSA9IGZhbHNlOyB1cmxzLmZvckVhY2goKHVybCkgPT4gVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpKSB9XG4gIH0sIFtzZWxlY3RlZE1lbW8/LmlkLCBzZWxlY3RlZE1lbW8/LmltYWdlcywgdG9rZW5dKVxuXG4gIGNvbnN0IGxvZ2luID0gYXN5bmMgKGV2ZW50KSA9PiB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxuICAgIGNvbnN0IGVycm9ycyA9IHZhbGlkYXRlTG9naW4obG9naW5Gb3JtKVxuICAgIHNldExvZ2luRXJyb3JzKGVycm9ycylcbiAgICBzZXRHbG9iYWxFcnJvcignJylcbiAgICBpZiAoT2JqZWN0LmtleXMoZXJyb3JzKS5sZW5ndGggPiAwKSByZXR1cm5cbiAgICBzZXRJc1NhdmluZyh0cnVlKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0FQSV9CQVNFfS9sb2dpbmAsIHsgbWV0aG9kOiAnUE9TVCcsIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9LCBib2R5OiBKU09OLnN0cmluZ2lmeShsb2dpbkZvcm0pIH0pXG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpLmNhdGNoKCgpID0+IG51bGwpXG4gICAgICBpZiAoIXJlc3BvbnNlLm9rKSB0aHJvdyBuZXcgRXJyb3IoZGF0YT8ubWVzc2FnZSB8fCAnbG9naW4nKVxuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ21lbW9QYWRUb2tlbicsIGRhdGEudG9rZW4pXG4gICAgICBzZXRUb2tlbihkYXRhLnRva2VuKVxuICAgICAgc2V0Q3VycmVudFVzZXIoZGF0YS51c2VyKVxuICAgICAgc2V0TWVzc2FnZSgn44Ot44Kw44Kk44Oz44GX44G+44GX44Gf44CCJylcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgc2V0R2xvYmFsRXJyb3IoJ+ODpuODvOOCtuODvElE44G+44Gf44Gv44OR44K544Ov44O844OJ44GM5q2j44GX44GP44GC44KK44G+44Gb44KT44CCJylcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNTYXZpbmcoZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgbG9nb3V0ID0gYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7IGlmICh0b2tlbikgYXdhaXQgcmVxdWVzdEpzb24oJy9sb2dvdXQnLCB7IG1ldGhvZDogJ1BPU1QnIH0pIH0gY2F0Y2ggKGVycm9yKSB7IC8qIGxvY2FsIGxvZ291dCBmaXJzdCAqLyB9XG4gICAgaGFuZGxlTG9nZ2VkT3V0KClcbiAgICBzZXRNZXNzYWdlKCcnKVxuICB9XG5cbiAgY29uc3QgdXBkYXRlRmlsdGVycyA9IChwYXRjaCkgPT4gc2V0RmlsdGVycygoY3VycmVudCkgPT4gKHsgLi4uY3VycmVudCwgLi4ucGF0Y2gsIHBhZ2U6IHBhdGNoLnBhZ2UgfHwgMSB9KSlcbiAgY29uc3QgZHJhZnRNZW1vSWQgPSBtb2RlID09PSAnZWRpdCcgJiYgc2VsZWN0ZWRNZW1vID8gc2VsZWN0ZWRNZW1vLmlkIDogbnVsbFxuICBjb25zdCBkcmFmdFBhdGggPSBkcmFmdE1lbW9JZCA/IGAvZHJhZnRzL21lbW9zLyR7ZHJhZnRNZW1vSWR9YCA6ICcvZHJhZnRzL25ldydcbiAgY29uc3QgYnVpbGREcmFmdFBheWxvYWQgPSAoKSA9PiAoeyBtZW1vSWQ6IGRyYWZ0TWVtb0lkLCB0aXRsZTogbWVtb0Zvcm0udGl0bGUsIGJvZHk6IG1lbW9Gb3JtLmJvZHksIHRhZ3NUZXh0OiBtZW1vRm9ybS50YWdzVGV4dCwgYmFzZVVwZGF0ZWRBdDogc2VsZWN0ZWRNZW1vPy51cGRhdGVkQXQgfHwgbnVsbCB9KVxuICBjb25zdCBzZXJpYWxpemVEcmFmdFBheWxvYWQgPSAocGF5bG9hZCkgPT4gSlNPTi5zdHJpbmdpZnkocGF5bG9hZClcbiAgY29uc3QgaGFzRHJhZnRDb250ZW50ID0gKGZvcm0pID0+IEJvb2xlYW4oZm9ybS50aXRsZSB8fCBmb3JtLmJvZHkgfHwgZm9ybS50YWdzVGV4dClcbiAgY29uc3Qgc2V0TWVtb0ZpZWxkID0gKGZpZWxkLCB2YWx1ZSkgPT4geyBzZXRNZW1vRm9ybSgoY3VycmVudCkgPT4gKHsgLi4uY3VycmVudCwgW2ZpZWxkXTogdmFsdWUgfSkpOyBzZXRGb3JtVG91Y2hlZCh0cnVlKTsgc2V0RHJhZnRTdGF0dXMoJycpIH1cbiAgY29uc3QgY2xlYXJBdXRvc2F2ZVRpbWVyID0gKCkgPT4geyBpZiAoYXV0b3NhdmVUaW1lclJlZi5jdXJyZW50KSB7IGNsZWFyVGltZW91dChhdXRvc2F2ZVRpbWVyUmVmLmN1cnJlbnQpOyBhdXRvc2F2ZVRpbWVyUmVmLmN1cnJlbnQgPSBudWxsIH0gfVxuICBjb25zdCBkZWxldGVDdXJyZW50RHJhZnQgPSBhc3luYyAoKSA9PiB7IHRyeSB7IGF3YWl0IHJlcXVlc3RKc29uKGRyYWZ0UGF0aCwgeyBtZXRob2Q6ICdERUxFVEUnIH0pIH0gY2F0Y2ggKGVycm9yKSB7IC8qIOS4i+abuOOBjeWJiumZpOWkseaVl+OBr+eUu+mdoumBt+enu+OCkuWEquWFiOOBmeOCi+OAgiAqLyB9IH1cblxuICBjb25zdCBmZXRjaEZpbGVCbG9iID0gYXN5bmMgKGZpbGUpID0+IHtcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKEFQSV9CQVNFICsgZmlsZS5kb3dubG9hZFVybCwgeyBoZWFkZXJzOiBhdXRoSGVhZGVycyB9KVxuICAgIGlmICghcmVzcG9uc2Uub2spIHRocm93IG5ldyBFcnJvcignZG93bmxvYWQnKVxuICAgIHJldHVybiByZXNwb25zZS5ibG9iKClcbiAgfVxuICBjb25zdCBkb3dubG9hZEZpbGUgPSBhc3luYyAoZmlsZSkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBibG9iID0gYXdhaXQgZmV0Y2hGaWxlQmxvYihmaWxlKVxuICAgICAgY29uc3QgdXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKVxuICAgICAgY29uc3QgbGluayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKVxuICAgICAgbGluay5ocmVmID0gdXJsXG4gICAgICBsaW5rLmRvd25sb2FkID0gZmlsZS5vcmlnaW5hbE5hbWVcbiAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQobGluaylcbiAgICAgIGxpbmsuY2xpY2soKVxuICAgICAgbGluay5yZW1vdmUoKVxuICAgICAgVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHNldEdsb2JhbEVycm9yKCfpgJrkv6HjgavlpLHmlZfjgZfjgb7jgZfjgZ/jgILjg43jg4Pjg4jjg6/jg7zjgq/mjqXntprjgpLnorroqo3jgZfjgabjgY/jgaDjgZXjgYTjgIInKVxuICAgIH1cbiAgfVxuICBjb25zdCByZWZyZXNoU2VsZWN0ZWRNZW1vID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICghc2VsZWN0ZWRNZW1vKSByZXR1cm5cbiAgICBjb25zdCBtZW1vID0gYXdhaXQgcmVxdWVzdEpzb24oJy90b2Rvcy8nICsgc2VsZWN0ZWRNZW1vLmlkKVxuICAgIHNldFNlbGVjdGVkTWVtbyhtZW1vKVxuICB9XG4gIGNvbnN0IGRlbGV0ZUV4aXN0aW5nRmlsZSA9IGFzeW5jIChmaWxlKSA9PiB7XG4gICAgaWYgKCF3aW5kb3cuY29uZmlybShmaWxlLm9yaWdpbmFsTmFtZSArICcg44KS5YmK6Zmk44GX44G+44GZ44GL77yfJykpIHJldHVyblxuICAgIHRyeSB7XG4gICAgICBhd2FpdCByZXF1ZXN0SnNvbignL2ZpbGVzLycgKyBmaWxlLmlkLCB7IG1ldGhvZDogJ0RFTEVURScgfSlcbiAgICAgIGF3YWl0IHJlZnJlc2hTZWxlY3RlZE1lbW8oKVxuICAgICAgc2V0TWVzc2FnZSgn44OV44Kh44Kk44Or44KS5YmK6Zmk44GX44G+44GX44Gf44CCJylcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgc2V0R2xvYmFsRXJyb3IoZXJyb3IubWVzc2FnZSB8fCAn5Yem55CG5Lit44Gr44Ko44Op44O844GM55m655Sf44GX44G+44GX44Gf44CC5pmC6ZaT44KS44GK44GE44Gm5YaN5bqm44GK6Kmm44GX44GP44Gg44GV44GE44CCJylcbiAgICB9XG4gIH1cbiAgY29uc3QgYWRkUGVuZGluZ0ZpbGVzID0gKGV2ZW50LCB0eXBlKSA9PiB7XG4gICAgY29uc3Qgc2VsZWN0ZWQgPSBBcnJheS5mcm9tKGV2ZW50LnRhcmdldC5maWxlcyB8fCBbXSlcbiAgICBjb25zdCBpc0ltYWdlID0gdHlwZSA9PT0gJ2ltYWdlJ1xuICAgIGNvbnN0IGV4aXN0aW5nQ291bnQgPSBpc0ltYWdlID8gKHNlbGVjdGVkTWVtbz8uaW1hZ2VzIHx8IFtdKS5sZW5ndGggOiAoc2VsZWN0ZWRNZW1vPy5hdHRhY2htZW50cyB8fCBbXSkubGVuZ3RoXG4gICAgY29uc3QgY3VycmVudCA9IGlzSW1hZ2UgPyBwZW5kaW5nSW1hZ2VzIDogcGVuZGluZ0F0dGFjaG1lbnRzXG4gICAgY29uc3QgbmV4dCA9IFsuLi5jdXJyZW50LCAuLi5zZWxlY3RlZF1cbiAgICBjb25zdCBlcnJvcnMgPSB2YWxpZGF0ZVNlbGVjdGVkRmlsZXMobmV4dCwgZXhpc3RpbmdDb3VudCwgdHlwZSlcbiAgICBjb25zdCBrZXkgPSBpc0ltYWdlID8gJ2ltYWdlcycgOiAnYXR0YWNobWVudHMnXG4gICAgc2V0RmlsZUVycm9ycygoY3VycmVudEVycm9ycykgPT4gKHsgLi4uY3VycmVudEVycm9ycywgW2tleV06IGVycm9yc1trZXldIHx8ICcnIH0pKVxuICAgIGlmIChpc0ltYWdlKSBzZXRQZW5kaW5nSW1hZ2VzKG5leHQpXG4gICAgZWxzZSBzZXRQZW5kaW5nQXR0YWNobWVudHMobmV4dClcbiAgICBldmVudC50YXJnZXQudmFsdWUgPSAnJ1xuICB9XG4gIGNvbnN0IHJlbW92ZVBlbmRpbmdGaWxlID0gKGluZGV4LCB0eXBlKSA9PiB7XG4gICAgaWYgKHR5cGUgPT09ICdpbWFnZScpIHNldFBlbmRpbmdJbWFnZXMoKGN1cnJlbnQpID0+IGN1cnJlbnQuZmlsdGVyKChfLCBpKSA9PiBpICE9PSBpbmRleCkpXG4gICAgZWxzZSBzZXRQZW5kaW5nQXR0YWNobWVudHMoKGN1cnJlbnQpID0+IGN1cnJlbnQuZmlsdGVyKChfLCBpKSA9PiBpICE9PSBpbmRleCkpXG4gICAgc2V0RmlsZUVycm9ycyh7fSlcbiAgfVxuICBjb25zdCBjbGVhckZpbGVJbnB1dHMgPSAoKSA9PiB7IHNldFBlbmRpbmdBdHRhY2htZW50cyhbXSk7IHNldFBlbmRpbmdJbWFnZXMoW10pOyBzZXRGaWxlRXJyb3JzKHt9KTsgc2V0SW1hZ2VVcmxzKHt9KSB9XG5cbiAgY29uc3Qgb3BlblVzZXJMaXN0ID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmIChjdXJyZW50VXNlci5yb2xlICE9PSAnYWRtaW4nKSB7IHNldE1vZGUoJ2xpc3QnKTsgc2V0R2xvYmFsRXJyb3IoJ+OCouOCr+OCu+OCueaoqemZkOOBjOOBguOCiuOBvuOBm+OCk+OAgicpOyByZXR1cm4gfVxuICAgIHNldE1vZGUoJ3VzZXJzJyk7IHNldE1lc3NhZ2UoJycpOyBzZXRVc2VyRXJyb3JzKHt9KTsgYXdhaXQgbG9hZFVzZXJzKClcbiAgfVxuICBjb25zdCBzdGFydENyZWF0ZSA9ICgpID0+IHsgY2xlYXJBdXRvc2F2ZVRpbWVyKCk7IHNldFNlbGVjdGVkTWVtbyhudWxsKTsgc2V0TWVtb0Zvcm0oZW1wdHlNZW1vKTsgY2xlYXJGaWxlSW5wdXRzKCk7IHNldEZvcm1Ub3VjaGVkKGZhbHNlKTsgbGFzdERyYWZ0UGF5bG9hZFJlZi5jdXJyZW50ID0gJyc7IHNldERyYWZ0U3RhdHVzKCcnKTsgc2V0Rm9ybUVycm9ycyh7fSk7IHNldE1lc3NhZ2UoJycpOyBzZXRHbG9iYWxFcnJvcignJyk7IHNldE1vZGUoJ2NyZWF0ZScpIH1cbiAgY29uc3Qgc3RhcnRFZGl0ID0gYXN5bmMgKG1lbW8pID0+IHsgY2xlYXJBdXRvc2F2ZVRpbWVyKCk7IGNvbnN0IGZ1bGxNZW1vID0gbWVtby5hdHRhY2htZW50cyA/IG1lbW8gOiBhd2FpdCByZXF1ZXN0SnNvbignL3RvZG9zLycgKyBtZW1vLmlkKTsgc2V0U2VsZWN0ZWRNZW1vKGZ1bGxNZW1vKTsgc2V0TWVtb0Zvcm0oeyB0aXRsZTogZnVsbE1lbW8udGl0bGUsIGJvZHk6IGZ1bGxNZW1vLmJvZHksIHRhZ3NUZXh0OiAoZnVsbE1lbW8udGFncyB8fCBbXSkuam9pbignLCAnKSB9KTsgY2xlYXJGaWxlSW5wdXRzKCk7IHNldEZvcm1Ub3VjaGVkKGZhbHNlKTsgbGFzdERyYWZ0UGF5bG9hZFJlZi5jdXJyZW50ID0gJyc7IHNldERyYWZ0U3RhdHVzKCcnKTsgc2V0Rm9ybUVycm9ycyh7fSk7IHNldE1lc3NhZ2UoJycpOyBzZXRHbG9iYWxFcnJvcignJyk7IHNldE1vZGUoJ2VkaXQnKSB9XG4gIGNvbnN0IHNob3dEZXRhaWwgPSBhc3luYyAobWVtbykgPT4ge1xuICAgIHNldEdsb2JhbEVycm9yKCcnKVxuICAgIHRyeSB7IHNldFNlbGVjdGVkTWVtbyhhd2FpdCByZXF1ZXN0SnNvbihgL3RvZG9zLyR7bWVtby5pZH1gKSk7IHNldE1vZGUoJ2RldGFpbCcpIH1cbiAgICBjYXRjaCAoZXJyb3IpIHsgc2V0R2xvYmFsRXJyb3IoZXJyb3IubWVzc2FnZSB8fCAn5oyH5a6a44GV44KM44Gf44Oh44Oi44Gv5a2Y5Zyo44GX44G+44Gb44KT44CCJyk7IGF3YWl0IGxvYWRNZW1vcygpIH1cbiAgfVxuICBjb25zdCBjYW5jZWxNZW1vRm9ybSA9IGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBvcmlnaW5hbCA9IHNlbGVjdGVkTWVtbyA/IHsgdGl0bGU6IHNlbGVjdGVkTWVtby50aXRsZSwgYm9keTogc2VsZWN0ZWRNZW1vLmJvZHksIHRhZ3NUZXh0OiAoc2VsZWN0ZWRNZW1vLnRhZ3MgfHwgW10pLmpvaW4oJywgJykgfSA6IGVtcHR5TWVtb1xuICAgIGNvbnN0IGNoYW5nZWQgPSBtZW1vRm9ybS50aXRsZSAhPT0gb3JpZ2luYWwudGl0bGUgfHwgbWVtb0Zvcm0uYm9keSAhPT0gb3JpZ2luYWwuYm9keSB8fCBtZW1vRm9ybS50YWdzVGV4dCAhPT0gb3JpZ2luYWwudGFnc1RleHRcbiAgICBpZiAoY2hhbmdlZCAmJiAhd2luZG93LmNvbmZpcm0oJ+WFpeWKm+WGheWuueOBr+S/neWtmOOBleOCjOOBpuOBhOOBvuOBm+OCk+OAguegtOajhOOBl+OBvuOBmeOBi++8nycpKSByZXR1cm5cbiAgICBjbGVhckF1dG9zYXZlVGltZXIoKVxuICAgIGlmIChjaGFuZ2VkIHx8IGhhc0RyYWZ0Q29udGVudChtZW1vRm9ybSkpIGF3YWl0IGRlbGV0ZUN1cnJlbnREcmFmdCgpXG4gICAgc2V0TW9kZSgnbGlzdCcpOyBzZXRNZW1vRm9ybShlbXB0eU1lbW8pOyBjbGVhckZpbGVJbnB1dHMoKTsgc2V0Rm9ybVRvdWNoZWQoZmFsc2UpOyBzZXREcmFmdFN0YXR1cygnJyk7IHNldEZvcm1FcnJvcnMoe30pXG4gIH1cbiAgY29uc3Qgc2F2ZU1lbW8gPSBhc3luYyAoZXZlbnQpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG4gICAgY29uc3QgZXJyb3JzID0gdmFsaWRhdGVNZW1vKG1lbW9Gb3JtKVxuICAgIGNvbnN0IGF0dGFjaG1lbnRFcnJvcnMgPSB2YWxpZGF0ZVNlbGVjdGVkRmlsZXMocGVuZGluZ0F0dGFjaG1lbnRzLCBzZWxlY3RlZE1lbW8/LmF0dGFjaG1lbnRzPy5sZW5ndGggfHwgMCwgJ2F0dGFjaG1lbnQnKVxuICAgIGNvbnN0IGltYWdlRXJyb3JzID0gdmFsaWRhdGVTZWxlY3RlZEZpbGVzKHBlbmRpbmdJbWFnZXMsIHNlbGVjdGVkTWVtbz8uaW1hZ2VzPy5sZW5ndGggfHwgMCwgJ2ltYWdlJylcbiAgICBjb25zdCBuZXh0RmlsZUVycm9ycyA9IHsgLi4uYXR0YWNobWVudEVycm9ycywgLi4uaW1hZ2VFcnJvcnMgfVxuICAgIHNldEZvcm1FcnJvcnMoZXJyb3JzKTsgc2V0RmlsZUVycm9ycyhuZXh0RmlsZUVycm9ycyk7IHNldEdsb2JhbEVycm9yKCcnKTsgc2V0TWVzc2FnZSgnJylcbiAgICBpZiAoT2JqZWN0LmtleXMoZXJyb3JzKS5sZW5ndGggPiAwIHx8IE9iamVjdC52YWx1ZXMobmV4dEZpbGVFcnJvcnMpLnNvbWUoQm9vbGVhbikpIHJldHVyblxuICAgIGNsZWFyQXV0b3NhdmVUaW1lcigpXG4gICAgc2V0SXNTYXZpbmcodHJ1ZSlcbiAgICB0cnkge1xuICAgICAgY29uc3QgaXNFZGl0ID0gbW9kZSA9PT0gJ2VkaXQnICYmIHNlbGVjdGVkTWVtb1xuICAgICAgY29uc3QgYXR0YWNobWVudHMgPSBhd2FpdCBQcm9taXNlLmFsbChwZW5kaW5nQXR0YWNobWVudHMubWFwKGZpbGVUb1VwbG9hZCkpXG4gICAgICBjb25zdCBpbWFnZXMgPSBhd2FpdCBQcm9taXNlLmFsbChwZW5kaW5nSW1hZ2VzLm1hcChmaWxlVG9VcGxvYWQpKVxuICAgICAgYXdhaXQgcmVxdWVzdEpzb24oJy90b2RvcycgKyAoaXNFZGl0ID8gJy8nICsgc2VsZWN0ZWRNZW1vLmlkIDogJycpLCB7IG1ldGhvZDogaXNFZGl0ID8gJ1BVVCcgOiAnUE9TVCcsIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9LCBib2R5OiBKU09OLnN0cmluZ2lmeSh7IHRpdGxlOiBtZW1vRm9ybS50aXRsZSwgYm9keTogbWVtb0Zvcm0uYm9keSwgdGFnczogbWVtb0Zvcm0udGFnc1RleHQsIHVwZGF0ZWRBdDogc2VsZWN0ZWRNZW1vPy51cGRhdGVkQXQsIGF0dGFjaG1lbnRzLCBpbWFnZXMgfSkgfSlcbiAgICAgIHNldE1lc3NhZ2UoaXNFZGl0ID8gJ+ODoeODouOCkuabtOaWsOOBl+OBvuOBl+OBn+OAgicgOiAn44Oh44Oi44KS55m76Yyy44GX44G+44GX44Gf44CCJylcbiAgICAgIGxhc3REcmFmdFBheWxvYWRSZWYuY3VycmVudCA9ICcnOyBjbGVhckZpbGVJbnB1dHMoKTsgc2V0Rm9ybVRvdWNoZWQoZmFsc2UpOyBzZXREcmFmdFN0YXR1cygnJylcbiAgICAgIHNldE1vZGUoJ2xpc3QnKTsgc2V0TWVtb0Zvcm0oZW1wdHlNZW1vKTsgc2V0U2VsZWN0ZWRNZW1vKG51bGwpOyBhd2FpdCBsb2FkTWVtb3MoKTsgYXdhaXQgbG9hZFRhZ3MoKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoZXJyb3IuZGF0YT8uZXJyb3JzKSBzZXRGb3JtRXJyb3JzKGVycm9yLmRhdGEuZXJyb3JzKVxuICAgICAgc2V0R2xvYmFsRXJyb3IoZXJyb3Iuc3RhdHVzID09PSA0MDkgPyBlcnJvci5tZXNzYWdlIDogJ+WHpueQhuS4reOBq+OCqOODqeODvOOBjOeZuueUn+OBl+OBvuOBl+OBn+OAguaZgumWk+OCkuOBiuOBhOOBpuWGjeW6puOBiuippuOBl+OBj+OBoOOBleOBhOOAgicpXG4gICAgfSBmaW5hbGx5IHsgc2V0SXNTYXZpbmcoZmFsc2UpIH1cbiAgfVxuICBjb25zdCBkZWxldGVNZW1vID0gYXN5bmMgKG1lbW8pID0+IHtcbiAgICBpZiAoIXdpbmRvdy5jb25maXJtKCfjgZPjga7jg6Hjg6LjgpLliYrpmaTjgZfjgb7jgZnjgYvvvJ8nKSkgcmV0dXJuXG4gICAgdHJ5IHsgYXdhaXQgcmVxdWVzdEpzb24oYC90b2Rvcy8ke21lbW8uaWR9YCwgeyBtZXRob2Q6ICdERUxFVEUnIH0pOyBzZXRNZXNzYWdlKCfjg6Hjg6LjgpLliYrpmaTjgZfjgb7jgZfjgZ/jgIInKTsgc2V0TW9kZSgnbGlzdCcpOyBzZXRTZWxlY3RlZE1lbW8obnVsbCk7IGF3YWl0IGxvYWRNZW1vcygpIH1cbiAgICBjYXRjaCAoZXJyb3IpIHsgc2V0R2xvYmFsRXJyb3IoZXJyb3IubWVzc2FnZSB8fCAn5Yem55CG5Lit44Gr44Ko44Op44O844GM55m655Sf44GX44G+44GX44Gf44CC5pmC6ZaT44KS44GK44GE44Gm5YaN5bqm44GK6Kmm44GX44GP44Gg44GV44GE44CCJykgfVxuICB9XG4gIGNvbnN0IHRvZ2dsZUZhdm9yaXRlID0gYXN5bmMgKG1lbW8pID0+IHtcbiAgICB0cnkgeyBhd2FpdCByZXF1ZXN0SnNvbihgL3RvZG9zLyR7bWVtby5pZH0vZmF2b3JpdGVgLCB7IG1ldGhvZDogbWVtby5pc0Zhdm9yaXRlID8gJ0RFTEVURScgOiAnUE9TVCcgfSk7IGF3YWl0IGxvYWRNZW1vcygpIH1cbiAgICBjYXRjaCAoZXJyb3IpIHsgc2V0R2xvYmFsRXJyb3IoJ+WHpueQhuS4reOBq+OCqOODqeODvOOBjOeZuueUn+OBl+OBvuOBl+OBn+OAguaZgumWk+OCkuOBiuOBhOOBpuWGjeW6puOBiuippuOBl+OBj+OBoOOBleOBhOOAgicpIH1cbiAgfVxuXG4gIGNvbnN0IHN0YXJ0VXNlckNyZWF0ZSA9ICgpID0+IHsgc2V0U2VsZWN0ZWRVc2VyKG51bGwpOyBzZXRVc2VyRm9ybShlbXB0eVVzZXIpOyBzZXRVc2VyRXJyb3JzKHt9KTsgc2V0TW9kZSgndXNlckZvcm0nKSB9XG4gIGNvbnN0IHN0YXJ0VXNlckVkaXQgPSAodXNlcikgPT4geyBzZXRTZWxlY3RlZFVzZXIodXNlcik7IHNldFVzZXJGb3JtKHsgdXNlcklkOiB1c2VyLnVzZXJJZCwgZGlzcGxheU5hbWU6IHVzZXIuZGlzcGxheU5hbWUsIGVtYWlsOiB1c2VyLmVtYWlsLCBwYXNzd29yZDogJycsIHJvbGU6IHVzZXIucm9sZSwgc3RhdHVzOiB1c2VyLnN0YXR1cyB9KTsgc2V0VXNlckVycm9ycyh7fSk7IHNldE1vZGUoJ3VzZXJGb3JtJykgfVxuICBjb25zdCBzYXZlVXNlciA9IGFzeW5jIChldmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7IHNldElzU2F2aW5nKHRydWUpOyBzZXRVc2VyRXJyb3JzKHt9KTsgc2V0R2xvYmFsRXJyb3IoJycpOyBzZXRNZXNzYWdlKCcnKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCBpc0VkaXQgPSBCb29sZWFuKHNlbGVjdGVkVXNlcilcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXF1ZXN0SnNvbihgL3VzZXJzJHtpc0VkaXQgPyBgLyR7c2VsZWN0ZWRVc2VyLmlkfWAgOiAnJ31gLCB7IG1ldGhvZDogaXNFZGl0ID8gJ1BVVCcgOiAnUE9TVCcsIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9LCBib2R5OiBKU09OLnN0cmluZ2lmeSh1c2VyRm9ybSkgfSlcbiAgICAgIHNldE1lc3NhZ2UoZGF0YS5tZXNzYWdlKTsgc2V0TW9kZSgndXNlcnMnKTsgYXdhaXQgbG9hZFVzZXJzKClcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGVycm9yLmRhdGE/LmVycm9ycykgc2V0VXNlckVycm9ycyhlcnJvci5kYXRhLmVycm9ycylcbiAgICAgIGVsc2Ugc2V0R2xvYmFsRXJyb3IoZXJyb3IubWVzc2FnZSB8fCAn5Yem55CG5Lit44Gr44Ko44Op44O844GM55m655Sf44GX44G+44GX44Gf44CC5pmC6ZaT44KS44GK44GE44Gm5YaN5bqm44GK6Kmm44GX44GP44Gg44GV44GE44CCJylcbiAgICB9IGZpbmFsbHkgeyBzZXRJc1NhdmluZyhmYWxzZSkgfVxuICB9XG4gIGNvbnN0IGRpc2FibGVVc2VyID0gYXN5bmMgKHVzZXIpID0+IHtcbiAgICBpZiAoIXdpbmRvdy5jb25maXJtKGAke3VzZXIudXNlcklkfSDjgpLnhKHlirnljJbjgZfjgb7jgZnjgYvvvJ9gKSkgcmV0dXJuXG4gICAgdHJ5IHsgY29uc3QgZGF0YSA9IGF3YWl0IHJlcXVlc3RKc29uKGAvdXNlcnMvJHt1c2VyLmlkfS9kaXNhYmxlYCwgeyBtZXRob2Q6ICdQQVRDSCcgfSk7IHNldE1lc3NhZ2UoZGF0YS5tZXNzYWdlKTsgYXdhaXQgbG9hZFVzZXJzKCkgfVxuICAgIGNhdGNoIChlcnJvcikgeyBzZXRHbG9iYWxFcnJvcihlcnJvci5tZXNzYWdlIHx8ICflh6bnkIbkuK3jgavjgqjjg6njg7zjgYznmbrnlJ/jgZfjgb7jgZfjgZ/jgILmmYLplpPjgpLjgYrjgYTjgablho3luqbjgYroqabjgZfjgY/jgaDjgZXjgYTjgIInKSB9XG4gIH1cblxuICBpZiAoIXRva2VuIHx8ICFjdXJyZW50VXNlcikge1xuICAgIHJldHVybiA8bWFpbiBjbGFzc05hbWU9XCJhcHAtc2hlbGwgbmFycm93XCI+PHNlY3Rpb24gY2xhc3NOYW1lPVwid29ya3NwYWNlIGZvcm0tcGFuZWxcIj48cCBjbGFzc05hbWU9XCJleWVicm93XCI+UUEgRXhlcmNpc2U8L3A+PGgxPk1lbW9QYWQg44Ot44Kw44Kk44OzPC9oMT57Z2xvYmFsRXJyb3IgJiYgPGRpdiBjbGFzc05hbWU9XCJub3RpY2UgZXJyb3JcIj57Z2xvYmFsRXJyb3J9PC9kaXY+fTxmb3JtIG9uU3VibWl0PXtsb2dpbn0gbm9WYWxpZGF0ZT48bGFiZWwgY2xhc3NOYW1lPVwiZmllbGRcIj48c3Bhbj7jg6bjg7zjgrbjg7xJRDwvc3Bhbj48aW5wdXQgdmFsdWU9e2xvZ2luRm9ybS51c2VySWR9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0TG9naW5Gb3JtKHsgLi4ubG9naW5Gb3JtLCB1c2VySWQ6IGUudGFyZ2V0LnZhbHVlIH0pfSAvPntsb2dpbkVycm9ycy51c2VySWQgJiYgPHN0cm9uZyBjbGFzc05hbWU9XCJmaWVsZC1lcnJvclwiPntsb2dpbkVycm9ycy51c2VySWR9PC9zdHJvbmc+fTwvbGFiZWw+PGxhYmVsIGNsYXNzTmFtZT1cImZpZWxkXCI+PHNwYW4+44OR44K544Ov44O844OJPC9zcGFuPjxpbnB1dCB0eXBlPVwicGFzc3dvcmRcIiB2YWx1ZT17bG9naW5Gb3JtLnBhc3N3b3JkfSBvbkNoYW5nZT17KGUpID0+IHNldExvZ2luRm9ybSh7IC4uLmxvZ2luRm9ybSwgcGFzc3dvcmQ6IGUudGFyZ2V0LnZhbHVlIH0pfSAvPntsb2dpbkVycm9ycy5wYXNzd29yZCAmJiA8c3Ryb25nIGNsYXNzTmFtZT1cImZpZWxkLWVycm9yXCI+e2xvZ2luRXJyb3JzLnBhc3N3b3JkfTwvc3Ryb25nPn08L2xhYmVsPjxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzTmFtZT1cInByaW1hcnktYnV0dG9uXCIgZGlzYWJsZWQ9e2lzU2F2aW5nfT57aXNTYXZpbmcgPyAn44Ot44Kw44Kk44Oz5LitJyA6ICfjg63jgrDjgqTjg7MnfTwvYnV0dG9uPjwvZm9ybT48cCBjbGFzc05hbWU9XCJoaW50XCI+5Yid5pyf44Om44O844K244O8OiBhZG1pbiAvIHBhc3N3b3JkMTIzPC9wPjwvc2VjdGlvbj48L21haW4+XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxtYWluIGNsYXNzTmFtZT1cImFwcC1zaGVsbFwiPlxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJhcHAtaGVhZGVyXCI+PGRpdj48cCBjbGFzc05hbWU9XCJleWVicm93XCI+e2N1cnJlbnRVc2VyLmRpc3BsYXlOYW1lfSAvIHtjdXJyZW50VXNlci5yb2xlID09PSAnYWRtaW4nID8gJ+euoeeQhuiAhScgOiAn5LiA6Iis44Om44O844K244O8J308L3A+PGgxPk1lbW9QYWQ8L2gxPjwvZGl2PjxkaXYgY2xhc3NOYW1lPVwiaGVhZGVyLWFjdGlvbnNcIj48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJwcmltYXJ5LWJ1dHRvblwiIG9uQ2xpY2s9e3N0YXJ0Q3JlYXRlfT7mlrDopo/kvZzmiJA8L2J1dHRvbj57Y3VycmVudFVzZXIucm9sZSA9PT0gJ2FkbWluJyAmJiA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJnaG9zdC1idXR0b25cIiBvbkNsaWNrPXtvcGVuVXNlckxpc3R9PuODpuODvOOCtuODvOeuoeeQhjwvYnV0dG9uPn08YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJnaG9zdC1idXR0b25cIiBvbkNsaWNrPXtsb2dvdXR9PuODreOCsOOCouOCpuODiDwvYnV0dG9uPjwvZGl2PjwvaGVhZGVyPlxuICAgICAge21lc3NhZ2UgJiYgPGRpdiBjbGFzc05hbWU9XCJub3RpY2Ugc3VjY2Vzc1wiPnttZXNzYWdlfTwvZGl2Pn17Z2xvYmFsRXJyb3IgJiYgPGRpdiBjbGFzc05hbWU9XCJub3RpY2UgZXJyb3JcIj57Z2xvYmFsRXJyb3J9PC9kaXY+fVxuXG4gICAgICB7bW9kZSA9PT0gJ3VzZXJzJyAmJiBjdXJyZW50VXNlci5yb2xlID09PSAnYWRtaW4nICYmIDxzZWN0aW9uIGNsYXNzTmFtZT1cIndvcmtzcGFjZVwiPjxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi1oZWFkaW5nXCI+PGgyPuODpuODvOOCtuODvOeuoeeQhjwvaDI+PGRpdiBjbGFzc05hbWU9XCJmb3JtLWFjdGlvbnNcIj48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJwcmltYXJ5LWJ1dHRvblwiIG9uQ2xpY2s9e3N0YXJ0VXNlckNyZWF0ZX0+44Om44O844K244O85L2c5oiQPC9idXR0b24+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiZ2hvc3QtYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0TW9kZSgnbGlzdCcpfT7jg6Hjg6LkuIDopqfjgbjmiLvjgos8L2J1dHRvbj48L2Rpdj48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cInVzZXItdGFibGVcIj48ZGl2IGNsYXNzTmFtZT1cInVzZXItcm93IHVzZXItaGVhZFwiPjxzcGFuPuODpuODvOOCtuODvElEPC9zcGFuPjxzcGFuPuihqOekuuWQjTwvc3Bhbj48c3Bhbj7jg6Hjg7zjg6s8L3NwYW4+PHNwYW4+5qip6ZmQPC9zcGFuPjxzcGFuPueKtuaFizwvc3Bhbj48c3Bhbj7mk43kvZw8L3NwYW4+PC9kaXY+e3VzZXJzLm1hcCgodXNlcikgPT4gPGRpdiBjbGFzc05hbWU9XCJ1c2VyLXJvd1wiIGtleT17dXNlci5pZH0+PHNwYW4+e3VzZXIudXNlcklkfTwvc3Bhbj48c3Bhbj57dXNlci5kaXNwbGF5TmFtZX08L3NwYW4+PHNwYW4+e3VzZXIuZW1haWx9PC9zcGFuPjxzcGFuPnt1c2VyLnJvbGUgPT09ICdhZG1pbicgPyAn566h55CG6ICFJyA6ICfkuIDoiKzjg6bjg7zjgrbjg7wnfTwvc3Bhbj48c3Bhbj57dXNlci5zdGF0dXMgPT09ICdhY3RpdmUnID8gJ+acieWKuScgOiAn54Sh5Yq5J308L3NwYW4+PHNwYW4gY2xhc3NOYW1lPVwicm93LWFjdGlvbnNcIj48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzdGFydFVzZXJFZGl0KHVzZXIpfT7nt6jpm4Y8L2J1dHRvbj48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJkYW5nZXItYnV0dG9uXCIgZGlzYWJsZWQ9e3VzZXIuc3RhdHVzID09PSAnZGlzYWJsZWQnfSBvbkNsaWNrPXsoKSA9PiBkaXNhYmxlVXNlcih1c2VyKX0+54Sh5Yq55YyWPC9idXR0b24+PC9zcGFuPjwvZGl2Pil9PC9kaXY+PC9zZWN0aW9uPn1cblxuICAgICAge21vZGUgPT09ICd1c2VyRm9ybScgJiYgY3VycmVudFVzZXIucm9sZSA9PT0gJ2FkbWluJyAmJiA8c2VjdGlvbiBjbGFzc05hbWU9XCJ3b3Jrc3BhY2UgZm9ybS1wYW5lbFwiPjxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi1oZWFkaW5nXCI+PGgyPntzZWxlY3RlZFVzZXIgPyAn44Om44O844K244O857eo6ZuGJyA6ICfjg6bjg7zjgrbjg7zkvZzmiJAnfTwvaDI+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiZ2hvc3QtYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0TW9kZSgndXNlcnMnKX0+44Kt44Oj44Oz44K744OrPC9idXR0b24+PC9kaXY+PGZvcm0gb25TdWJtaXQ9e3NhdmVVc2VyfSBub1ZhbGlkYXRlPjxsYWJlbCBjbGFzc05hbWU9XCJmaWVsZFwiPjxzcGFuPuODpuODvOOCtuODvElEPC9zcGFuPjxpbnB1dCB2YWx1ZT17dXNlckZvcm0udXNlcklkfSBkaXNhYmxlZD17Qm9vbGVhbihzZWxlY3RlZFVzZXIpfSBvbkNoYW5nZT17KGUpID0+IHNldFVzZXJGb3JtKHsgLi4udXNlckZvcm0sIHVzZXJJZDogZS50YXJnZXQudmFsdWUgfSl9IC8+e3VzZXJFcnJvcnMudXNlcklkICYmIDxzdHJvbmcgY2xhc3NOYW1lPVwiZmllbGQtZXJyb3JcIj57dXNlckVycm9ycy51c2VySWR9PC9zdHJvbmc+fTwvbGFiZWw+PGxhYmVsIGNsYXNzTmFtZT1cImZpZWxkXCI+PHNwYW4+6KGo56S65ZCNPC9zcGFuPjxpbnB1dCB2YWx1ZT17dXNlckZvcm0uZGlzcGxheU5hbWV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0VXNlckZvcm0oeyAuLi51c2VyRm9ybSwgZGlzcGxheU5hbWU6IGUudGFyZ2V0LnZhbHVlIH0pfSAvPnt1c2VyRXJyb3JzLmRpc3BsYXlOYW1lICYmIDxzdHJvbmcgY2xhc3NOYW1lPVwiZmllbGQtZXJyb3JcIj57dXNlckVycm9ycy5kaXNwbGF5TmFtZX08L3N0cm9uZz59PC9sYWJlbD48bGFiZWwgY2xhc3NOYW1lPVwiZmllbGRcIj48c3Bhbj7jg6Hjg7zjg6vjgqLjg4njg6zjgrk8L3NwYW4+PGlucHV0IHZhbHVlPXt1c2VyRm9ybS5lbWFpbH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRVc2VyRm9ybSh7IC4uLnVzZXJGb3JtLCBlbWFpbDogZS50YXJnZXQudmFsdWUgfSl9IC8+e3VzZXJFcnJvcnMuZW1haWwgJiYgPHN0cm9uZyBjbGFzc05hbWU9XCJmaWVsZC1lcnJvclwiPnt1c2VyRXJyb3JzLmVtYWlsfTwvc3Ryb25nPn08L2xhYmVsPjxsYWJlbCBjbGFzc05hbWU9XCJmaWVsZFwiPjxzcGFuPuODkeOCueODr+ODvOODiXtzZWxlY3RlZFVzZXIgPyAn77yI5aSJ5pu05pmC44Gu44G/5YWl5Yqb77yJJyA6ICcnfTwvc3Bhbj48aW5wdXQgdHlwZT1cInBhc3N3b3JkXCIgdmFsdWU9e3VzZXJGb3JtLnBhc3N3b3JkfSBvbkNoYW5nZT17KGUpID0+IHNldFVzZXJGb3JtKHsgLi4udXNlckZvcm0sIHBhc3N3b3JkOiBlLnRhcmdldC52YWx1ZSB9KX0gLz57dXNlckVycm9ycy5wYXNzd29yZCAmJiA8c3Ryb25nIGNsYXNzTmFtZT1cImZpZWxkLWVycm9yXCI+e3VzZXJFcnJvcnMucGFzc3dvcmR9PC9zdHJvbmc+fTwvbGFiZWw+PGxhYmVsIGNsYXNzTmFtZT1cImZpZWxkXCI+PHNwYW4+5qip6ZmQPC9zcGFuPjxzZWxlY3QgdmFsdWU9e3VzZXJGb3JtLnJvbGV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0VXNlckZvcm0oeyAuLi51c2VyRm9ybSwgcm9sZTogZS50YXJnZXQudmFsdWUgfSl9PjxvcHRpb24gdmFsdWU9XCJ1c2VyXCI+5LiA6Iis44Om44O844K244O8PC9vcHRpb24+PG9wdGlvbiB2YWx1ZT1cImFkbWluXCI+566h55CG6ICFPC9vcHRpb24+PC9zZWxlY3Q+e3VzZXJFcnJvcnMucm9sZSAmJiA8c3Ryb25nIGNsYXNzTmFtZT1cImZpZWxkLWVycm9yXCI+e3VzZXJFcnJvcnMucm9sZX08L3N0cm9uZz59PC9sYWJlbD57c2VsZWN0ZWRVc2VyICYmIDxsYWJlbCBjbGFzc05hbWU9XCJmaWVsZFwiPjxzcGFuPueKtuaFizwvc3Bhbj48c2VsZWN0IHZhbHVlPXt1c2VyRm9ybS5zdGF0dXN9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0VXNlckZvcm0oeyAuLi51c2VyRm9ybSwgc3RhdHVzOiBlLnRhcmdldC52YWx1ZSB9KX0+PG9wdGlvbiB2YWx1ZT1cImFjdGl2ZVwiPuacieWKuTwvb3B0aW9uPjxvcHRpb24gdmFsdWU9XCJkaXNhYmxlZFwiPueEoeWKuTwvb3B0aW9uPjwvc2VsZWN0PjwvbGFiZWw+fTxkaXYgY2xhc3NOYW1lPVwiZm9ybS1hY3Rpb25zXCI+PGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgY2xhc3NOYW1lPVwicHJpbWFyeS1idXR0b25cIiBkaXNhYmxlZD17aXNTYXZpbmd9Pntpc1NhdmluZyA/ICfkv53lrZjkuK0nIDogc2VsZWN0ZWRVc2VyID8gJ+abtOaWsCcgOiAn55m76YyyJ308L2J1dHRvbj48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJnaG9zdC1idXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXRNb2RlKCd1c2VycycpfT7jgq3jg6Pjg7Pjgrvjg6s8L2J1dHRvbj48L2Rpdj48L2Zvcm0+PC9zZWN0aW9uPn1cblxuICAgICAge21vZGUgPT09ICdsaXN0JyAmJiA8c2VjdGlvbiBjbGFzc05hbWU9XCJ3b3Jrc3BhY2VcIj48ZGl2IGNsYXNzTmFtZT1cInRvb2xiYXIgc3RhY2thYmxlXCI+PGxhYmVsIGNsYXNzTmFtZT1cInNlYXJjaC1maWVsZFwiPjxzcGFuPuaknOe0ojwvc3Bhbj48aW5wdXQgdmFsdWU9e2ZpbHRlcnMua2V5d29yZH0gb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVGaWx0ZXJzKHsga2V5d29yZDogZS50YXJnZXQudmFsdWUgfSl9IHBsYWNlaG9sZGVyPVwi44K/44Kk44OI44Or44O75pys5paH44KS5qSc57SiXCIgLz48L2xhYmVsPjxsYWJlbCBjbGFzc05hbWU9XCJzZWxlY3QtZmllbGRcIj48c3Bhbj7ooajnpLrku7bmlbA8L3NwYW4+PHNlbGVjdCB2YWx1ZT17ZmlsdGVycy5saW1pdH0gb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVGaWx0ZXJzKHsgbGltaXQ6IE51bWJlcihlLnRhcmdldC52YWx1ZSkgfSl9PjxvcHRpb24gdmFsdWU9XCIxMFwiPjEw5Lu2PC9vcHRpb24+PG9wdGlvbiB2YWx1ZT1cIjI1XCI+MjXku7Y8L29wdGlvbj48b3B0aW9uIHZhbHVlPVwiNTBcIj41MOS7tjwvb3B0aW9uPjwvc2VsZWN0PjwvbGFiZWw+PGxhYmVsIGNsYXNzTmFtZT1cInNlbGVjdC1maWVsZFwiPjxzcGFuPuS4puOBs+abv+OBiDwvc3Bhbj48c2VsZWN0IHZhbHVlPXtmaWx0ZXJzLnNvcnRCeX0gb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVGaWx0ZXJzKHsgc29ydEJ5OiBlLnRhcmdldC52YWx1ZSB9KX0+PG9wdGlvbiB2YWx1ZT1cInVwZGF0ZWRBdFwiPuabtOaWsOaXpeaZgjwvb3B0aW9uPjxvcHRpb24gdmFsdWU9XCJjcmVhdGVkQXRcIj7kvZzmiJDml6XmmYI8L29wdGlvbj48b3B0aW9uIHZhbHVlPVwidGl0bGVcIj7jgr/jgqTjg4jjg6s8L29wdGlvbj48L3NlbGVjdD48L2xhYmVsPjxkaXYgY2xhc3NOYW1lPVwic2VnbWVudGVkXCIgYXJpYS1sYWJlbD1cIuaYh+mghumZjemghlwiPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT17ZmlsdGVycy5vcmRlciA9PT0gJ2Rlc2MnID8gJ2FjdGl2ZScgOiAnJ30gb25DbGljaz17KCkgPT4gdXBkYXRlRmlsdGVycyh7IG9yZGVyOiAnZGVzYycgfSl9PumZjemghjwvYnV0dG9uPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT17ZmlsdGVycy5vcmRlciA9PT0gJ2FzYycgPyAnYWN0aXZlJyA6ICcnfSBvbkNsaWNrPXsoKSA9PiB1cGRhdGVGaWx0ZXJzKHsgb3JkZXI6ICdhc2MnIH0pfT7mmIfpoIY8L2J1dHRvbj48L2Rpdj48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cInRvb2xiYXIgY29tcGFjdC10b29sYmFyXCI+PGxhYmVsIGNsYXNzTmFtZT1cImNoZWNrLWZpZWxkXCI+PGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNoZWNrZWQ9e2ZpbHRlcnMuZmF2b3JpdGV9IG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlRmlsdGVycyh7IGZhdm9yaXRlOiBlLnRhcmdldC5jaGVja2VkIH0pfSAvPiDjgYrmsJfjgavlhaXjgorjga7jgb88L2xhYmVsPjxsYWJlbCBjbGFzc05hbWU9XCJzZWxlY3QtZmllbGRcIj48c3Bhbj7jgr/jgrA8L3NwYW4+PHNlbGVjdCB2YWx1ZT17ZmlsdGVycy50YWd9IG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlRmlsdGVycyh7IHRhZzogZS50YXJnZXQudmFsdWUgfSl9PjxvcHRpb24gdmFsdWU9XCJcIj7jgZnjgbnjgaY8L29wdGlvbj57dGFncy5tYXAoKHRhZykgPT4gPG9wdGlvbiBrZXk9e3RhZy5ub3JtYWxpemVkTmFtZX0gdmFsdWU9e3RhZy5ub3JtYWxpemVkTmFtZX0+e3RhZy5uYW1lfTwvb3B0aW9uPil9PC9zZWxlY3Q+PC9sYWJlbD48ZGl2IGNsYXNzTmFtZT1cInNlZ21lbnRlZFwiIGFyaWEtbGFiZWw9XCLooajnpLrliIfjgormm7/jgYhcIj48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9e2Rpc3BsYXlNb2RlID09PSAnbGlzdCcgPyAnYWN0aXZlJyA6ICcnfSBvbkNsaWNrPXsoKSA9PiBzZXREaXNwbGF5TW9kZSgnbGlzdCcpfT7kuIDopqc8L2J1dHRvbj48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9e2Rpc3BsYXlNb2RlID09PSAnY29tcGFjdCcgPyAnYWN0aXZlJyA6ICcnfSBvbkNsaWNrPXsoKSA9PiBzZXREaXNwbGF5TW9kZSgnY29tcGFjdCcpfT7jgrPjg7Pjg5Hjgq/jg4g8L2J1dHRvbj48L2Rpdj48L2Rpdj57aXNMb2FkaW5nICYmIDxwIGNsYXNzTmFtZT1cImVtcHR5LXN0YXRlXCI+6Kqt44G/6L6844G/5Lit44Gn44GZ44CCPC9wPn17IWlzTG9hZGluZyAmJiB0b3RhbCA9PT0gMCAmJiAhZmlsdGVycy5rZXl3b3JkICYmICFmaWx0ZXJzLmZhdm9yaXRlICYmIDxwIGNsYXNzTmFtZT1cImVtcHR5LXN0YXRlXCI+44Oh44Oi44GM55m76Yyy44GV44KM44Gm44GE44G+44Gb44KT44CCPC9wPn17IWlzTG9hZGluZyAmJiB0b3RhbCA9PT0gMCAmJiAoZmlsdGVycy5rZXl3b3JkIHx8IGZpbHRlcnMuZmF2b3JpdGUpICYmIDxwIGNsYXNzTmFtZT1cImVtcHR5LXN0YXRlXCI+5p2h5Lu244Gr5LiA6Ie044GZ44KL44Oh44Oi44GM44GC44KK44G+44Gb44KT44CCPC9wPn08ZGl2IGNsYXNzTmFtZT17ZGlzcGxheU1vZGUgPT09ICdjb21wYWN0JyA/ICdtZW1vLWxpc3QgY29tcGFjdCcgOiAnbWVtby1saXN0J30+e21lbW9zLm1hcCgobWVtbykgPT4gPGFydGljbGUgY2xhc3NOYW1lPVwibWVtby1pdGVtXCIga2V5PXttZW1vLmlkfT48ZGl2IGNsYXNzTmFtZT1cIm1lbW8tbWFpblwiPjxoMj57bWVtby50aXRsZX08L2gyPntkaXNwbGF5TW9kZSA9PT0gJ2xpc3QnICYmIDxwIGNsYXNzTmFtZT1cIm1lbW8tcHJldmlld1wiPnttZW1vLmJvZHkuc2xpY2UoMCwgNTApfTwvcD59e21lbW8udGFncz8ubGVuZ3RoID4gMCAmJiA8ZGl2IGNsYXNzTmFtZT1cInRhZy1saXN0XCI+e21lbW8udGFncy5tYXAoKHRhZykgPT4gPHNwYW4gY2xhc3NOYW1lPVwidGFnLWNoaXBcIiBrZXk9e3RhZ30+e3RhZ308L3NwYW4+KX08L2Rpdj59PHAgY2xhc3NOYW1lPVwibWVtby1kYXRlXCI+5pu05paw5pel5pmCIHtmb3JtYXREYXRlKG1lbW8udXBkYXRlZEF0KX08L3A+PC9kaXY+PGRpdiBjbGFzc05hbWU9XCJtZW1vLWFjdGlvbnNcIj48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiB0b2dnbGVGYXZvcml0ZShtZW1vKX0+e21lbW8uaXNGYXZvcml0ZSA/ICfjgYrmsJfjgavlhaXjgorop6PpmaQnIDogJ+OBiuawl+OBq+WFpeOCiid9PC9idXR0b24+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2hvd0RldGFpbChtZW1vKX0+6Kmz57SwPC9idXR0b24+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc3RhcnRFZGl0KG1lbW8pfT7nt6jpm4Y8L2J1dHRvbj48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJkYW5nZXItYnV0dG9uXCIgb25DbGljaz17KCkgPT4gZGVsZXRlTWVtbyhtZW1vKX0+5YmK6ZmkPC9idXR0b24+PC9kaXY+PC9hcnRpY2xlPil9PC9kaXY+PGRpdiBjbGFzc05hbWU9XCJwYWdpbmF0aW9uXCI+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgZGlzYWJsZWQ9e2ZpbHRlcnMucGFnZSA8PSAxfSBvbkNsaWNrPXsoKSA9PiB1cGRhdGVGaWx0ZXJzKHsgcGFnZTogZmlsdGVycy5wYWdlIC0gMSB9KX0+5YmN44G4PC9idXR0b24+PHNwYW4+e2ZpbHRlcnMucGFnZX0gLyB7cGFnZUNvdW50fTwvc3Bhbj48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBkaXNhYmxlZD17ZmlsdGVycy5wYWdlID49IHBhZ2VDb3VudH0gb25DbGljaz17KCkgPT4gdXBkYXRlRmlsdGVycyh7IHBhZ2U6IGZpbHRlcnMucGFnZSArIDEgfSl9PuasoeOBuDwvYnV0dG9uPjwvZGl2Pjwvc2VjdGlvbj59XG5cbiAgICAgIHsobW9kZSA9PT0gJ2NyZWF0ZScgfHwgbW9kZSA9PT0gJ2VkaXQnKSAmJiA8c2VjdGlvbiBjbGFzc05hbWU9XCJ3b3Jrc3BhY2UgZm9ybS1wYW5lbFwiPjxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi1oZWFkaW5nXCI+PGgyPnttb2RlID09PSAnY3JlYXRlJyA/ICfjg6Hjg6LmlrDopo/kvZzmiJAnIDogJ+ODoeODoue3qOmbhid9PC9oMj48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJnaG9zdC1idXR0b25cIiBvbkNsaWNrPXtjYW5jZWxNZW1vRm9ybX0+44Kt44Oj44Oz44K744OrPC9idXR0b24+PC9kaXY+PGZvcm0gb25TdWJtaXQ9e3NhdmVNZW1vfSBub1ZhbGlkYXRlPjxsYWJlbCBjbGFzc05hbWU9XCJmaWVsZFwiPjxzcGFuPuOCv+OCpOODiOODqzwvc3Bhbj48aW5wdXQgdmFsdWU9e21lbW9Gb3JtLnRpdGxlfSBtYXhMZW5ndGg9ezEyMH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRNZW1vRmllbGQoJ3RpdGxlJywgZS50YXJnZXQudmFsdWUpfSAvPjxzbWFsbD57bWVtb0Zvcm0udGl0bGUubGVuZ3RofS8xMDA8L3NtYWxsPntmb3JtRXJyb3JzLnRpdGxlICYmIDxzdHJvbmcgY2xhc3NOYW1lPVwiZmllbGQtZXJyb3JcIj57Zm9ybUVycm9ycy50aXRsZX08L3N0cm9uZz59PC9sYWJlbD48bGFiZWwgY2xhc3NOYW1lPVwiZmllbGRcIj48c3Bhbj7mnKzmloc8L3NwYW4+PHRleHRhcmVhIHZhbHVlPXttZW1vRm9ybS5ib2R5fSByb3dzPVwiMTJcIiBtYXhMZW5ndGg9ezIxMDB9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0TWVtb0ZpZWxkKCdib2R5JywgZS50YXJnZXQudmFsdWUpfSAvPjxzbWFsbD57bWVtb0Zvcm0uYm9keS5sZW5ndGh9LzIwMDA8L3NtYWxsPntmb3JtRXJyb3JzLmJvZHkgJiYgPHN0cm9uZyBjbGFzc05hbWU9XCJmaWVsZC1lcnJvclwiPntmb3JtRXJyb3JzLmJvZHl9PC9zdHJvbmc+fTwvbGFiZWw+PGxhYmVsIGNsYXNzTmFtZT1cImZpZWxkXCI+PHNwYW4+44K/44KwPC9zcGFuPjxpbnB1dCB2YWx1ZT17bWVtb0Zvcm0udGFnc1RleHR9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0TWVtb0ZpZWxkKCd0YWdzVGV4dCcsIGUudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCLkvos6IOS7leS6iywg6YeN6KaBXCIgLz48c21hbGw+44Kr44Oz44Oe5Yy65YiH44KK44CB5pyA5aSnMTDlgIvjgIHlkIQzMOaWh+Wtl+S7peWGhTwvc21hbGw+e2Zvcm1FcnJvcnMudGFncyAmJiA8c3Ryb25nIGNsYXNzTmFtZT1cImZpZWxkLWVycm9yXCI+e2Zvcm1FcnJvcnMudGFnc308L3N0cm9uZz59PC9sYWJlbD48ZGl2IGNsYXNzTmFtZT1cImZpbGUtZ3JpZFwiPjxsYWJlbCBjbGFzc05hbWU9XCJmaWVsZFwiPjxzcGFuPua3u+S7mOODleOCoeOCpOODqzwvc3Bhbj48aW5wdXQgdHlwZT1cImZpbGVcIiBtdWx0aXBsZSBhY2NlcHQ9XCIucGRmLC50eHQsLmNzdiwuZG9jeCwueGxzeFwiIG9uQ2hhbmdlPXsoZSkgPT4gYWRkUGVuZGluZ0ZpbGVzKGUsICdhdHRhY2htZW50Jyl9IC8+PHNtYWxsPuacgOWkpzXku7bjgIEx44OV44Kh44Kk44OrMTBNQuS7peWGhTwvc21hbGw+e2ZpbGVFcnJvcnMuYXR0YWNobWVudHMgJiYgPHN0cm9uZyBjbGFzc05hbWU9XCJmaWVsZC1lcnJvclwiPntmaWxlRXJyb3JzLmF0dGFjaG1lbnRzfTwvc3Ryb25nPn08L2xhYmVsPjxsYWJlbCBjbGFzc05hbWU9XCJmaWVsZFwiPjxzcGFuPueUu+WDjzwvc3Bhbj48aW5wdXQgdHlwZT1cImZpbGVcIiBtdWx0aXBsZSBhY2NlcHQ9XCIuanBnLC5qcGVnLC5wbmcsLmdpZiwud2VicFwiIG9uQ2hhbmdlPXsoZSkgPT4gYWRkUGVuZGluZ0ZpbGVzKGUsICdpbWFnZScpfSAvPjxzbWFsbD7mnIDlpKcxMOaemuOAgTHjg5XjgqHjgqTjg6s1TULku6XlhoU8L3NtYWxsPntmaWxlRXJyb3JzLmltYWdlcyAmJiA8c3Ryb25nIGNsYXNzTmFtZT1cImZpZWxkLWVycm9yXCI+e2ZpbGVFcnJvcnMuaW1hZ2VzfTwvc3Ryb25nPn08L2xhYmVsPjwvZGl2PntzZWxlY3RlZE1lbW8/LmF0dGFjaG1lbnRzPy5sZW5ndGggPiAwICYmIDxkaXYgY2xhc3NOYW1lPVwiZmlsZS1saXN0XCI+PGgzPueZu+mMsua4iOOBv+a3u+S7mOODleOCoeOCpOODqzwvaDM+e3NlbGVjdGVkTWVtby5hdHRhY2htZW50cy5tYXAoKGZpbGUpID0+IDxkaXYgY2xhc3NOYW1lPVwiZmlsZS1yb3dcIiBrZXk9e2ZpbGUuaWR9PjxzcGFuPntmaWxlLm9yaWdpbmFsTmFtZX0gKHtmb3JtYXRTaXplKGZpbGUuc2l6ZSl9KTwvc3Bhbj48ZGl2IGNsYXNzTmFtZT1cInJvdy1hY3Rpb25zXCI+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gZG93bmxvYWRGaWxlKGZpbGUpfT7jg4Djgqbjg7Pjg63jg7zjg4k8L2J1dHRvbj48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJkYW5nZXItYnV0dG9uXCIgb25DbGljaz17KCkgPT4gZGVsZXRlRXhpc3RpbmdGaWxlKGZpbGUpfT7liYrpmaQ8L2J1dHRvbj48L2Rpdj48L2Rpdj4pfTwvZGl2Pn17c2VsZWN0ZWRNZW1vPy5pbWFnZXM/Lmxlbmd0aCA+IDAgJiYgPGRpdiBjbGFzc05hbWU9XCJpbWFnZS1ncmlkXCI+PGgzPueZu+mMsua4iOOBv+eUu+WDjzwvaDM+e3NlbGVjdGVkTWVtby5pbWFnZXMubWFwKChmaWxlKSA9PiA8ZGl2IGNsYXNzTmFtZT1cImltYWdlLWNhcmRcIiBrZXk9e2ZpbGUuaWR9PntpbWFnZVVybHNbZmlsZS5pZF0gPyA8aW1nIHNyYz17aW1hZ2VVcmxzW2ZpbGUuaWRdfSBhbHQ9e2ZpbGUub3JpZ2luYWxOYW1lfSAvPiA6IDxkaXYgY2xhc3NOYW1lPVwiaW1hZ2UtcGxhY2Vob2xkZXJcIj7jg5fjg6zjg5Pjg6Xjg7zjgafjgY3jgb7jgZvjgpM8L2Rpdj59PHNwYW4+e2ZpbGUub3JpZ2luYWxOYW1lfTwvc3Bhbj48ZGl2IGNsYXNzTmFtZT1cInJvdy1hY3Rpb25zXCI+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gZG93bmxvYWRGaWxlKGZpbGUpfT7jg4Djgqbjg7Pjg63jg7zjg4k8L2J1dHRvbj48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJkYW5nZXItYnV0dG9uXCIgb25DbGljaz17KCkgPT4gZGVsZXRlRXhpc3RpbmdGaWxlKGZpbGUpfT7liYrpmaQ8L2J1dHRvbj48L2Rpdj48L2Rpdj4pfTwvZGl2Pn17cGVuZGluZ0F0dGFjaG1lbnRzLmxlbmd0aCA+IDAgJiYgPGRpdiBjbGFzc05hbWU9XCJmaWxlLWxpc3RcIj48aDM+6L+95Yqg5LqI5a6a44Gu5re75LuY44OV44Kh44Kk44OrPC9oMz57cGVuZGluZ0F0dGFjaG1lbnRzLm1hcCgoZmlsZSwgaW5kZXgpID0+IDxkaXYgY2xhc3NOYW1lPVwiZmlsZS1yb3dcIiBrZXk9e2ZpbGUubmFtZSArICctJyArIGluZGV4fT48c3Bhbj57ZmlsZS5uYW1lfSAoe2Zvcm1hdFNpemUoZmlsZS5zaXplKX0pPC9zcGFuPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImRhbmdlci1idXR0b25cIiBvbkNsaWNrPXsoKSA9PiByZW1vdmVQZW5kaW5nRmlsZShpbmRleCwgJ2F0dGFjaG1lbnQnKX0+5YmK6ZmkPC9idXR0b24+PC9kaXY+KX08L2Rpdj59e3BlbmRpbmdJbWFnZXMubGVuZ3RoID4gMCAmJiA8ZGl2IGNsYXNzTmFtZT1cImltYWdlLWdyaWRcIj48aDM+6L+95Yqg5LqI5a6a44Gu55S75YOPPC9oMz57cGVuZGluZ0ltYWdlcy5tYXAoKGZpbGUsIGluZGV4KSA9PiA8ZGl2IGNsYXNzTmFtZT1cImltYWdlLWNhcmRcIiBrZXk9e2ZpbGUubmFtZSArICctJyArIGluZGV4fT48aW1nIHNyYz17VVJMLmNyZWF0ZU9iamVjdFVSTChmaWxlKX0gYWx0PXtmaWxlLm5hbWV9IC8+PHNwYW4+e2ZpbGUubmFtZX08L3NwYW4+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiZGFuZ2VyLWJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHJlbW92ZVBlbmRpbmdGaWxlKGluZGV4LCAnaW1hZ2UnKX0+5YmK6ZmkPC9idXR0b24+PC9kaXY+KX08L2Rpdj59e2RyYWZ0U3RhdHVzICYmIDxwIGNsYXNzTmFtZT1cImRyYWZ0LXN0YXR1c1wiPntkcmFmdFN0YXR1c308L3A+fTxkaXYgY2xhc3NOYW1lPVwiZm9ybS1hY3Rpb25zXCI+PGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgY2xhc3NOYW1lPVwicHJpbWFyeS1idXR0b25cIiBkaXNhYmxlZD17aXNTYXZpbmd9Pntpc1NhdmluZyA/ICfkv53lrZjkuK0nIDogbW9kZSA9PT0gJ2NyZWF0ZScgPyAn55m76YyyJyA6ICfmm7TmlrAnfTwvYnV0dG9uPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImdob3N0LWJ1dHRvblwiIG9uQ2xpY2s9e2NhbmNlbE1lbW9Gb3JtfT7jgq3jg6Pjg7Pjgrvjg6s8L2J1dHRvbj48L2Rpdj48L2Zvcm0+PC9zZWN0aW9uPn1cblxuICAgICAge21vZGUgPT09ICdkZXRhaWwnICYmIHNlbGVjdGVkTWVtbyAmJiA8c2VjdGlvbiBjbGFzc05hbWU9XCJ3b3Jrc3BhY2UgZGV0YWlsLXBhbmVsXCI+PGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLWhlYWRpbmdcIj48aDI+e3NlbGVjdGVkTWVtby50aXRsZX08L2gyPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImdob3N0LWJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldE1vZGUoJ2xpc3QnKX0+5LiA6Kan44G45oi744KLPC9idXR0b24+PC9kaXY+e3NlbGVjdGVkTWVtby50YWdzPy5sZW5ndGggPiAwICYmIDxkaXYgY2xhc3NOYW1lPVwidGFnLWxpc3QgZGV0YWlsLXRhZ3NcIj57c2VsZWN0ZWRNZW1vLnRhZ3MubWFwKCh0YWcpID0+IDxzcGFuIGNsYXNzTmFtZT1cInRhZy1jaGlwXCIga2V5PXt0YWd9Pnt0YWd9PC9zcGFuPil9PC9kaXY+fXtzZWxlY3RlZE1lbW8uYXR0YWNobWVudHM/Lmxlbmd0aCA+IDAgJiYgPGRpdiBjbGFzc05hbWU9XCJmaWxlLWxpc3RcIj48aDM+5re75LuY44OV44Kh44Kk44OrPC9oMz57c2VsZWN0ZWRNZW1vLmF0dGFjaG1lbnRzLm1hcCgoZmlsZSkgPT4gPGRpdiBjbGFzc05hbWU9XCJmaWxlLXJvd1wiIGtleT17ZmlsZS5pZH0+PHNwYW4+e2ZpbGUub3JpZ2luYWxOYW1lfSAoe2Zvcm1hdFNpemUoZmlsZS5zaXplKX0pPC9zcGFuPjxkaXYgY2xhc3NOYW1lPVwicm93LWFjdGlvbnNcIj48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBkb3dubG9hZEZpbGUoZmlsZSl9PuODgOOCpuODs+ODreODvOODiTwvYnV0dG9uPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImRhbmdlci1idXR0b25cIiBvbkNsaWNrPXsoKSA9PiBkZWxldGVFeGlzdGluZ0ZpbGUoZmlsZSl9PuWJiumZpDwvYnV0dG9uPjwvZGl2PjwvZGl2Pil9PC9kaXY+fXtzZWxlY3RlZE1lbW8uaW1hZ2VzPy5sZW5ndGggPiAwICYmIDxkaXYgY2xhc3NOYW1lPVwiaW1hZ2UtZ3JpZFwiPjxoMz7nlLvlg488L2gzPntzZWxlY3RlZE1lbW8uaW1hZ2VzLm1hcCgoZmlsZSkgPT4gPGRpdiBjbGFzc05hbWU9XCJpbWFnZS1jYXJkXCIga2V5PXtmaWxlLmlkfT57aW1hZ2VVcmxzW2ZpbGUuaWRdID8gPGltZyBzcmM9e2ltYWdlVXJsc1tmaWxlLmlkXX0gYWx0PXtmaWxlLm9yaWdpbmFsTmFtZX0gLz4gOiA8ZGl2IGNsYXNzTmFtZT1cImltYWdlLXBsYWNlaG9sZGVyXCI+44OX44Os44OT44Ol44O844Gn44GN44G+44Gb44KTPC9kaXY+fTxzcGFuPntmaWxlLm9yaWdpbmFsTmFtZX08L3NwYW4+PGRpdiBjbGFzc05hbWU9XCJyb3ctYWN0aW9uc1wiPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IGRvd25sb2FkRmlsZShmaWxlKX0+44OA44Km44Oz44Ot44O844OJPC9idXR0b24+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiZGFuZ2VyLWJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IGRlbGV0ZUV4aXN0aW5nRmlsZShmaWxlKX0+5YmK6ZmkPC9idXR0b24+PC9kaXY+PC9kaXY+KX08L2Rpdj59PHAgY2xhc3NOYW1lPVwibWVtby1ib2R5XCI+e3NlbGVjdGVkTWVtby5ib2R5fTwvcD48ZGwgY2xhc3NOYW1lPVwiZGF0ZS1ncmlkXCI+PGRpdj48ZHQ+5L2c5oiQ5pel5pmCPC9kdD48ZGQ+e2Zvcm1hdERhdGUoc2VsZWN0ZWRNZW1vLmNyZWF0ZWRBdCl9PC9kZD48L2Rpdj48ZGl2PjxkdD7mm7TmlrDml6XmmYI8L2R0PjxkZD57Zm9ybWF0RGF0ZShzZWxlY3RlZE1lbW8udXBkYXRlZEF0KX08L2RkPjwvZGl2PjwvZGw+PGRpdiBjbGFzc05hbWU9XCJmb3JtLWFjdGlvbnNcIj48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzdGFydEVkaXQoc2VsZWN0ZWRNZW1vKX0+57eo6ZuGPC9idXR0b24+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiZGFuZ2VyLWJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IGRlbGV0ZU1lbW8oc2VsZWN0ZWRNZW1vKX0+5YmK6ZmkPC9idXR0b24+PC9kaXY+PC9zZWN0aW9uPn1cbiAgICA8L21haW4+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwXHJcblxyXG5cclxuXHJcbiJdfQ==